from pathlib import Path
import os,subprocess,json,hashlib,time,shutil,sys,ast
r=Path('/Users/andreyyurlov/.codex/worktrees/local-service-stack/incant');o=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/physics-process-main176-001');o.mkdir(exist_ok=False)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
assert not git('status','--porcelain');head=git('rev-parse','HEAD');assert head=='8a9b469efb1c5be8b78e185b077e3d12ce03e70e'
producer=json.loads(Path('/Users/andreyyurlov/.codex/incant-evidence/physics-project-shipping-002/freeze.json').read_text());assert all(h(r/p)==sha for p,sha in producer.items());(o/'producer-freeze.json').write_text(json.dumps(producer,indent=2)+'\n')
paths=git('ls-files','crates','editor/app','tools','sdk','schemas','third_party','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo').splitlines();freeze={p:h(r/p) for p in paths if (r/p).is_file()};(o/'freeze.json').write_text(json.dumps({'head':head,'files':freeze},indent=2)+'\n')
e=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');e['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/Users/andreyyurlov/.local/share/fnm/node-versions/v22.23.3/installation/bin:/opt/homebrew/bin:'+e['PATH'];rows=[]
def run(name,cmd,env=e,cwd=r):
 assert all(h(r/p)==v for p,v in freeze.items());print('starting',name,flush=True);start=time.monotonic()
 with (o/(name+'.stdout')).open('wb') as out,(o/(name+'.stderr')).open('wb') as err:rc=subprocess.run(cmd,cwd=cwd,env=env,stdout=out,stderr=err).returncode
 row={'name':name,'command':list(map(str,cmd)),'cwd':str(cwd),'exit':rc,'seconds':time.monotonic()-start}
 for s in ['stdout','stderr']:row[s]={'path':str(o/(name+'.'+s)),'sha256':h(o/(name+'.'+s))}
 rows.append(row);(o/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,rc,flush=True);assert all(h(r/p)==v for p,v in freeze.items())
 if rc:raise SystemExit(rc)
 return (o/(name+'.stdout')).read_text()
run('python',['python3','-B','-m','unittest','discover','-s','tools/tests','-v']);run('node',['node','--test','tools/tests/native_script.test.mjs'])
sys.path.insert(0,str(r/'tools'));import export_native,physics_export,physics_features
# Reproduce the exact candidate's obsolete workspace-wide graph audit against current metadata.
metadata=json.loads(run('workspace-metadata',['cargo','metadata','--locked','--format-version','1','--filter-platform','x86_64-unknown-linux-gnu']))
old=subprocess.check_output(['git','show','a2cae856183e35cf1007a90803ad740d62984b00:tools/export_native.py'],cwd=r,text=True);tree=ast.parse(old);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='normal_dependencies');env={'require':export_native.require,'NAME':'incant_game_player'};exec(compile(ast.Module(body=[node],type_ignores=[]),'<candidate normal_dependencies>','exec'),env)
try:env['normal_dependencies'](metadata)
except ValueError as error:assert str(error)=='Authoring/JIT normal dependency: incant_wasm_dev';failure=str(error)
else:raise AssertionError('Baseline graph audit did not reproduce')
(o/'baseline-refusal.json').write_text(json.dumps({'candidate':'a2cae856183e35cf1007a90803ad740d62984b00','error':failure,'metadata_sha256':h(o/'workspace-metadata.stdout'),'production_graph_source':'exact candidate function, current actual workspace metadata','qualification':'Reproduces false workspace feature leakage; no old exporter or build executed.'},indent=2)+'\n')
graphs=[]
for target in ['aarch64-apple-darwin','x86_64-unknown-linux-gnu','x86_64-pc-windows-msvc']:
 for mode in ['deterministic','fast']:
  features=','.join(physics_export.cargo_features(mode,['project','render-input']));name=target+'-'+mode;graph=run(name,['cargo','tree','--locked','--no-default-features','-p','incant_game_player','--features',features,'--target',target,'-e','normal','--prefix','none','--format','{p}|{f}']);names=export_native.normal_dependencies(graph);assert not physics_features.selected_graph_errors(graph,mode,target);graphs.append({'target':target,'mode':mode,'normal_packages':len(names),'graph_sha256':h(o/(name+'.stdout'))})
(o/'graphs.json').write_text(json.dumps(graphs,indent=2)+'\n')
# New CPU launches of the original immutable producer packages. No cold build or new shipping-source claim.
replays=[];root=Path('/Users/andreyyurlov/.codex/incant-evidence/physics-project-shipping-002/exports')
for mode in ['deterministic','fast']:
 case=root/mode;old=json.loads((case/'result.json').read_text());player=case/'package/player';before={str(p.relative_to(player)):h(p) for p in player.rglob('*') if p.is_file()};assert before==old['package_files'];assert not (case/'authoring').exists() and all(not(case/p).exists() for p in old['removed_maps']);obs=o/(mode+'-observe.json');shutil.copy2(case/'observe.json',obs)
 env={'PATH':str(player),'TMPDIR':str(o),'TMP':str(o),'TEMP':str(o)};pcm=o/(mode+'.pcm');report=json.loads(run('replay-'+mode,[str(player/'incant_game_player'),'--package',str(player/'data'),'--ticks','12','--observe',str(obs),'--output',str(pcm)],env=env,cwd=player));assert report==old['report'];assert h(pcm)==report['pcm_sha256'];assert before=={str(p.relative_to(player)):h(p) for p in player.rglob('*') if p.is_file()};replays.append({'mode':mode,'player_sha256':h(player/'incant_game_player'),'package_path':str(player),'package_files':before,'report':report,'pcm_path':str(pcm),'pcm_sha256':h(pcm),'source_deleted':True,'unchanged_package':True})
(o/'replays.json').write_text(json.dumps(replays,indent=2)+'\n')
run('features',['python3','tools/physics_features.py','manifest']);run('fmt',['./tools/cargo','fmt','--all','--','--check']);run('conventions',['python3','tools/generate_conventions.py','--check']);run('diff',['git','diff','--check'])
(o/'terminal.json').write_text(json.dumps({'head':head,'exit':0,'unchanged':True,'frozen_inputs':len(freeze),'producer_inputs_exact':len(producer),'checks':len(rows),'graphs':len(graphs),'shipping_replays':2,'qualification':'No Rust rebuild, simulator, device, GPU or fresh cold shipping export. Exact producer inputs and original shipping/actual target compiler evidence reused; new helper/graph checks and two unchanged-package CPU launches only.'},indent=2)+'\n');print('terminal',flush=True)
