import os,sys,json,time,hashlib
from pathlib import Path
root=Path('/Users/andreyyurlov/.codex/worktrees/cooked-visual-assets/incant')
sys.path.insert(0,str(root/'tools'));import native_process
out=Path('/Users/andreyyurlov/.codex/incant-evidence/ssao-checks-001');out.mkdir(exist_ok=False)
env=os.environ.copy();env['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:'+env['PATH'];env['CARGO_TARGET_DIR']='/tmp/incant-cpu-profiler-target'
commands=[
['tools/cargo','test','--locked','-p','incant_render','-j2'],
['tools/cargo','clippy','--locked','-p','incant_render','--all-targets','-j2','--','-D','warnings'],
['tools/cargo','check','--locked','-p','incant_render','--lib','--target','wasm32-unknown-unknown','-j2'],
['tools/cargo','test','--locked','-p','incant_render','--lib','--features','cooked-materials','ambient_occlusion','-j2'],
['tools/cargo','clippy','--locked','-p','incant_render','--all-targets','--features','cooked-materials','-j2','--','-D','warnings'],
['tools/cargo','fmt','-p','incant_render','--','--check'],
['python3','tools/check_runtime_dependencies.py','incant_render'],
['python3','tools/generate_conventions.py','--check'],
]
results=[]
for i,cmd in enumerate(commands):
 log=out/f'{i:02}.log';start=time.time()
 with log.open('wb') as stream: r=native_process.run(cmd,cwd=root,env=env,stdout=stream,stderr=stream,timeout=1800)
 row={'argv':cmd,'exit':r.returncode,'seconds':time.time()-start,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()};results.append(row);(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode: sys.exit(r.returncode)
