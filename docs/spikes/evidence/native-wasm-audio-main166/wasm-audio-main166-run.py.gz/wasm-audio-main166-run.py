from pathlib import Path
import os,subprocess,json,time,hashlib,shutil
r=Path('/Users/andreyyurlov/.codex/worktrees/local-service-stack/incant');o=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/wasm-audio-main166-001');o.mkdir(exist_ok=False)
target=Path('/Users/andreyyurlov/.codex/incant-wasm-audio-integration-target');env=dict(os.environ,CARGO_TARGET_DIR=str(target));env['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/Users/andreyyurlov/.local/share/fnm/node-versions/v22.23.3/installation/bin:/opt/homebrew/opt/llvm/bin:/opt/homebrew/bin:'+env['PATH'];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
assert not git('status','--porcelain');assert json.loads((target/'incant-checkout-owner.json').read_text())['checkout']==str(r);head=git('rev-parse','HEAD');assert head=='aa23956568dd8aaec3d6c2f23c13ae4bbfe5bdc2'
paths=git('ls-files','crates','editor/app','tools','sdk','schemas','third_party','samples/core','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo','.gitattributes','.github').splitlines();freeze={p:h(r/p) for p in paths if (r/p).is_file()};(o/'freeze.json').write_text(json.dumps({'head':head,'main':'5bdb77ac11a73c4110e45d8dbb82bfe6ce3aacbe','producer':'ed77de6d46adbb0d5ba96b2117446efe0bdc222c','files':freeze},indent=2)+'\n')
changed=git('diff','--name-only','b8d94477^','ed77de6d','--','crates','tools','sdk','Cargo.toml','Cargo.lock').splitlines();assert all((r/p).read_bytes()==subprocess.check_output(['git','show','ed77de6d:'+p],cwd=r) for p in changed);(o/'accepted-sources.json').write_text(json.dumps({p:h(r/p) for p in changed},indent=2)+'\n')
common=['--locked','--profile','ci','-j2'];cmds=[
('conformance',['python3','tools/probes/shipping-wasm2c.py',str(o/'conformance'),'--rustup','/opt/homebrew/bin/rustup','--profile','ci','--conformance-only']),
('wasm-sdk',['./tools/cargo','check','--manifest-path','sdk/rust/Cargo.toml','--locked','--target','wasm32-unknown-unknown']),
('runtime-only',['./tools/cargo','check']+common+['-p','incant_wasm_runtime','--no-default-features']),
('graph',['python3','tools/check_runtime_dependencies.py','incant_wasm_runtime','incant_wasm_abi','incant_script','incant_game_runtime']),
('generated',['python3','tools/generate_wasm_sdk.py','--check']),
('tools',['python3','-m','unittest','discover','-s','tools/tests','-p','test_wasm*.py']),
('headless',['./tools/cargo','build']+common+['-p','incant_headless','--features','wasmtime-host']),
('oracle',['./tools/cargo','build']+common+['-p','incant_cook','--example','audio_package_oracle']),
('oracle-clippy',['./tools/cargo','clippy']+common+['-p','incant_cook','--example','audio_package_oracle','--','-D','warnings']),
('fmt',['./tools/cargo','fmt','--all','--','--check']),('conventions',['python3','tools/generate_conventions.py','--check']),('diff',['git','diff','--check'])]
results=[]
for name,cmd in cmds:
 assert all(h(r/p)==v for p,v in freeze.items());print('starting',name,flush=True);start=time.monotonic()
 with (o/(name+'.log')).open('w') as log:rc=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 results.append({'name':name,'command':cmd,'exit':rc,'seconds':time.monotonic()-start,'sha256':h(o/(name+'.log'))});(o/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,rc,flush=True)
 if rc:raise SystemExit(rc)
 if name=='headless':
  src=target/'ci/incant_headless';dst=o/'incant_headless';shutil.copy2(src,dst);(o/'headless-binary.json').write_text(json.dumps({'source_head':head,'profile':'ci','features':['wasmtime-host'],'sha256':h(dst),'bytes':dst.stat().st_size},indent=2)+'\n')
 if name=='oracle':
  src=target/'ci/examples/audio_package_oracle';dst=o/'audio_package_oracle';shutil.copy2(src,dst);(o/'oracle-binary.json').write_text(json.dumps({'source_head':head,'profile':'ci','sha256':h(dst),'bytes':dst.stat().st_size},indent=2)+'\n')
 assert all(h(r/p)==v for p,v in freeze.items())
