from pathlib import Path
import sys,os,json,hashlib,time
root=Path('/Users/andreyyurlov/.codex/worktrees/native-audio-host/incant');out=Path(__file__).parent
sys.path.insert(0,str(root/'tools'));from native_process import run
from physics_features import validate_artifacts,compiler_messages
TD='/Users/andreyyurlov/.codex/incant-physics-variant-target';target='aarch64-apple-darwin';env=dict(os.environ,CARGO_TARGET_DIR=TD);rows=[];code=0
for mode,flags in [('deterministic',[]),('fast',['--no-default-features']),('fast-simd8',['--no-default-features'])]:
 for name,sub,packages,extra in [('project-tests','test',['incant_doc','incant_cmd','incant_cook','incant_play'],['incant_cook/typescript']),('project-clippy','clippy',['incant_doc','incant_cmd','incant_cook','incant_play'],['incant_cook/typescript'])]:
  features=extra+[p+'/physics-fast-simd8' for p in packages if p!='incant_doc'] if mode=='fast-simd8' else extra
  argv=[str(root/'tools/cargo'),sub,'--locked','--profile','ci','--target',target,'-j2','--all-targets','--message-format=json']
  for p in packages:argv+=['-p',p]
  argv+=flags
  if sub=='test':
   if name=='variant-save':argv=[a for a in argv if a!='--all-targets']+['--test','physics_variant']
   else:argv+=['--no-fail-fast']
  if features:argv+=['--features',','.join(features)]
  if sub=='clippy':argv+=['--','-D','warnings']
  stem=mode+'-'+name;start=time.monotonic()
  with (out/(stem+'.stdout')).open('wb') as stdout,(out/(stem+'.stderr')).open('wb') as stderr:r=run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr,text=False,timeout=3600)
  row={'name':stem,'argv':argv,'exit_code':r.returncode,'seconds':time.monotonic()-start}
  for stream in ['stdout','stderr']:
   p=out/(stem+'.'+stream);row[stream]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
  if r.returncode==0:row['compiler_features']=validate_artifacts(compiler_messages(out/(stem+'.stdout')),mode,target_dir=TD,target=target,profile='ci')
  rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(stem,r.returncode,flush=True)
  if r.returncode:code=r.returncode;break
 if code:break
freeze=json.loads((out/'freeze.json').read_text());changed=[p for p,h in freeze.items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];(out/'terminal.json').write_text(json.dumps({'exit_code':code,'changed':changed,'frozen_files':len(freeze)},indent=2)+'\n');sys.exit(code or bool(changed))
