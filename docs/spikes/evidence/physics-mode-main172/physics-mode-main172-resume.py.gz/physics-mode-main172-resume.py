from pathlib import Path
import os,sys,json,subprocess,hashlib,time
r=Path('/Users/andreyyurlov/.codex/worktrees/local-service-stack/incant')
o=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/physics-mode-main172-001')
td=Path('/Users/andreyyurlov/.codex/incant-physics-foundation-integration-target')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
assert not git('status','--porcelain');assert git('rev-parse','HEAD')=='bc5087be85b280f51fcd3f891bd7db60d7d06661'
paths=git('ls-files','crates','editor/app','tools','sdk','schemas','third_party','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo').splitlines()
freeze=json.loads((o/'freeze.json').read_text())['files'];assert all(h(r/p)==v for p,v in freeze.items())
e=dict(os.environ,CARGO_TARGET_DIR=str(td));e['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/Users/andreyyurlov/.local/share/fnm/node-versions/v22.23.3/installation/bin:/opt/homebrew/bin:'+e['PATH']
sys.path.insert(0,str(r/'tools'));from physics_features import validate_artifacts,compiler_messages
rows=json.loads((o/'results.json').read_text())
def run(name,cmd,mode=None):
 assert all(h(r/p)==v for p,v in freeze.items());print('starting',name,flush=True);start=time.monotonic()
 with (o/(name+'.stdout')).open('wb') as out,(o/(name+'.stderr')).open('wb') as err:rc=subprocess.run(cmd,cwd=r,env=e,stdout=out,stderr=err).returncode
 row={'name':name,'command':cmd,'exit':rc,'seconds':time.monotonic()-start}
 for s in ['stdout','stderr']:row[s]={'path':str(o/(name+'.'+s)),'sha256':h(o/(name+'.'+s))}
 if rc==0 and mode:row['compiler_features']=validate_artifacts(compiler_messages(o/(name+'.stdout')),mode,target_dir=td,target='aarch64-apple-darwin',profile='ci')
 rows.append(row);(o/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,rc,flush=True)
 assert all(h(r/p)==v for p,v in freeze.items())
 if rc:raise SystemExit(rc)
ui_paths=git('ls-files','editor/ui','package.json','package-lock.json').splitlines()
ui_freeze={p:h(r/p) for p in ui_paths if (r/p).is_file()};(o/'ui-build-inputs.json').write_text(json.dumps(ui_freeze,indent=2)+'\n')
run('frontend-install',['npm','ci'])
run('frontend-build',['npm','run','build','--workspace','editor/ui'])
assert all(h(r/p)==v for p,v in ui_freeze.items())
(o/'frontend-dist.json').write_text(json.dumps({str(p.relative_to(r)):h(p) for p in sorted((r/'editor/ui/dist').rglob('*')) if p.is_file()},indent=2)+'\n')
for mode,flags in [('deterministic',[]),('fast',['--no-default-features']),('fast-simd8',['--no-default-features'])]:
 for name,sub,pkgs,features in [
 ('tests','test',['incant_runtime','incant_cook','incant_game_runtime','incant_render_game'],['incant_cook/typescript']),
 ('clippy','clippy',['incant_runtime','incant_cook','incant_game_runtime','incant_render_game','incant_wasm_dev'],['incant_cook/typescript']),
 ('ancestry','check',['incant_headless','incant_game_player','incant_editor','incant_wasm_dev'],['incant_game_player/project','incant_game_player/render-input','incant_game_player/mobile-ffi','incant_editor/custom-protocol'])]:
  features=features+([p+'/physics-fast-simd8' for p in pkgs] if mode=='fast-simd8' else [])
  cmd=['./tools/cargo',sub,'--locked','--profile','ci','--target','aarch64-apple-darwin','-j2','--all-targets','--message-format=json']+[x for p in pkgs for x in ['-p',p]]+flags
  if features:cmd+=['--features',','.join(features)]
  if sub=='test':cmd+=['--no-fail-fast']
  if sub=='clippy':cmd+=['--','-D','warnings']
  if mode=='deterministic' and name in ('tests','clippy'):continue
  run(mode+'-'+name+('-resume' if mode=='deterministic' else ''),cmd,mode)
run('feature-guard',['python3','tools/physics_features.py','manifest'])
run('feature-tests',['python3','-m','unittest','discover','-s','tools/tests','-p','test_physics_features.py'])
run('fmt',['./tools/cargo','fmt','--all','--','--check'])
run('conventions',['python3','tools/generate_conventions.py','--check'])
run('diff',['git','diff','--check'])
(o/'terminal.json').write_text(json.dumps({'exit':0,'head':git('rev-parse','HEAD'),'frozen_files':len(freeze),'unchanged':True},indent=2)+'\n')
print('all terminal',flush=True)
