import json,sys,os,time,subprocess,hashlib
from pathlib import Path
R=Path('/Users/andreyyurlov/.codex/worktrees/physics-failure-isolation/incant');E=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'tools'),str(R/'tools/probes')]
from native_wasm_restart.owner import Owner,process_rows
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
env=dict(os.environ);env['PATH']='/Users/andreyyurlov/.local/share/fnm/node-versions/v22.23.3/installation/bin:/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin';env.update(PYTHONDONTWRITEBYTECODE='1',CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2')
o=Owner(E/'output',Path('/private/tmp/incant-wasm-persistent-shipping-20261017-target'),16328871936);o.deadline=o.start+900;env['TMPDIR']=str(o.scratch)
r={'source':head,'passed':False,'wrapper_pid':os.getpid(),'stages':[]}
try:
 with o:
  for cmd in json.loads((E/'steps.json').read_text()):
   print(' '.join(cmd),flush=True);start=time.monotonic();x=o.run(cmd,cwd=R,env=env,timeout=300);r['stages'].append({'command':cmd,'exit':x.returncode,'seconds':time.monotonic()-start});assert x.returncode==0,(cmd,x.stderr[-3000:])
  assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip();r['passed']=True;o.passed=True
except BaseException as error:r['error']=repr(error)
r.update(seconds=time.monotonic()-o.start,groups=o.groups,peaks=o.peaks)
(E/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items()if k not in ('stages','groups')}),flush=True)
raise SystemExit(0 if r['passed']else 1)
