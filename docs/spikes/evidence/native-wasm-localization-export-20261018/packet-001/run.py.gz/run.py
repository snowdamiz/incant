"""Reviewed once-only launcher; native work is gated inside the frozen CLI."""
from pathlib import Path
import runpy
import sys
p = Path(__file__).resolve().parent
root = Path('/Users/andreyyurlov/.codex/worktrees/wasm-localization-proof/incant')
script = root / 'tools/probes/native-wasm-localization-export.py'
sys.argv = [str(script), '--packet', str(p), *sys.argv[1:]]
runpy.run_path(str(script), run_name='__main__')
