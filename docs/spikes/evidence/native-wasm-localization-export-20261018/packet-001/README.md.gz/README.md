# Unexecuted authored localization export proof

Producer b79fb1b97ad99951e1579ebda5ea2c5c1d48a529 on main401. One fresh ordinary export; no runtime source changes. Root must create root-grant.json bound to packet.json before native execution. --check is data only.

Invoke the exact pinned Python from plan.json with -B run.py. It compiles one trusted no_std Rust guest and normal headless, authors through import/source/command/save paths, executes one 12-tick TS reference, exports through the unchanged public headless exporter, then runs 12/5/7/7 source-free positive ticks plus six one-tick ignored-error controls from the prefix checkpoint. Expected report totals are 0/130/132/64. Every row field is checked in each guest; Python independently derives the expected canonical rows from authored tables.

No GPU/window/device audio/performance/phase acceptance. Failure subprocesses demonstrate nonpublication and terminal failure, not rollback of accepted native simulation/input. PR401's prior ABI/Wasmtime/wasm2c evidence covers internal callback rollback. Explicit eight-byte state and exact PCM/checkpoint continuation are tested; no arbitrary guest-memory snapshot claim.

All native children are bounded by the existing non-reaping process-group owner, two jobs/Rayon2, 5400s overall, 12GiB fresh target, 8GiB scratch, 2GiB retained, 8GiB RSS, 28GiB launch/6GiB ongoing free floor. Logs retain existing128MiB individual/256MiB aggregate ceilings. Guest180s, headless1200s, author/TS240s, exporter3300s (shipping2400s), ten runtime children30s each/300s aggregate. No automatic retries. No active process, output directory or target has been created by packet preparation.

The 193-file Node tool closure (32,875,399 bytes) was copied from this host's existing pinned dependencies without installation or native addon execution; TypeScript source-only checking passed. node-dependencies.json binds all private bytes, exact lockfile versions and absence of extra files. Node itself is pinned. These preparation tools are separate from future native output budgets, bounded64MiB.

51 pure Python controls pass (12 new,39 reused); strict TS source check, SDK/conventions freshness and git diff whitespace pass. The first pure negative-control error is retained outside this packet: a higher valid watermark was mistakenly expected to fail. Only that negative input was corrected to below-tick; the checker was not relaxed.

After the actual tool session terminates, run closeout.py --terminal-exit EXIT --tool-session SESSION. Its terminal fields are explicitly caller-observed, not inferred. It rechecks every recorded PID/group including wrapper. Periodic process observation is not a sandbox or a claim every transient descendant was sampled. Original repository SDK/tool bytes remain; source-free means runtime package/owned ingress/build removal and restricted PATH, not a filesystem sandbox.
