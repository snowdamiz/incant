"""Post-exit data/process closeout; never launches a compiler or player.

Call only after the actual exec tool handle returns its terminal exit. The exit
and tool session are caller-supplied receipt fields, not measured by this script.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys

P = Path(__file__).resolve().parent
ROOT = Path('/Users/andreyyurlov/.codex/worktrees/wasm-localization-proof/incant')
sys.path.insert(0, str(ROOT/'tools'))
from probes.native_wasm_localization.inputs import verify
from probes.native_wasm_checkpoint.oracle import cleanup
from probes.native_wasm_restart.inputs import record
from probes.native_wasm_restart.owner import tree_bytes

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--terminal-exit', type=int, required=True)
parser.add_argument('--tool-session', required=True)
args = parser.parse_args()
assert not (P/'terminal-closeout.json').exists(), 'Create-only terminal receipt'
verify(ROOT, P)
result = json.loads((P/'result.json').read_text())
owner = json.loads((P/'output/owner.json').read_text())
raw = (P/'output/process-inventory.jsonl').read_bytes()
assert len(raw) <= 1024*1024
inventory = [json.loads(line) for line in raw.splitlines()]
pids = {row['pid'] for row in inventory}
ps = subprocess.run(['/bin/ps','-axo','pid=,pgid=,rss='],check=True,capture_output=True,text=True,timeout=5)
rows = [tuple(map(int, line.split())) for line in ps.stdout.splitlines()]
absence = [{'pid': pid,'pid_and_group_absent':not any(pid in (p,g) for p,g,_ in rows)} for pid in sorted(pids)]
receipt = {'actual_exec_terminal_exit':args.terminal_exit,'tool_session':args.tool_session,
           'terminal_receipt_source':'caller observed completed exec tool, not inferred from result.json',
           'result':record(P/'result.json'),'owner':record(P/'output/owner.json'),
           'inventory':record(P/'output/process-inventory.jsonl'),'absence':absence,
           'source_tools_unchanged':True,'target_allocated_bytes':tree_bytes(Path(json.loads((P/'plan.json').read_text())['target'])),
           'passed':False}
try:
    cleanup(inventory,owner,absence,result['wrapper_pid'])
    receipt['all_observed_pids_and_managed_groups_absent']=True
    receipt['passed'] = args.terminal_exit == 0 and result['passed'] is True
except (ValueError,KeyError,TypeError,AssertionError) as error:
    receipt['error']=repr(error)
with (P/'terminal-closeout.json').open('x') as file:
    json.dump(receipt,file,indent=2);file.write('\n')
print(json.dumps(receipt))
raise SystemExit(0 if receipt.get('all_observed_pids_and_managed_groups_absent') is True else 1)
