"""Source/data-only packet preparation; no compiler or player is invoked."""
import datetime
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

P = Path(__file__).resolve().parent
ROOT = Path('/Users/andreyyurlov/.codex/worktrees/wasm-localization-proof/incant')
BASE = P.parent
sys.path[:0] = [str(ROOT / 'tools')]
from probes.native_wasm_restart.inputs import record, source_inventory
from probes.native_wasm_restart.verify import require
from probes.native_wasm_localization.inputs import verify, node_inventory


def save(name, value):
    with (P / name).open('x') as file:
        json.dump(value, file, indent=2, sort_keys=True)
        file.write('\n')


source = source_inventory(ROOT)
require(source['head'] == 'b79fb1b97ad99951e1579ebda5ea2c5c1d48a529', 'Reviewed source commit')
save('source.json', source)
rust = Path('/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin')
python = Path('/opt/homebrew/Cellar/python@3.14/3.14.8/Frameworks/Python.framework/Versions/3.14/bin/python3.14')
rustup = Path('/opt/homebrew/Cellar/rustup/1.29.1')
xcode = Path('/Applications/Xcode.app/Contents/Developer')
wabt = Path('/Users/andreyyurlov/.codex/incant-resume-20261017/wasm-persistent-cpu-002-1hbnmjxz/tools/wabt')
target = Path('/private/tmp/incant-wasm-localization-shipping-20261017-target')
require(not target.exists() and not target.is_symlink(), 'Fresh target absent; never touch renderer target')
node = Path('/Users/andreyyurlov/.local/share/fnm/node-versions/v24.21.0/installation/bin/node')
tool_paths = [node, python, rust/'bin/cargo', rust/'bin/rustc', rust/'bin/rustfmt',
              rustup/'bin/rustup', rustup/'libexec/bin/rustup',
              wabt/'bin/wasm2c', wabt/'bin/wat2wasm',
              Path('/usr/bin/xcrun'), Path('/usr/bin/cc'), Path('/usr/bin/ar'),
              Path('/usr/bin/ld'), Path('/bin/bash')]
tool_paths += [rust/'lib/rustlib/aarch64-apple-darwin/bin'/name for name in
               ('llvm-nm','llvm-readobj','rust-lld')]
tool_paths += list((rust/'lib').glob('librustc_driver*.dylib'))
tool_paths += list((rust/'lib/rustlib/wasm32-unknown-unknown/lib').iterdir())
tool_paths += [xcode/'Toolchains/XcodeDefault.xctoolchain/usr/bin'/name for name in
               ('clang','clang++','ar','ld','dsymutil','dwarfdump','strip')]
tool_paths += [xcode/'Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk/SDKSettings.plist',
               Path('/opt/homebrew/etc/rustup/settings.toml'), Path('/Users/andreyyurlov/.rustup/settings.toml')]
tools = {}
for path in tool_paths:
    tools[str(path)] = record(path)
    if path.is_symlink(): tools[str(path.resolve(strict=True))] = record(path.resolve(strict=True))
save('tools.json', tools)
save('node-dependencies.json', node_inventory(ROOT))
absent = []
for parent in [ROOT, *ROOT.parents, Path('/Users/andreyyurlov')]:
    for name in ('config', 'config.toml'):
        path = parent / '.cargo' / name
        if path == ROOT / '.cargo/config.toml': continue
        require(not path.exists() and not path.is_symlink(), 'Unbound ambient Cargo configuration: ' + str(path))
        absent.append(str(path))
plan = {
    'format':'incant-authored-wasm-localization-shipping-v1','source_root':str(ROOT),
    'source_head':source['head'],'base_main':'843d6d4b3838d35a158a5178ea5a9fd6e010a7e5',
    'target':str(target),'target_baseline_allocated_bytes':0,'target_ceiling_allocated_bytes':12*1024**3,
    'scratch_bytes':8*1024**3,'retained_bytes':2*1024**3,'rss_bytes':8*1024**3,
    'launch_floor_bytes':28*1024**3,'free_floor_bytes':6*1024**3,
    'aggregate_seconds':5400,'maximum_child_seconds':2400,'jobs':2,'rayon_threads':2,
    'output':str(P/'output'),'python':str(python),'cargo':str(rust/'bin/cargo'),'rustc':str(rust/'bin/rustc'),
    'node':str(node),'node_dependency_preparation_bytes':sum(row['bytes'] for row in node_inventory(ROOT).values()),
    'path':':'.join(map(str,[node.parent,rust/'bin',rustup/'bin','/usr/bin','/bin','/usr/sbin','/sbin'])),
    'developer_dir':str(xcode),'wabt':str(wabt),'absent_configuration':sorted(set(absent)),
    'prepared_at':datetime.datetime.now(datetime.UTC).isoformat(),'observed_free_bytes':shutil.disk_usage(P).free,
    'automatic_retries':0,'native_authorization':'pending exact root-grant.json',
    'no_shared_target':'Fresh independent target; no shared target reads/writes. Prior timer CPU and PGO costs remain retained.',
    'allocation':'Fresh allocation, not a reset of historic persistence or destroyed FONT/CORE targets. All costs/failed records remain scoped to this new packet.',
    'scope':['ordinary Rust coverage guest and matched TS reference; 132 keys, four committed locale settings, exact row identities/pages/unknown-key kind; eight-byte checkpoint; trusted fixed source only','fresh normal default-feature headless, profile ci, bin only',
             'public import/init/RPC atomic authoring, Undo/Redo/save/reopen','ordinary export_native.export fresh cooker+shipping player; no shared session',
             'four plain-player positive runs, six precise refusals; source-free package','bounded raw-data replay and post-exit exact process-inventory closeout'],
    'stages':[{'name':'Rust SDK/guest','seconds':180},{'name':'normal headless','seconds':1200},
              {'name':'public authoring plus actual TS reference','seconds':240},{'name':'fresh export','seconds':3300,'cooker_child_seconds':600,'shipping_child_seconds':2400},
              {'name':'four positive + six refusal processes','seconds':300,'child_seconds':30},
              {'name':'data replay/source postcheck','seconds':'within aggregate5400'}],
    'copied_cooker':'Not executed or substituted; earlier source-compatibility receipt retained as provenance only. Exporter builds current default-profile cooker fresh.',
    'process_lifecycle':'Reuse qualified non-reaping managed process groups. PID inventory is independently append-only; trusted descendants must retain group, polling cannot observe every transient process. Root/tool terminal exit and subsequent ps closeout are required for wrapper absence.',
    'limits':['no runtime/API change; internal rollback evidence remains prior PR401 qualification','no GPU/window/device audio/phone/performance/full-save gate',
              'explicit host bytes only, not arbitrary guest memory','plain two-entity scene, no physics/UI',
              'package48000Hz/default60Hz; fractional tick-frame phase not claimed',
              'callback failures publish no outputs; this does not assert rollback of the earlier simulation/input step',
              'restricted PATH/HOME and deleted owned build/source files are not an OS read sandbox']}
save('plan.json',plan)
save('provenance.json', {'prior_abi_report':record(ROOT/'docs/spikes/evidence/native-wasm-localization-report.json'), 'historical_coroutine_result':record(Path('/Users/andreyyurlov/.codex/incant-resume-20261017/wasm-coroutines-shipping-001/result.json')), 'no_old_native_outputs_reused':True, 'authored_shipping_proof_executed':False})
with (P/'source.diff').open('xb') as file:
    file.write(subprocess.check_output(['/usr/bin/git','-C',str(ROOT),'diff','843d6d4b',source['head']]))
runner = '''"""Reviewed once-only launcher; native work is gated inside the frozen CLI."""\nfrom pathlib import Path\nimport runpy\nimport sys\np = Path(__file__).resolve().parent\nroot = Path('/Users/andreyyurlov/.codex/worktrees/wasm-localization-proof/incant')\nscript = root / 'tools/probes/native-wasm-localization-export.py'\nsys.argv = [str(script), '--packet', str(p), *sys.argv[1:]]\nrunpy.run_path(str(script), run_name='__main__')\n'''
with (P/'run.py').open('x') as file:file.write(runner)
print(json.dumps({'packet':str(P),'head':source['head'],'source_entries':len(source['files']), 'tools':len(tools),'free':plan['observed_free_bytes']}))
