"""Ten bounded fresh-process checks of the unchanged previously built package.

The original producer remains failed. No compiler, exporter or GPU is invoked.
Only the current-format checkpoint oracle changed; exact build/authoring records
and package bytes are independently rechecked before and after these players.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/Users/andreyyurlov/.codex/worktrees/physics-failure-isolation/incant')
E = Path(__file__).resolve().parent
OLD = E.parent / 'packet-001/output'
sys.path.insert(0, str(ROOT / 'tools'))
from probes.native_wasm_checkpoint.owner import CheckpointOwner
from probes.native_wasm_checkpoint.replay import audit_build, managed_logs
from probes.native_wasm_checkpoint.route import inventory
from probes.native_wasm_localization import fixture as f, oracle
from probes.native_wasm_localization.replay import authoring
from probes.native_wasm_restart.verify import equal, require


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    with path.open('x') as file:
        json.dump(value, file, indent=2)
        file.write('\n')


def sha(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def preflight():
    for row in read(E / 'inputs.json'):
        path = Path(row['path'])
        require(not path.is_symlink() and path.stat().st_size == row['bytes']
                and sha(path) == row['sha256'], 'Frozen input changed: ' + str(path))
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
            == '486303d5e10c7a56596efa8b5b058c5e2176c79d', 'Checker source identity')
    prior = read(OLD.parent / 'result.json')
    closeout = read(OLD.parent / 'terminal-closeout.json')
    require(prior['passed'] is False and prior['error'] == "ValueError('Explicit eight-byte state only')"
            and closeout['actual_exec_terminal_exit'] == 1
            and closeout['all_observed_pids_and_managed_groups_absent'] is True,
            'Keep the original failure and terminal closure')
    owner = read(OLD / 'owner.json')
    require(owner['passed'] is False and owner['error'] == prior['error'], 'Original failed owner')
    managed_logs(OLD, owner['calls'])
    authoring(OLD)
    exported = read(OLD / 'package/export.json')
    audit_build(OLD, owner, exported)
    authored = read(OLD / 'authored.json')
    equal(exported['project_sha256'], authored['project_sha256'], 'Authored project identity')
    equal(exported['program'], {
        'kind': 'wasm', 'module': authored['module'], 'fingerprint': authored['fingerprint'],
        'input_sha256': authored['guest_sha256'], 'prepared_sha256': authored['prepared_sha256'],
        'registry_sha256': authored['registry_sha256'], 'translator': 'wasm2c-1.0.42'}, 'Actual guest')
    equal(read(OLD / 'expected-coverage.json'), [f.rows(i) for i in range(4)], 'Independent coverage')
    equal(inventory(OLD / 'package/player'), read(OLD / 'package-files.json'), 'Original immutable package')
    for name in ('authoring', 'trusted-wabt', 'guest-build'):
        require(not (OLD / name).exists(), 'Owned input remains')
    require(not list((OLD / 'private-builds').iterdir()), 'Exporter scratch remains')
    oracle.run(read(OLD / 'baseline.json'), (OLD / 'baseline.pcm').read_bytes(),
               (OLD / 'baseline.save').read_bytes(), 'baseline')


def main():
    preflight()
    if '--check' in sys.argv:
        print('Data-only preflight passed; no native child')
        return
    require(not (E / 'result.json').exists(), 'Once-only followup')
    output = E / 'output'
    target = Path('/private/tmp/incant-wasm-localization-shipping-20261017-target')
    o = CheckpointOwner(output, target)
    o.deadline = o.start + 300
    player = OLD / 'package/player/incant_game_player'
    env = {'PATH': str(player.parent), 'HOME': str(output / 'absent-home'),
           'TMPDIR': str(output), 'TEMP': str(output), 'TMP': str(output)}
    final = {'passed': False, 'wrapper_pid': os.getpid(), 'original_producer_failed': True,
             'compiled_source': 'b79fb1b97ad99951e1579ebda5ea2c5c1d48a529', 'checker_source':
             '486303d5e10c7a56596efa8b5b058c5e2176c79d', 'player_sha256': sha(player),
             'native_compilation': False, 'GPU': False, 'original_seconds': 548.2815779579687}
    outputs = {}
    try:
        with o:
            for name in [*oracle.RUNS, *f.FAILURES.values()]:
                positive = name in oracle.RUNS
                start, end = oracle.RUNS[name] if positive else (f.SPLIT, f.SPLIT + 1)
                key = None if positive else next(k for k, v in f.FAILURES.items() if v == name)
                recording = output / (name + '-input.json')
                write(recording, f.recording(end - start, key) if key else f.recording(end - start))
                pcm, saved = output / (name + '.pcm'), output / (name + '.save')
                argv = [player, '--package', player.parent / 'data', '--ticks', str(end - start),
                        '--output', pcm, '--save-checkpoint', saved, '--input-recording', recording]
                if start:
                    argv += ['--load-checkpoint', output / 'prefix.save']
                if positive:
                    observe = output / (name + '-observe.json')
                    write(observe, f.observation(start, end))
                    argv += ['--observe', observe]
                result = o.run(argv, cwd=player.parent, env=env, timeout=25)
                receipt = {'argv': list(map(str, argv)), 'cwd': str(player.parent), 'environment': env,
                    'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
                    'outputs_present': [pcm.exists(), saved.exists()],
                    'staging': [p.name for p in output.glob('.incant-*')]}
                write(output / (name + '-process.json'), receipt)
                if positive:
                    require(result.returncode == 0 and result.stderr == '', 'Successful exact native route')
                    require(pcm.stat().st_size <= 256000 and saved.stat().st_size <= 1024**2, 'Read bounds')
                    report = json.loads(result.stdout)
                    write(output / (name + '.json'), report)
                    outputs[name] = {'report': report, 'pcm': pcm.read_bytes(), 'saved': saved.read_bytes()}
                    oracle.run(**outputs[name], name=name)
                else:
                    oracle.refusal(receipt, name)
            oracle.joined(outputs, read(OLD / 'reference.json'), (OLD / 'reference.pcm').read_bytes())
            require(outputs['baseline']['pcm'] == (OLD / 'baseline.pcm').read_bytes()
                    and outputs['baseline']['saved'] == (OLD / 'baseline.save').read_bytes(),
                    'Original actual baseline reproduced exactly')
            preflight()
            o.passed = True
        final['passed'] = True
    except BaseException as error:
        final['error'] = repr(error)
    final.update(seconds=time.monotonic() - o.start, groups=o.groups, peaks=o.peaks,
                 cumulative_seconds=548.2815779579687 + time.monotonic() - o.start)
    write(E / 'result.json', final)
    print(json.dumps({k: v for k, v in final.items() if k != 'groups'}))
    raise SystemExit(0 if final['passed'] else 1)


if __name__ == '__main__':
    main()
