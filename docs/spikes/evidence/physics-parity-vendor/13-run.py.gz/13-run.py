from pathlib import Path
import hashlib,json,subprocess,time,os
root=Path('/Users/andreyyurlov/.codex/worktrees/ci-build-cache/incant');out=Path(__file__).parent;env=dict(os.environ);env['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/opt/homebrew/bin:'+env['PATH'];source={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in ['tools/probes/physics-parity/features.py','tools/tests/test_physics_parity.py']};(out/'source.json').write_text(json.dumps(source,indent=2)+'\n');results=[]
for name,args in [('tools',['npm','run','test:tools']),('conventions',['python3','tools/generate_conventions.py','--check']),('diff',['git','diff','--check'])]:
 start=time.time();p=out/(name+'.log')
 with p.open('wb') as f:r=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'argv':args,'exit':r.returncode,'seconds':time.time()-start,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};results.append(row);(out/'checks.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 assert all(hashlib.sha256((root/n).read_bytes()).hexdigest()==h for n,h in source.items())
 if r.returncode:raise SystemExit(r.returncode)
