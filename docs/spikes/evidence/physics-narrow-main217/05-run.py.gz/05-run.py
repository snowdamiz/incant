from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
R=Path('/Users/andreyyurlov/.codex/worktrees/grid-navigation/incant');E=Path(__file__).parent
producer='e921a308ca73e0331540dac4c0f90bce372b200b';main='1da6cab9778913999a745803445f209d4da0f90d'
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def sha(b):return hashlib.sha256(b).hexdigest()
roots=['crates/incant_physics_snapshot','third_party','Cargo.toml','Cargo.lock','.cargo','rust-toolchain.toml','tools/cargo','crates/incant_runtime/src/save.rs','crates/incant_script/src/checkpoint/mod.rs']
assert not git('diff','--name-only',producer,'--',*roots).strip()
paths=set(git('ls-tree','-r','--name-only',producer,'--',*roots).decode().splitlines())
paths.update(p for p in git('ls-tree','-r','--name-only',producer,'--','crates').decode().splitlines() if p.endswith('/Cargo.toml'))
rows=[]
for p in sorted(paths):
 b=(R/p).read_bytes();assert b==git('show',producer+':'+p),p;rows.append({'path':p,'sha256':sha(b),'bytes':len(b)})
(E/'source-identity.json').write_text(json.dumps({'producer':producer,'main':main,'roots':roots,'files':rows,'all_workspace_manifests_exact':True},indent=2)+'\n')
delta=[]
for p in git('diff','--name-only',producer,'HEAD','--','crates','third_party','Cargo.toml','Cargo.lock','.cargo','rust-toolchain.toml','tools').decode().splitlines():
 assert p.startswith(('crates/incant_render/','crates/incant_render_data/','crates/incant_render_game/','crates/incant_text/','crates/incant_ui/')),p
 b=(R/p).read_bytes();assert b==git('show',main+':'+p);old=git('show',producer+':'+p) if git('ls-tree',producer,'--',p).strip() else None;delta.append({'path':p,'producer_sha256':sha(old) if old is not None else None,'current_main_sha256':sha(b)})
(E/'unrelated-main-delta.json').write_text(json.dumps(delta,indent=2)+'\n')
M=json.loads((R/'docs/spikes/evidence/physics-narrow-owner.json').read_text());env=os.environ.copy();env['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/opt/homebrew/bin:'+env['PATH'];env['CARGO_NET_OFFLINE']='true';checks=[]
def run(name,args):
 p=E/(name+'.log');t=time.monotonic()
 with p.open('wb') as f:
  child=subprocess.Popen(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT);code=child.wait()
 row={'name':name,'argv':args,'cwd':str(R),'pid':child.pid,'exit':code,'reaped':True,'seconds':round(time.monotonic()-t,3),'path':str(p),'sha256':sha(p.read_bytes())};checks.append(row);(E/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(name,code,flush=True);assert code==0,row
run('selected-graph',['./tools/cargo','tree','--locked','--offline','-p','incant_physics_snapshot','--edges','normal,build,dev','--prefix','none','--format','{p} {f}'])
for row in M['binaries']:
 p=Path(row['path']);assert p.stat().st_size==row['bytes'] and sha(p.read_bytes())==row['sha256'];run('replay-'+p.name,[str(p),'--test-threads=1','--nocapture'])
run('runtime-graph',['python3','tools/check_runtime_dependencies.py','incant_physics_snapshot'])
run('fmt',['./tools/cargo','fmt','--all','--','--check'])
run('conventions',['python3','tools/generate_conventions.py','--check'])
run('diff',['git','diff','--check',main,'HEAD'])
for row in rows:assert sha((R/row['path']).read_bytes())==row['sha256'],row['path']
print('completed',len(checks),datetime.datetime.now(datetime.UTC).isoformat(),flush=True)
