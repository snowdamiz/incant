from pathlib import Path
import os,subprocess,json,hashlib,gzip,time,shutil
r=Path('/Users/andreyyurlov/.codex/worktrees/local-service-stack/incant');o=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/physics-project-main173-001');o.mkdir(exist_ok=False)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
assert not git('status','--porcelain');head=git('rev-parse','HEAD');assert head=='38dcd215b6165cebbeaadfa5f876113a3fdbb604'
paths=git('ls-files','crates','editor/app','tools','sdk','schemas','third_party','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo').splitlines();freeze={p:h(r/p) for p in paths if (r/p).is_file()};(o/'freeze.json').write_text(json.dumps({'head':head,'files':freeze},indent=2)+'\n')
producer='530f322f477ec643b3b6907d4799e94cd8fd7d0b';diff=git('diff','--name-only',producer,'HEAD','--','crates','editor','tools','sdk','schemas','third_party','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo').splitlines();assert len(diff)==5 and all(p.startswith('tools/probes/physics-snapshot-boundary/') for p in diff)
verified={}
for name in ['integrated-freeze','headless-freeze']:
 p=r/'docs/spikes/evidence/physics-project-contract'/(name+'.json.gz');v=json.loads(gzip.decompress(p.read_bytes()));assert all(h(r/f)==sha for f,sha in v.items());verified[name]={'retained_path':str(p.relative_to(r)),'sha256':h(p),'count':len(v),'all_exact':True}
source=Path('/Users/andreyyurlov/.codex/incant-evidence/physics-project-headless-001/incant_headless');assert h(source)=='bfc30895d90cb04122904f347e891beb63258d2b94cfdcb8377ae6e1ee0cc04b';binary=o/'incant_headless';shutil.copy2(source,binary);binary.chmod(0o555)
(o/'reused-evidence.json').write_text(json.dumps({'producer':producer,'head':head,'compiled_path_differences':diff,'difference_scope':'Separate excluded trusted physics diagnostic only; no linked engine/host/compiler input differences.','freezes':verified,'binary':{'source':str(source),'copy':str(binary),'sha256':h(binary)},'qualification':'No Rust recompilation or Rust test rerun in this integration. Reuse source-identical producer 134 tests and Clippy per three variants plus integrated65 cook/Play tests per variant; totals overlap, not additive.'},indent=2)+'\n')
e=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');e['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/Users/andreyyurlov/.local/share/fnm/node-versions/v22.23.3/installation/bin:/opt/homebrew/bin:'+e['PATH'];rows=[]
def run(name,cmd):
 assert all(h(r/p)==v for p,v in freeze.items());print('starting',name,flush=True);start=time.monotonic()
 with (o/(name+'.stdout')).open('wb') as out,(o/(name+'.stderr')).open('wb') as err:rc=subprocess.run(cmd,cwd=r,env=e,stdout=out,stderr=err).returncode
 row={'name':name,'command':cmd,'exit':rc,'seconds':time.monotonic()-start}
 for s in ['stdout','stderr']:row[s]={'path':str(o/(name+'.'+s)),'sha256':h(o/(name+'.'+s))}
 rows.append(row);(o/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,rc,flush=True);assert all(h(r/p)==v for p,v in freeze.items())
 if rc:raise SystemExit(rc)
run('schema',[str(binary),'schema',str(o/'schemas')]);generated={p.name:h(p) for p in (o/'schemas').glob('*.json')};actual={p.name:h(p) for p in (r/'schemas').glob('*.json')};assert len(generated)==70 and generated==actual;(o/'schemas.json').write_text(json.dumps(generated,indent=2)+'\n')
run('sdk',['node','tools/generate_sdk.mjs','--check']);run('strict-sdk',['node','node_modules/typescript/bin/tsc','-p','sdk/ts/tsconfig.json']);run('bridge',['node','tools/build_bridge.mjs','--check']);run('feature-manifests',['python3','tools/physics_features.py','manifest']);run('feature-tests',['python3','-m','unittest','discover','-s','tools/tests','-p','test_physics_features.py']);run('fmt',['./tools/cargo','fmt','--all','--','--check']);run('conventions',['python3','tools/generate_conventions.py','--check']);run('diff',['git','diff','--check'])
(o/'terminal.json').write_text(json.dumps({'head':head,'exit':0,'unchanged':True,'frozen_inputs':len(freeze),'schemas':len(generated),'checks':len(rows),'rust_evidence_reused':True},indent=2)+'\n');print('all terminal',flush=True)
