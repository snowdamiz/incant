from pathlib import Path
import subprocess,os,json,hashlib,datetime
root=Path('/Users/andreyyurlov/.codex/worktrees/ci-build-cache/incant'); out=Path(__file__).parent
frozen=json.loads((out/'freeze.json').read_text())
def verify():
 for row in frozen['files']:assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
env=os.environ.copy();env['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/opt/homebrew/bin:'+env['PATH'];env['CARGO_TARGET_DIR']='/tmp/incant-dynamic-resolution-target';env['CARGO_BUILD_JOBS']='2'
meta=json.loads(subprocess.check_output(['cargo','metadata','--locked','--format-version','1','--no-deps'],cwd=root,env=env));members=set(meta['workspace_members']);packages=[x['name'] for x in meta['packages'] if x['id'] in members]
commands=[('workspace-products-clean',['cargo','clean',*[a for name in packages for a in ['-p',name]]]),('renderer-cpu',['cargo','test','-p','incant_render','--lib','--profile','ci','--locked','-j2']),('renderer-clippy',['cargo','clippy','-p','incant_render','--all-targets','--profile','ci','--locked','-j2','--','-D','warnings']),('fmt',['cargo','fmt','--all','--check']),('conventions',['python3','tools/generate_conventions.py','--check']),('diff',['git','diff','--check'])]
results=[]
for i,(name,cmd) in enumerate(commands):
 verify();log=out/f'{i:02}-{name}.log';start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with log.open('wb') as f:
  f.write(('$ '+' '.join(cmd)+'\n').encode());f.flush();p=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 result={'name':name,'command':cmd,'start':start,'end':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()};results.append(result);(out/'checks.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(result),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 verify()
(out/'after-freeze.json').write_text(json.dumps({'unchanged':True,'files':len(frozen['files'])})+'\n')
