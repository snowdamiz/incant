from pathlib import Path
import json,hashlib,subprocess,os,sys,time,shutil
root=Path('/Users/andreyyurlov/.codex/worktrees/native-audio-host/incant');out=Path(__file__).parent;target=Path('/Users/andreyyurlov/.codex/incant-physics-variant-target');sys.path.insert(0,str(root/'tools'))
from native_process import run
from physics_features import compiler_messages,validate_artifacts
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','crates','tools','sdk','schemas','third_party','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo'],cwd=root,text=True).splitlines();freeze={p:h(root/p) for p in paths if (root/p).is_file()};(out/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
env=dict(os.environ,CARGO_TARGET_DIR=str(target));rows=[];binaries={}
for mode in ['deterministic','fast']:
 flags=['--no-default-features']+(['--features','physics-deterministic'] if mode=='deterministic' else [])
 for kind,tail in [('test',[]),('clippy',['--','-D','warnings']),('build',[])]:
  name=mode+'-'+kind;argv=[str(root/'tools/cargo'),kind,'--locked','--profile','ci','--target','aarch64-apple-darwin','-j2','-p','incant_headless','--bin','incant_headless',*flags,'--message-format=json',*tail];start=time.monotonic()
  with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:r=run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=1800)
  changed=[p for p,s in freeze.items() if h(root/p)!=s];row={'name':name,'argv':argv,'exit_code':r.returncode,'seconds':time.monotonic()-start,'changed':changed};rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
  if r.returncode or changed:sys.exit(r.returncode or 1)
  if kind=='build':
   messages=compiler_messages(out/(name+'.stdout'));row['physics']=validate_artifacts(messages,mode,target_dir=target,target='aarch64-apple-darwin',profile='ci')
   executable=[m['executable'] for m in messages if m.get('reason')=='compiler-artifact' and m['target']['name']=='incant_headless' and m.get('executable')];assert len(executable)==1
   dest=out/('incant_headless-'+mode);shutil.copy2(executable[0],dest);dest.chmod(0o555);binaries[mode]={'path':str(dest),'sha256':h(dest),'physics':row['physics']}
(out/'binaries.json').write_text(json.dumps(binaries,indent=2)+'\n');(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'result.json').write_text(json.dumps({'passed':True,'frozen_inputs':len(freeze),'commands':6,'binaries':binaries},indent=2)+'\n')
