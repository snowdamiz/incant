from pathlib import Path
import gzip,hashlib,json,subprocess
R=Path('/Users/andreyyurlov/.codex/worktrees/grid-navigation/incant');E=Path(__file__).parent;D=R/'docs/spikes/evidence/physics-collider-main216';D.mkdir(exist_ok=True)
producer='9c7f5a446962eac365a746682e6c6e54bc0fb372';main='428ab762235d365f7545395ff896eb1d9d96e450'
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
def sha(b):return hashlib.sha256(b).hexdigest()
roots=['crates/incant_physics_snapshot','third_party','Cargo.toml','Cargo.lock','.cargo','rust-toolchain.toml','tools/cargo']
files=git('ls-tree','-r','--name-only',producer,'--',*roots).decode().splitlines();rows=[]
for p in files:
 b=(R/p).read_bytes();assert b==git('show',producer+':'+p),p;rows.append({'path':p,'sha256':sha(b)})
(E/'source-identity.json').write_text(json.dumps({'producer':producer,'roots':roots,'files':rows},indent=2)+'\n')
changed=git('diff','--name-only',producer,'HEAD','--','crates','third_party','Cargo.toml','Cargo.lock','.cargo','rust-toolchain.toml','tools').decode().splitlines()
assert changed==git('diff','--name-only',main+'~1',main,'--','crates','third_party','Cargo.toml','Cargo.lock','.cargo','rust-toolchain.toml','tools').decode().splitlines() or all(p.startswith(('crates/incant_render/','crates/incant_render_data/','crates/incant_render_game/','crates/incant_text/','crates/incant_ui/')) for p in changed)
delta=[]
for p in changed:
 b=(R/p).read_bytes();assert b==git('show',main+':'+p);delta.append({'path':p,'producer_sha256':sha(git('show',producer+':'+p)),'main_sha256':sha(b)})
(E/'unrelated-main-delta.json').write_text(json.dumps(delta,indent=2)+'\n')
records=[]
for i,p in enumerate(sorted(E.iterdir())):
 if not p.is_file() or p.name=='package.py':continue
 b=p.read_bytes();dest=D/(f'{i:02d}-'+p.name+'.gz');dest.write_bytes(gzip.compress(b,mtime=0));records.append({'path':str(dest.relative_to(R)),'sha256':sha(dest.read_bytes()),'raw_path':str(p),'raw_sha256':sha(b),'raw_bytes':len(b)})
m={'schema':1,'scope':'Exact accepted inert collider source on main216; no live physics-save admission','producer':producer,'main':main,'integration_source':git('rev-parse','HEAD').decode().strip(),'producer_manifest':{'path':'docs/spikes/evidence/physics-collider-state.json','sha256':'2fed433a3cf7986c49706ca196cc9c31e2ba78d283c59583c0046a8f374ecefd'},'producer_reviews':[{'path':'docs/spikes/evidence/physics-collider-source-review.json','sha256':'4773d3bf2fdea3bd5e45f8c9029e0aa1dad912b06618c5b2de1a28381d12352b'},{'path':'docs/spikes/evidence/physics-collider-final-review.json','sha256':'9da78ce6b3e4306feb318a2bd496bb72c69e69626ac614751a599a5bc6386dd1'}],'source_files':len(rows),'unrelated_implementation_files':len(delta),'checks':8,'replayed_cases':34,'retained_full_producer_cases':135,'records':records,'limits':['No new compile: exact producer binaries were rerun after source and selected dependency equality checks.','Strict Clippy and wasm32 are reused exact-source producer evidence.','Trusted own-world serde continuation does not admit hostile decoded records to a live solver.','No shipping, GPU, device, performance, or phase gate claim.'],'review':'Independent current-main review pending'}
(R/'docs/spikes/evidence/physics-collider-main216.json').write_text(json.dumps(m,indent=2)+'\n');print('sources',len(rows),'records',len(records),'unrelated',len(delta))
