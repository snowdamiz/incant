from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
R=Path('/Users/andreyyurlov/.codex/worktrees/grid-navigation/incant');P=Path('/Users/andreyyurlov/.codex/worktrees/native-agent-play/incant');E=Path(__file__).parent
M=json.loads((R/'docs/spikes/evidence/physics-collider-state.json').read_text());env=os.environ.copy();env['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/opt/homebrew/bin:'+env['PATH'];env['CARGO_NET_OFFLINE']='true'
checks=[]
def run(name,args,cwd=R):
 p=E/(name+'.log');t=time.monotonic()
 with p.open('wb') as f:
  child=subprocess.Popen(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT);code=child.wait()
 row={'name':name,'argv':args,'cwd':str(cwd),'pid':child.pid,'exit':code,'reaped':True,'seconds':round(time.monotonic()-t,3),'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()};checks.append(row);(E/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(name,code,flush=True);assert code==0,row
assert not subprocess.check_output(['git','status','--porcelain'],cwd=P).strip()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=P).decode().strip()=='9c7f5a446962eac365a746682e6c6e54bc0fb372'
for label,cwd in [('current',R),('producer',P)]:run(label+'-selected-graph',['./tools/cargo','tree','--locked','--offline','-p','incant_physics_snapshot','--edges','normal,build,dev','--prefix','none','--format','{p} {f}'],cwd)
a=(E/'current-selected-graph.log').read_text().replace(str(R),'<ROOT>');b=(E/'producer-selected-graph.log').read_text().replace(str(P),'<ROOT>');assert a==b;(E/'normalized-selected-graph.txt').write_text(a)
for row in M['binaries']:
 p=Path(row['path']);assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'];run('replay-'+p.name,[str(p),'--test-threads=1','--nocapture'])
run('runtime-graph',['python3','tools/check_runtime_dependencies.py','incant_physics_snapshot'])
run('fmt',['./tools/cargo','fmt','--all','--','--check'])
run('conventions',['python3','tools/generate_conventions.py','--check'])
run('diff',['git','diff','--check','428ab762235d365f7545395ff896eb1d9d96e450','HEAD'])
print('completed',len(checks),datetime.datetime.now(datetime.UTC).isoformat())
