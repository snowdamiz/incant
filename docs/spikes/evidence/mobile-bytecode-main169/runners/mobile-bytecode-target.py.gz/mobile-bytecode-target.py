from pathlib import Path
import os,json,subprocess,time
r=Path('/Users/andreyyurlov/.codex/worktrees/ci-build-cache/incant');s=Path('/Users/andreyyurlov/.codex/incant-compound-wasm-integration-target');t=Path('/Users/andreyyurlov/.codex/incant-integration-targets/incant-dbf85c6c752803e4ffcf17b4ee9153f7e76e8c842fb98fb36cefafc89bf3e538');o=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/mobile-bytecode-target');o.mkdir(exist_ok=False)
assert list(t.iterdir())==[t/'.incant-checkout.json'];assert json.loads((t/'.incant-checkout.json').read_text())['checkout']==str(r)
start=time.monotonic();subprocess.run(['/bin/cp','-cR',str(s)+'/.',str(t)],check=True);(t/'CACHEDIR.TAG').write_text('Signature: 8a477f597d28d172789f06886806bc55\n# Private reproducible Cargo cache.\n');(o/'clone.json').write_text(json.dumps({'source':str(s),'target':str(t),'seconds':time.monotonic()-start,'method':'APFS read-only source clone','no_source_build_handles':True},indent=2)+'\n');print('clone complete; source target released',flush=True)
e=dict(os.environ,CARGO_TARGET_DIR=str(t));e['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/opt/homebrew/bin:'+e['PATH']
meta=json.loads(subprocess.check_output(['./tools/cargo','metadata','--locked','--format-version','1'],cwd=r,env=e,stderr=(o/'metadata.log').open('w')));packages=sorted({p['name'] for p in meta['packages'] if p.get('source') is None});commands=[]
for profile in ['ci','release','dev']:
 cmd=['./tools/cargo','clean','--profile',profile]+[v for p in packages for v in ['-p',p]];log=o/(profile+'.log');start=time.monotonic()
 with log.open('w') as f:rc=subprocess.run(cmd,cwd=r,env=e,stdout=f,stderr=subprocess.STDOUT).returncode
 commands.append({'command':cmd,'exit':rc,'seconds':time.monotonic()-start});(o/'result.json').write_text(json.dumps({'target':str(t),'packages':packages,'commands':commands},indent=2)+'\n');print(profile,rc,flush=True)
 if rc:raise SystemExit(rc)
(t/'incant-checkout-owner.json').write_text(json.dumps({'checkout':str(r),'source_clone':str(s),'adoption':str(o/'result.json'),'local_workspace_products_cleaned':True},indent=2)+'\n')
