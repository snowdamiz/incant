from pathlib import Path
import json,gzip,hashlib,subprocess,re,ast
r=Path('/Users/andreyyurlov/.codex/worktrees/ci-build-cache/incant');o=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/mobile-bytecode-main169-001');d=r/'docs/spikes/evidence/mobile-bytecode-main169';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();hb=lambda b:hashlib.sha256(b).hexdigest();j=lambda p:json.loads(p.read_text());git=lambda *a:subprocess.check_output(['git',*a],cwd=r,text=True).strip()
f=j(o/'freeze.json');assert all(h(r/p)==v for p,v in f['files'].items());checks=j(o/'results.json');assert len(checks)==16 and all(x['exit']==0 and h(Path(x['log']))==x['sha256'] for x in checks)
counts={}
for name in ['script','cook','player']:
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',(o/(name+'.log')).read_text());total=[sum(int(x[i]) for x in rows) for i in range(3)];assert total[1:]==[0,0];counts[name]={'passed':total[0],'failed':0,'ignored':0,'groups':len(rows)}
prod=j(o/'producer.json');assert len(prod)==11 and all(h(r/x['path'])==x['sha256'] for x in prod)
proofs={};binaries={};generated={}
for target,controls,commands in [('aarch64-apple-darwin',32,39),('aarch64-apple-ios-sim',32,44),('aarch64-apple-ios',0,7)]:
 a=j(o/target/'archive-receipt.json');p=j(o/target/'callers/result.json');assert p['passed'] and len(p['controls'])==controls and len(p['commands'])==commands
 for key in ['archive','header','fixture_generator']:
  v=p[key];assert h(Path(v['path']))==v['sha256'];binaries[target+'/'+key]=v
 for key,v in p['callers'].items():assert h(Path(v['path']))==v['sha256'];binaries[target+'/'+key]=v
 for c in p['commands']:
  for stream in ['stdout','stderr']:assert h(Path(c[stream]))==c[stream+'_sha256']
 for name,sha in p['fixture_files'].items():assert h(o/target/'callers/fixture'/name)==sha
 for c in p['controls']:
  if 'request' in c:assert h(Path(c['request']))==c['request_sha256']
 m=j(o/target/'script-symbols.json');assert m['format']==3 and m['target']==target and m['producer_target']=='aarch64-apple-darwin' and m['source_sha256']==h(o/'mobile_compat.js')
 data=(o/target/'behavior.rs').read_text();arr=re.search(r'bytecode: &(\[.*?\]), hardening: &(\[.*?\])',data,re.S);assert arr
 bytecode,hardening=[bytes(ast.literal_eval(x)) for x in arr.groups()];assert bytecode[0]==hardening[0]==28 and hb(bytecode)==m['bytecode_sha256'] and hb(hardening)==m['hardening_sha256']
 generated[target]={'metadata':m,'bytecode_sha256':hb(bytecode),'hardening_sha256':hb(hardening),'source':a['embedded_module']};proofs[target]=p
assert len({v['bytecode_sha256'] for v in generated.values()})==1 and len({v['hardening_sha256'] for v in generated.values()})==1
assert len({v['metadata']['build_id'] for v in generated.values()})==1
for name in ['accepted','repeat','release','observation-failure']:
 games=[next(c for c in proofs[t]['controls'] if c['name']==lang+'-'+name)['result']['game'] for t in ['aarch64-apple-darwin','aarch64-apple-ios-sim'] for lang in ['c','swift']];assert all(v==games[0] for v in games)
 pcms=[(o/t/'callers'/f'{lang}-{name}'/'audio.pcm').read_bytes() for t in ['aarch64-apple-darwin','aarch64-apple-ios-sim'] for lang in ['c','swift']];assert all(v==pcms[0] for v in pcms)
(o/'cross-runtime.json').write_text(json.dumps({'passed':True,'exact_cross_runtime_game_cases':['accepted','repeat','release','observation-failure'],'callers_per_case':4,'generated':generated},indent=2)+'\n')
d.mkdir(exist_ok=False);art={}
def keep(p,name):
 dst=d/(name+'.gz');dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(gzip.compress(p.read_bytes(),mtime=0));art[str(dst.relative_to(d))]={'sha256':h(dst),'raw_sha256':h(p),'source':str(p),'bytes':p.stat().st_size}
for p in sorted(o.rglob('*')):
 if not p.is_file() or '__pycache__' in p.parts or p.name in ['libincant_game_player.a','incant-mobile-runtime-fixture','caller-c','caller-swift'] or any(x.endswith('.dSYM') for x in p.parts):continue
 keep(p,str(p.relative_to(o)))
for p in [o.parent/'mobile-bytecode-main169-run.py',o.parent/'mobile-bytecode-target.py',Path(__file__)]:keep(p,'runners/'+p.name)
for p in sorted((o.parent/'mobile-bytecode-target').glob('*')):
 if p.is_file():keep(p,'target-adoption/'+p.name)
packet={'scope':'Trusted-source mobile bytecode route on actual main169; fresh macOS and iOS archives with real C/Swift numerical callers.','tested_source':f['head'],'main':'4fc128f9aba4d5992b9dfd5476d998db7a9a4b7a','source_inputs':len(f['files']),'producer_source':'a54a9da5bc620e0dc9e489cc531ddf6c350109be','accepted_source_comparisons':prod,'checks':checks,'test_counts':counts,'callers':{t:{'passed':p['passed'],'controls':len(p['controls']),'commands':len(p['commands']),'execution':p['execution'],'simulator':p.get('simulator')} for t,p in proofs.items()},'binaries':binaries,'artifacts':art,'cross_runtime':'Exact game reports and PCM for four cases across both C and Swift on macOS and iOS simulator; bytecode/hardening arrays generated freshly and identical across all three archive targets.','independent_review':'pending current-main final audit','limitations':['ci profile CPU fixture only, not shipping-profile or phone performance','iOS device compile/link only; no physical-device execution','No Android admission, authored-project cross-export, renderer/window/GPU or signing changes','Metadata hashes are compatibility checks, not authentication of project executable bytes','Original producer proof is preserved separately; current integration uses new matching archives and caller executables'],'target_ownership':'Explicit checkout-owned target APFS-cloned from idle cache; only cloned local/path-package outputs cleaned for ci/release/dev before use. No shared target writes.'}
(r/'docs/spikes/evidence/mobile-bytecode-main169.json').write_text(json.dumps(packet,indent=2)+'\n');print(json.dumps({'manifest_sha256':h(r/'docs/spikes/evidence/mobile-bytecode-main169.json'),'artifacts':len(art),'sources':len(f['files']),'counts':counts}))
