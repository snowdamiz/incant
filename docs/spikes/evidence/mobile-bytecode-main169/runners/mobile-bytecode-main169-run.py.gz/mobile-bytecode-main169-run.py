from pathlib import Path
import os,subprocess,json,time,hashlib,shutil
r=Path('/Users/andreyyurlov/.codex/worktrees/ci-build-cache/incant');o=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/mobile-bytecode-main169-001');o.mkdir(exist_ok=False)
target=Path('/Users/andreyyurlov/.codex/incant-integration-targets/incant-dbf85c6c752803e4ffcf17b4ee9153f7e76e8c842fb98fb36cefafc89bf3e538')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
assert not git('status','--porcelain');assert git('rev-parse','HEAD')=='c6bb65f05a68caab6ea9d219e25d3e137ca2c9bc';assert json.loads((target/'incant-checkout-owner.json').read_text())['checkout']==str(r)
paths=git('ls-files','crates','editor/app','tools','sdk','schemas','third_party','samples/core','samples/planar','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo','.gitattributes','.github').splitlines();freeze={p:h(r/p) for p in paths if (r/p).is_file()};(o/'freeze.json').write_text(json.dumps({'head':git('rev-parse','HEAD'),'root':str(r),'files':freeze},indent=2)+'\n')
changed=git('diff','--name-only','a54a9da5^','a54a9da5','--','crates').splitlines();producer=[]
for p in changed:
 b=subprocess.check_output(['git','show','a54a9da5:'+p],cwd=r);assert hashlib.sha256(b).hexdigest()==h(r/p),p;producer.append({'path':p,'sha256':h(r/p)})
(o/'producer.json').write_text(json.dumps(producer,indent=2)+'\n')
e=dict(os.environ,CARGO_TARGET_DIR=str(target));e['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/Users/andreyyurlov/.local/share/fnm/node-versions/v22.23.3/installation/bin:/opt/homebrew/opt/llvm/bin:/opt/homebrew/bin:'+e['PATH']
for k in list(e):
 if k.startswith('INCANT_NATIVE_'):del e[k]
results=[]
def run(name,cmd,env=None):
 assert all(h(r/p)==v for p,v in freeze.items());print('starting',name,flush=True);start=time.monotonic();log=o/(name+'.log')
 with log.open('w') as f:rc=subprocess.run(cmd,cwd=r,env=env or e,stdout=f,stderr=subprocess.STDOUT).returncode
 rec={'name':name,'command':cmd,'exit':rc,'seconds':time.monotonic()-start,'log':str(log),'sha256':h(log)};results.append(rec);(o/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,rc,flush=True)
 assert all(h(r/p)==v for p,v in freeze.items())
 if rc:raise SystemExit(rc)
 return rec
c=['--locked','--profile','ci','-j2']
commands=[('script',['./tools/cargo','test']+c+['-p','incant_script']),('cook',['./tools/cargo','test']+c+['-p','incant_cook','--features','typescript','--test','scripts','--test','typescript','--test','project_scripts']),('player',['./tools/cargo','test']+c+['-p','incant_game_player','--features','mobile-ffi,render-input']),('clippy',['./tools/cargo','clippy']+c+['-p','incant_script','-p','incant_cook','-p','incant_game_player','--features','incant_cook/typescript,incant_game_player/mobile-ffi','--all-targets','--','-D','warnings']),('graph',['python3','tools/check_runtime_dependencies.py','incant_script','incant_game_player','--features','incant_game_player/mobile-ffi']),('fmt',['./tools/cargo','fmt','--all','--','--check']),('conventions',['python3','tools/generate_conventions.py','--check']),('diff',['git','diff','--check']),('caller-tests',['python3','tools/probes/mobile-runtime-library/test_verify.py']),('fixture',['./tools/cargo','build','--locked','--release','-j2','--manifest-path','tools/probes/mobile-runtime-library/fixture/Cargo.toml'])]
for n,cmd in commands:run(n,cmd)
b=target/'release/incant-mobile-runtime-fixture';shutil.copy2(b,o/b.name);(o/'fixture-binary.json').write_text(json.dumps({'sha256':h(b),'bytes':b.stat().st_size,'source':git('rev-parse','HEAD'),'profile':'release'},indent=2)+'\n')
fixture=r/'crates/incant_script/tests/fixtures/mobile_compat.js';expected=fixture.with_suffix('.expected.json')
for p in [fixture,expected,r/'crates/incant_game_player/include/incant_game.h']:shutil.copy2(p,o/p.name)
e['INCANT_NATIVE_SCRIPT_SOURCE']=str(fixture);e['INCANT_NATIVE_SCRIPT_NAME']='mobile-compat.js'
archives=[]
for triple in ['aarch64-apple-darwin','aarch64-apple-ios-sim','aarch64-apple-ios']:
 dest=o/triple;dest.mkdir();cmd=['./tools/cargo','rustc']+c+['-p','incant_game_player','--lib','--features','mobile-ffi','--crate-type','staticlib'];tr=target
 if triple!='aarch64-apple-darwin':cmd+=['--target',triple];tr=target/triple
 rec=run('archive-'+triple,cmd);archive=tr/'ci/libincant_game_player.a';shutil.copy2(archive,dest/archive.name)
 matches=[]
 for p in (tr/'ci/build').glob('incant_game_player-*/out/script-symbols.json'):
  data=json.loads(p.read_text())
  if data.get('source_sha256')==h(fixture) and data.get('target')==triple and data.get('source_name')=='mobile-compat.js':matches.append(p)
 assert len(matches)==1,matches
 for p in [matches[0],matches[0].with_name('behavior.rs')]:shutil.copy2(p,dest/p.name)
 receipt={'target':triple,'profile':'ci','features':['mobile-ffi'],'command':{**rec,'exit_code':rec['exit'],'env':{k:e[k] for k in ['PATH','CARGO_TARGET_DIR','INCANT_NATIVE_SCRIPT_SOURCE','INCANT_NATIVE_SCRIPT_NAME']}},'archive':{'path':str(dest/archive.name),'sha256':h(dest/archive.name),'bytes':archive.stat().st_size},'header':{'path':str(o/'incant_game.h'),'sha256':h(o/'incant_game.h')},'sources':freeze,'commit':git('rev-parse','HEAD'),'source_freeze':{'path':str(o/'freeze.json'),'sha256':h(o/'freeze.json')},'linked_guest':{'kind':'mobile-compat','source':{'path':str(o/fixture.name),'sha256':h(fixture)},'expectations':{'path':str(o/expected.name),'sha256':h(expected)}},'script_symbols':{'path':str(dest/'script-symbols.json'),'sha256':h(dest/'script-symbols.json')},'embedded_module':{'path':str(dest/'behavior.rs'),'sha256':h(dest/'behavior.rs')},'unchanged':True,'execution':'not executed; archive compilation only'}
 rp=dest/'archive-receipt.json';rp.write_text(json.dumps(receipt,indent=2)+'\n');archives.append(rp)
for rp in archives:
 run('callers-'+rp.parent.name,['python3','tools/probes/mobile-runtime-library/verify.py','--archive-receipt',str(rp),'--receipt-sha256',h(rp),'--fixture-generator',str(o/'incant-mobile-runtime-fixture'),'--output',str(rp.parent/'callers')])
print('all terminal',flush=True)
