from pathlib import Path
import subprocess,os,json,hashlib,time,shutil,re,stat
r=Path('/Users/andreyyurlov/.codex/worktrees/native-agent-bridge/incant')
e=Path(__file__).parent
f=json.loads((e.parent/'temporal-edge-source-001/freeze.json').read_text())
for row in f['sources']+f['baselines']:assert hashlib.sha256((r/row['path']).read_bytes()).hexdigest()==row['sha256']
env=dict(os.environ,PATH='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:'+os.environ['PATH'],CARGO_TARGET_DIR='/tmp/incant-cpu-profiler-target')
cargo=['tools/cargo'];common=['--locked','--profile','ci','-j2'];pkgs=['-p','incant_render','-p','incant_render_gpu_host']
commands=[('native',cargo+['test']+common+pkgs),('clippy',cargo+['clippy']+common+pkgs+['--all-targets','--','-D','warnings']),('web',cargo+['check']+common+pkgs+['--target','wasm32-unknown-unknown','--lib']),('cooked-refusal',cargo+['test']+common+['-p','incant_render','--lib','--features','cooked-clusters,cooked-materials,cooked-text,cooked-ui,cooked-sprites']),('graph',['python3','tools/check_runtime_dependencies.py']),('format',cargo+['fmt','--all','--','--check']),('conventions',['python3','tools/generate_conventions.py','--check'])]
checks=[];binaries=[]
for name,args in commands:
 t=time.time();log=e/(name+'.log')
 with log.open('w') as out:
  child=subprocess.Popen(args,cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT);code=child.wait()
 checks.append(dict(name=name,argv=args,pid=child.pid,exit=code,reaped=True,seconds=time.time()-t,log=str(log),sha256=hashlib.sha256(log.read_bytes()).hexdigest()))
 (e/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(name,code,flush=True)
 for source in re.findall(r'Running .*?\((/tmp/incant-cpu-profiler-target/[^)]+)\)',log.read_text()):
  source=Path(source);dest=e/'binaries'/(name+'-'+source.name);dest.parent.mkdir(exist_ok=True);shutil.copy2(source,dest)
  binaries.append(dict(copy=str(dest),sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),bytes=dest.stat().st_size,mode=oct(stat.S_IMODE(dest.stat().st_mode))))
 (e/'binaries.json').write_text(json.dumps(binaries,indent=2)+'\n')
 if code:print(log.read_text()[-6000:]);raise SystemExit(code)
for row in f['sources']+f['baselines']:assert hashlib.sha256((r/row['path']).read_bytes()).hexdigest()==row['sha256']
print('final source unchanged; all checks passed',flush=True)
