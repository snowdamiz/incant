// language: metal2.4
#include <metal_stdlib>
#include <simd/simd.h>

using metal::uint;

struct _mslBufferSizes {
    uint buffer_size15;
    uint buffer_size14;
};

struct Frame {
    metal::float4x4 view_projection;
    metal::float4 eye;
    metal::float4 environment;
};
struct VertexOut {
    metal::float4 position;
    metal::float3 world;
    metal::float3 normal;
    metal::float4 tangent;
    metal::float2 uv;
    char _pad5[8];
};
metal::float3 unpackFloat32x3_(uint b0, uint b1, uint b2, uint b3, uint b4, uint b5, uint b6, uint b7, uint b8, uint b9, uint b10, uint b11) {
    return metal::float3(as_type<float>(b3 << 24 | b2 << 16 | b1 << 8 | b0), as_type<float>(b7 << 24 | b6 << 16 | b5 << 8 | b4), as_type<float>(b11 << 24 | b10 << 16 | b9 << 8 | b8));
}
metal::float2 unpackFloat32x2_(uint b0, uint b1, uint b2, uint b3, uint b4, uint b5, uint b6, uint b7) {
    return metal::float2(as_type<float>(b3 << 24 | b2 << 16 | b1 << 8 | b0), as_type<float>(b7 << 24 | b6 << 16 | b5 << 8 | b4));
}
metal::float4 unpackFloat32x4_(uint b0, uint b1, uint b2, uint b3, uint b4, uint b5, uint b6, uint b7, uint b8, uint b9, uint b10, uint b11, uint b12, uint b13, uint b14, uint b15) {
    return metal::float4(as_type<float>(b3 << 24 | b2 << 16 | b1 << 8 | b0), as_type<float>(b7 << 24 | b6 << 16 | b5 << 8 | b4), as_type<float>(b11 << 24 | b10 << 16 | b9 << 8 | b8), as_type<float>(b15 << 24 | b14 << 16 | b13 << 8 | b12));
}

struct vertex_Output {
    metal::float4 position [[position]];
    metal::float3 world [[user(loc0), center_perspective]];
    metal::float3 normal [[user(loc1), center_perspective]];
    metal::float4 tangent [[user(loc2), center_perspective]];
    metal::float2 uv [[user(loc3), center_perspective]];
};
struct vb_15_type { metal::uchar data[48]; };
struct vb_14_type { metal::uchar data[112]; };
vertex vertex_Output vertex_(
  constant Frame& frame [[buffer(0)]]
, uint v_id [[vertex_id]]
, uint i_id [[instance_id]]
, const device vb_15_type* vb_15_in [[buffer(15)]]
, const device vb_14_type* vb_14_in [[buffer(14)]]
, constant _mslBufferSizes& _buffer_sizes [[buffer(1)]]
) {
    metal::float3 position = {};
    metal::float3 normal = {};
    metal::float2 uv = {};
    metal::float4 tangent = {};
    if (v_id < (_buffer_sizes.buffer_size15 / 48)) {
        const vb_15_type vb_15_elem = vb_15_in[v_id];
        position = unpackFloat32x3_(vb_15_elem.data[0], vb_15_elem.data[1], vb_15_elem.data[2], vb_15_elem.data[3], vb_15_elem.data[4], vb_15_elem.data[5], vb_15_elem.data[6], vb_15_elem.data[7], vb_15_elem.data[8], vb_15_elem.data[9], vb_15_elem.data[10], vb_15_elem.data[11]);
        normal = unpackFloat32x3_(vb_15_elem.data[12], vb_15_elem.data[13], vb_15_elem.data[14], vb_15_elem.data[15], vb_15_elem.data[16], vb_15_elem.data[17], vb_15_elem.data[18], vb_15_elem.data[19], vb_15_elem.data[20], vb_15_elem.data[21], vb_15_elem.data[22], vb_15_elem.data[23]);
        uv = unpackFloat32x2_(vb_15_elem.data[24], vb_15_elem.data[25], vb_15_elem.data[26], vb_15_elem.data[27], vb_15_elem.data[28], vb_15_elem.data[29], vb_15_elem.data[30], vb_15_elem.data[31]);
        tangent = unpackFloat32x4_(vb_15_elem.data[32], vb_15_elem.data[33], vb_15_elem.data[34], vb_15_elem.data[35], vb_15_elem.data[36], vb_15_elem.data[37], vb_15_elem.data[38], vb_15_elem.data[39], vb_15_elem.data[40], vb_15_elem.data[41], vb_15_elem.data[42], vb_15_elem.data[43], vb_15_elem.data[44], vb_15_elem.data[45], vb_15_elem.data[46], vb_15_elem.data[47]);
    }
    metal::float4 w0_ = {};
    metal::float4 w1_ = {};
    metal::float4 w2_ = {};
    metal::float4 w3_ = {};
    metal::float4 n0_ = {};
    metal::float4 n1_ = {};
    metal::float4 n2_ = {};
    if (i_id < (_buffer_sizes.buffer_size14 / 112)) {
        const vb_14_type vb_14_elem = vb_14_in[i_id];
        w0_ = unpackFloat32x4_(vb_14_elem.data[0], vb_14_elem.data[1], vb_14_elem.data[2], vb_14_elem.data[3], vb_14_elem.data[4], vb_14_elem.data[5], vb_14_elem.data[6], vb_14_elem.data[7], vb_14_elem.data[8], vb_14_elem.data[9], vb_14_elem.data[10], vb_14_elem.data[11], vb_14_elem.data[12], vb_14_elem.data[13], vb_14_elem.data[14], vb_14_elem.data[15]);
        w1_ = unpackFloat32x4_(vb_14_elem.data[16], vb_14_elem.data[17], vb_14_elem.data[18], vb_14_elem.data[19], vb_14_elem.data[20], vb_14_elem.data[21], vb_14_elem.data[22], vb_14_elem.data[23], vb_14_elem.data[24], vb_14_elem.data[25], vb_14_elem.data[26], vb_14_elem.data[27], vb_14_elem.data[28], vb_14_elem.data[29], vb_14_elem.data[30], vb_14_elem.data[31]);
        w2_ = unpackFloat32x4_(vb_14_elem.data[32], vb_14_elem.data[33], vb_14_elem.data[34], vb_14_elem.data[35], vb_14_elem.data[36], vb_14_elem.data[37], vb_14_elem.data[38], vb_14_elem.data[39], vb_14_elem.data[40], vb_14_elem.data[41], vb_14_elem.data[42], vb_14_elem.data[43], vb_14_elem.data[44], vb_14_elem.data[45], vb_14_elem.data[46], vb_14_elem.data[47]);
        w3_ = unpackFloat32x4_(vb_14_elem.data[48], vb_14_elem.data[49], vb_14_elem.data[50], vb_14_elem.data[51], vb_14_elem.data[52], vb_14_elem.data[53], vb_14_elem.data[54], vb_14_elem.data[55], vb_14_elem.data[56], vb_14_elem.data[57], vb_14_elem.data[58], vb_14_elem.data[59], vb_14_elem.data[60], vb_14_elem.data[61], vb_14_elem.data[62], vb_14_elem.data[63]);
        n0_ = unpackFloat32x4_(vb_14_elem.data[64], vb_14_elem.data[65], vb_14_elem.data[66], vb_14_elem.data[67], vb_14_elem.data[68], vb_14_elem.data[69], vb_14_elem.data[70], vb_14_elem.data[71], vb_14_elem.data[72], vb_14_elem.data[73], vb_14_elem.data[74], vb_14_elem.data[75], vb_14_elem.data[76], vb_14_elem.data[77], vb_14_elem.data[78], vb_14_elem.data[79]);
        n1_ = unpackFloat32x4_(vb_14_elem.data[80], vb_14_elem.data[81], vb_14_elem.data[82], vb_14_elem.data[83], vb_14_elem.data[84], vb_14_elem.data[85], vb_14_elem.data[86], vb_14_elem.data[87], vb_14_elem.data[88], vb_14_elem.data[89], vb_14_elem.data[90], vb_14_elem.data[91], vb_14_elem.data[92], vb_14_elem.data[93], vb_14_elem.data[94], vb_14_elem.data[95]);
        n2_ = unpackFloat32x4_(vb_14_elem.data[96], vb_14_elem.data[97], vb_14_elem.data[98], vb_14_elem.data[99], vb_14_elem.data[100], vb_14_elem.data[101], vb_14_elem.data[102], vb_14_elem.data[103], vb_14_elem.data[104], vb_14_elem.data[105], vb_14_elem.data[106], vb_14_elem.data[107], vb_14_elem.data[108], vb_14_elem.data[109], vb_14_elem.data[110], vb_14_elem.data[111]);
    }
    VertexOut out = {};
    metal::float4x4 world = metal::float4x4(w0_, w1_, w2_, w3_);
    metal::float3x3 linear = metal::float3x3(w0_.xyz, w1_.xyz, w2_.xyz);
    metal::float4 p = world * metal::float4(position, 1.0);
    metal::float4x4 _e23 = frame.view_projection;
    out.position = _e23 * p;
    out.world = p.xyz;
    out.normal = metal::float3x3(n0_.xyz, n1_.xyz, n2_.xyz) * normal;
    out.tangent = metal::float4(linear * tangent.xyz, tangent.w * n0_.w);
    out.uv = uv;
    VertexOut _e41 = out;
    const auto _tmp = _e41;
    return vertex_Output { _tmp.position, _tmp.world, _tmp.normal, _tmp.tangent, _tmp.uv };
}
