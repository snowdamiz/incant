// language: metal2.4
#include <metal_stdlib>
#include <simd/simd.h>

using metal::uint;

struct _mslBufferSizes {
    uint size4;
    uint size5;
    uint size6;
};

struct ShadowCascade {
    metal::float4x4 matrix_;
    metal::float4 parameters;
};
struct type_2 {
    ShadowCascade inner[16];
};
struct ShadowData {
    type_2 cascades;
};
struct LightGrid {
    metal::float4x4 view;
    metal::float4 viewport;
    metal::uint4 dimensions;
    metal::float4 depth;
    metal::uint4 lights;
};
struct Light {
    metal::float4 position_range;
    metal::float4 direction_outer;
    metal::float4 radiance_inner;
    metal::uint4 kind;
};
typedef Light type_12[1];
typedef uint type_13[1];
struct Frame {
    metal::float4x4 view_projection;
    metal::float4 eye;
    metal::float4 environment;
};
struct Material {
    metal::float4 base;
    metal::float4 emissive_roughness;
    metal::float4 factors;
    metal::uint4 flags;
};
struct VertexOut {
    metal::float4 position;
    metal::float3 world;
    metal::float3 normal;
    metal::float4 tangent;
    metal::float2 uv;
    char _pad5[8];
};

float sample_cascade(
    uint index,
    metal::float3 world,
    metal::float3 n_1,
    metal::depth2d_array<float, metal::access::sample> shadow_maps,
    metal::sampler shadow_sampler,
    constant ShadowData& shadow_data
) {
    bool local_2 = {};
    bool local_3 = {};
    bool local_4 = {};
    float sum = 0.0;
    int y = -1;
    int x = {};
    ShadowCascade cascade = shadow_data.cascades.inner[metal::min(unsigned(index), 15u)];
    metal::float4 p = cascade.matrix_ * metal::float4(world + ((n_1 * cascade.parameters.z) * 0.25), 1.0);
    metal::float2 uv = (metal::float2(p.x, -(p.y)) * 0.5) + metal::float2(0.5);
    if (!(metal::any(uv < metal::float2(0.0)))) {
        local_2 = metal::any(uv > metal::float2(1.0));
    } else {
        local_2 = true;
    }
    bool _e38 = local_2;
    if (!(_e38)) {
        local_3 = p.z < 0.0;
    } else {
        local_3 = true;
    }
    bool _e46 = local_3;
    if (!(_e46)) {
        local_4 = p.z > 1.0;
    } else {
        local_4 = true;
    }
    bool _e54 = local_4;
    if (_e54) {
        return 1.0;
    }
    metal::float2 texel = metal::float2(1.0) / static_cast<metal::float2>(metal::uint2(shadow_maps.get_width(), shadow_maps.get_height()));
    uint2 loop_bound = uint2(4294967295u);
    bool loop_init = true;
    while(true) {
        if (metal::all(loop_bound == uint2(0u))) { break; }
        loop_bound -= uint2(loop_bound.y == 0u, 1u);
        if (!loop_init) {
            int _e92 = y;
            y = as_type<int>(as_type<uint>(_e92) + as_type<uint>(1));
        }
        loop_init = false;
        int _e66 = y;
        if (_e66 <= 1) {
        } else {
            break;
        }
        {
            x = -1;
            uint2 loop_bound_1 = uint2(4294967295u);
            bool loop_init_1 = true;
            while(true) {
                if (metal::all(loop_bound_1 == uint2(0u))) { break; }
                loop_bound_1 -= uint2(loop_bound_1.y == 0u, 1u);
                if (!loop_init_1) {
                    int _e89 = x;
                    x = as_type<int>(as_type<uint>(_e89) + as_type<uint>(1));
                }
                loop_init_1 = false;
                int _e71 = x;
                if (_e71 <= 1) {
                } else {
                    break;
                }
                {
                    float _e74 = sum;
                    int _e77 = x;
                    int _e79 = y;
                    float _e86 = shadow_maps.sample_compare(shadow_sampler, uv + (metal::float2(static_cast<float>(_e77), static_cast<float>(_e79)) * texel), static_cast<int>(index), p.z);
                    sum = _e74 + _e86;
                }
            }
        }
    }
    float _e94 = sum;
    return _e94 / 9.0;
}

float directional_shadow(
    uint slot,
    metal::float3 world_1,
    metal::float3 n_2,
    metal::depth2d_array<float, metal::access::sample> shadow_maps,
    metal::sampler shadow_sampler,
    constant ShadowData& shadow_data,
    constant LightGrid& light_grid
) {
    uint i = 0u;
    bool local_5 = {};
    float next = {};
    if (slot == 0u) {
        return 1.0;
    }
    uint base_2 = (slot - 1u) * 4u;
    metal::float4x4 _e12 = light_grid.view;
    float depth = -((_e12 * metal::float4(world_1, 1.0)).z);
    uint2 loop_bound_2 = uint2(4294967295u);
    bool loop_init_2 = true;
    while(true) {
        if (metal::all(loop_bound_2 == uint2(0u))) { break; }
        loop_bound_2 -= uint2(loop_bound_2.y == 0u, 1u);
        if (!loop_init_2) {
            uint _e66 = i;
            i = _e66 + 1u;
        }
        loop_init_2 = false;
        uint _e20 = i;
        if (_e20 < 4u) {
        } else {
            break;
        }
        {
            uint _e25 = i;
            metal::float4 params = shadow_data.cascades.inner[metal::min(unsigned(base_2 + _e25), 15u)].parameters;
            if (depth <= params.x) {
                local_5 = params.x > 0.0;
            } else {
                local_5 = false;
            }
            bool _e38 = local_5;
            if (_e38) {
                uint _e39 = i;
                float _e41 = sample_cascade(base_2 + _e39, world_1, n_2, shadow_maps, shadow_sampler, shadow_data);
                if (depth <= params.y) {
                    return _e41;
                }
                next = 1.0;
                uint _e46 = i;
                if (_e46 < 3u) {
                    uint _e49 = i;
                    float _e53 = sample_cascade((base_2 + _e49) + 1u, world_1, n_2, shadow_maps, shadow_sampler, shadow_data);
                    next = _e53;
                }
                float _e54 = next;
                return metal::mix(_e41, _e54, metal::clamp((depth - params.y) / (params.x - params.y), 0.0, 1.0));
            }
        }
    }
    return 1.0;
}

metal::float3 unit(
    metal::float3 v
) {
    return v * metal::rsqrt(metal::max(metal::dot(v, v), 0.0000000000000001));
}

metal::float3 shade_light(
    Light light,
    metal::float3 world_2,
    metal::float3 n_3,
    metal::float3 v_1,
    metal::float3 base,
    float metallic,
    float roughness
) {
    metal::float3 l = {};
    float attenuation = 1.0;
    l = -(light.direction_outer.xyz);
    if (light.kind.x != 0u) {
        metal::float3 delta = light.position_range.xyz - world_2;
        float distance2_ = metal::dot(delta, delta);
        float range2_ = light.position_range.w * light.position_range.w;
        if (distance2_ >= range2_) {
            return metal::float3(0.0);
        }
        metal::float3 _e29 = unit(delta);
        l = _e29;
        float ratio2_ = distance2_ / range2_;
        float window = metal::max(1.0 - (ratio2_ * ratio2_), 0.0);
        attenuation = (window * window) / metal::max(distance2_, 0.0001);
        if (light.kind.x == 2u) {
            metal::float3 _e44 = l;
            float cosine = metal::dot(-(_e44), light.direction_outer.xyz);
            float cone = metal::clamp((cosine - light.direction_outer.w) / (light.radiance_inner.w - light.direction_outer.w), 0.0, 1.0);
            float _e61 = attenuation;
            attenuation = _e61 * (cone * cone);
        }
    }
    metal::float3 _e64 = l;
    metal::float3 _e66 = unit(v_1 + _e64);
    float nv = metal::max(metal::dot(n_3, v_1), 0.0);
    metal::float3 _e70 = l;
    float nl = metal::max(metal::dot(n_3, _e70), 0.0);
    float nh = metal::max(metal::dot(n_3, _e66), 0.0);
    float vh = metal::max(metal::dot(v_1, _e66), 0.0);
    float a2_ = ((roughness * roughness) * roughness) * roughness;
    float denominator = ((nh * nh) * (a2_ - 1.0)) + 1.0;
    float distribution = a2_ / ((3.1415927 * denominator) * denominator);
    float visibility = 0.5 / metal::max((nl * metal::sqrt(((nv * nv) * (1.0 - a2_)) + a2_)) + (nv * metal::sqrt(((nl * nl) * (1.0 - a2_)) + a2_)), 0.0000001);
    metal::float3 f0_ = metal::mix(metal::float3(0.04), base, metallic);
    metal::float3 fresnel = f0_ + ((metal::float3(1.0) - f0_) * metal::pow(1.0 - vh, 5.0));
    metal::float3 diffuse = (((metal::float3(1.0) - fresnel) * (1.0 - metallic)) * base) / metal::float3(3.1415927);
    float _e140 = attenuation;
    return ((diffuse + ((distribution * visibility) * fresnel)) * light.radiance_inner.xyz) * (nl * _e140);
}

metal::uint2 naga_f2u32(metal::float2 value) {
    return static_cast<metal::uint2>(metal::clamp(value, 0.0, 4294967000.0));
}

uint naga_f2u32(float value) {
    return static_cast<uint>(metal::clamp(value, 0.0, 4294967000.0));
}

metal::float3 direct_lighting(
    metal::float2 pixel,
    metal::float3 world_3,
    metal::float3 n_4,
    metal::float3 surface_normal_1,
    metal::float3 v_2,
    metal::float3 base_1,
    float metallic_1,
    float roughness_1,
    metal::depth2d_array<float, metal::access::sample> shadow_maps,
    metal::sampler shadow_sampler,
    constant ShadowData& shadow_data,
    constant LightGrid& light_grid,
    device type_12 const& punctual_lights,
    device type_13 const& cluster_counts,
    device type_13 const& cluster_masks,
    constant _mslBufferSizes& _buffer_sizes
) {
    metal::float3 radiance = metal::float3(0.0);
    uint i_1 = 0u;
    uint i_2 = {};
    uint word = 0u;
    uint mask = {};
    uint2 loop_bound_3 = uint2(4294967295u);
    bool loop_init_3 = true;
    while(true) {
        if (metal::all(loop_bound_3 == uint2(0u))) { break; }
        loop_bound_3 -= uint2(loop_bound_3.y == 0u, 1u);
        if (!loop_init_3) {
            uint _e35 = i_1;
            i_1 = _e35 + 1u;
        }
        loop_init_3 = false;
        uint _e13 = i_1;
        uint _e17 = light_grid.lights.x;
        if (_e13 < _e17) {
        } else {
            break;
        }
        {
            metal::float3 _e19 = radiance;
            uint _e21 = i_1;
            Light _e23 = punctual_lights[metal::min(unsigned(_e21), (_buffer_sizes.size4 - 0 - 64) / 64)];
            metal::float3 _e24 = shade_light(_e23, world_3, n_4, v_2, base_1, metallic_1, roughness_1);
            uint _e26 = i_1;
            uint _e30 = punctual_lights[metal::min(unsigned(_e26), (_buffer_sizes.size4 - 0 - 64) / 64)].kind.y;
            float _e31 = directional_shadow(_e30, world_3, surface_normal_1, shadow_maps, shadow_sampler, shadow_data, light_grid);
            radiance = _e19 + (_e24 * _e31);
        }
    }
    uint _e40 = light_grid.lights.y;
    if (_e40 == 0u) {
        metal::float3 _e43 = radiance;
        return _e43;
    }
    uint _e47 = light_grid.lights.z;
    if (_e47 != 0u) {
        uint _e53 = light_grid.lights.x;
        i_2 = _e53;
        uint2 loop_bound_4 = uint2(4294967295u);
        bool loop_init_4 = true;
        while(true) {
            if (metal::all(loop_bound_4 == uint2(0u))) { break; }
            loop_bound_4 -= uint2(loop_bound_4.y == 0u, 1u);
            if (!loop_init_4) {
                uint _e74 = i_2;
                i_2 = _e74 + 1u;
            }
            loop_init_4 = false;
            uint _e55 = i_2;
            uint _e59 = light_grid.lights.x;
            uint _e63 = light_grid.lights.y;
            if (_e55 < (_e59 + _e63)) {
            } else {
                break;
            }
            {
                metal::float3 _e66 = radiance;
                uint _e68 = i_2;
                Light _e70 = punctual_lights[metal::min(unsigned(_e68), (_buffer_sizes.size4 - 0 - 64) / 64)];
                metal::float3 _e71 = shade_light(_e70, world_3, n_4, v_2, base_1, metallic_1, roughness_1);
                radiance = _e66 + _e71;
            }
        }
        metal::float3 _e76 = radiance;
        return _e76;
    }
    metal::float4 _e79 = light_grid.viewport;
    metal::uint4 _e91 = light_grid.dimensions;
    metal::uint2 xy = metal::min(naga_f2u32(metal::max(pixel - _e79.xy, metal::float2(0.0)) / metal::float2(64.0)), _e91.xy - metal::uint2(1u));
    metal::float4x4 _e99 = light_grid.view;
    float _e108 = light_grid.depth.x;
    float depth_1 = metal::max(-((_e99 * metal::float4(world_3, 1.0)).z), _e108);
    float _e113 = light_grid.depth.x;
    float _e119 = light_grid.depth.z;
    uint _e127 = light_grid.dimensions.z;
    uint z = metal::min(naga_f2u32(metal::max(metal::log(depth_1 / _e113) * _e119, 0.0)), _e127 - 1u);
    uint _e134 = light_grid.dimensions.y;
    uint _e141 = light_grid.dimensions.x;
    uint cluster = (((z * _e134) + xy.y) * _e141) + xy.x;
    uint _e147 = cluster_counts[metal::min(unsigned(cluster), (_buffer_sizes.size5 - 0 - 4) / 4)];
    if (_e147 == 0u) {
        metal::float3 _e150 = radiance;
        return _e150;
    }
    uint2 loop_bound_5 = uint2(4294967295u);
    bool loop_init_5 = true;
    while(true) {
        if (metal::all(loop_bound_5 == uint2(0u))) { break; }
        loop_bound_5 -= uint2(loop_bound_5.y == 0u, 1u);
        if (!loop_init_5) {
            uint _e196 = word;
            word = _e196 + 1u;
        }
        loop_init_5 = false;
        uint _e153 = word;
        uint _e157 = light_grid.dimensions.w;
        if (_e153 < _e157) {
        } else {
            break;
        }
        {
            uint _e163 = light_grid.dimensions.w;
            uint _e165 = word;
            uint _e168 = cluster_masks[metal::min(unsigned((cluster * _e163) + _e165), (_buffer_sizes.size6 - 0 - 4) / 4)];
            mask = _e168;
            uint2 loop_bound_6 = uint2(4294967295u);
            while(true) {
                if (metal::all(loop_bound_6 == uint2(0u))) { break; }
                loop_bound_6 -= uint2(loop_bound_6.y == 0u, 1u);
                uint _e170 = mask;
                if (_e170 != 0u) {
                } else {
                    break;
                }
                {
                    uint _e176 = light_grid.lights.x;
                    uint _e177 = word;
                    uint _e181 = mask;
                    uint index_1 = (_e176 + (_e177 * 32u)) + (((metal::ctz(_e181) + 1) % 33) - 1);
                    metal::float3 _e184 = radiance;
                    Light _e187 = punctual_lights[metal::min(unsigned(index_1), (_buffer_sizes.size4 - 0 - 64) / 64)];
                    metal::float3 _e188 = shade_light(_e187, world_3, n_4, v_2, base_1, metallic_1, roughness_1);
                    radiance = _e184 + _e188;
                    uint _e190 = mask;
                    uint _e191 = mask;
                    mask = _e190 & (_e191 - 1u);
                }
            }
        }
    }
    metal::float3 _e198 = radiance;
    return _e198;
}

metal::float3 environment_direction(
    metal::float3 d,
    constant Frame& frame
) {
    float c = frame.environment.y;
    float s = frame.environment.z;
    return metal::float3((c * d.x) - (s * d.z), d.y, (s * d.x) + (c * d.z));
}

struct fragment_Input {
    metal::float3 world [[user(loc0), center_perspective]];
    metal::float3 normal [[user(loc1), center_perspective]];
    metal::float4 tangent [[user(loc2), center_perspective]];
    metal::float2 uv [[user(loc3), center_perspective]];
};
struct fragment_Output {
    metal::float4 member [[color(0)]];
};
fragment fragment_Output fragment_(
  fragment_Input varyings [[stage_in]]
, metal::float4 position [[position]]
, bool front [[front_facing]]
, metal::depth2d_array<float, metal::access::sample> shadow_maps [[texture(8)]]
, metal::sampler shadow_sampler [[sampler(6)]]
, constant ShadowData& shadow_data [[buffer(6)]]
, constant LightGrid& light_grid [[buffer(2)]]
, device type_12 const& punctual_lights [[buffer(3)]]
, device type_13 const& cluster_counts [[buffer(4)]]
, device type_13 const& cluster_masks [[buffer(5)]]
, constant Frame& frame [[buffer(0)]]
, constant Material& material [[buffer(1)]]
, metal::texture2d<float, metal::access::sample> base_map [[texture(0)]]
, metal::sampler base_sampler [[sampler(0)]]
, metal::texture2d<float, metal::access::sample> mr_map [[texture(1)]]
, metal::sampler mr_sampler [[sampler(1)]]
, metal::texture2d<float, metal::access::sample> normal_map [[texture(2)]]
, metal::sampler normal_sampler [[sampler(2)]]
, metal::texture2d<float, metal::access::sample> occlusion_map [[texture(3)]]
, metal::sampler occlusion_sampler [[sampler(3)]]
, metal::texture2d<float, metal::access::sample> emissive_map [[texture(4)]]
, metal::sampler emissive_sampler [[sampler(4)]]
, metal::texturecube<float, metal::access::sample> specular_environment [[texture(5)]]
, metal::texturecube<float, metal::access::sample> diffuse_environment [[texture(6)]]
, metal::texture2d<float, metal::access::sample> brdf_lut [[texture(7)]]
, metal::sampler environment_sampler [[sampler(5)]]
, constant _mslBufferSizes& _buffer_sizes [[buffer(7)]]
) {
    const VertexOut in = { position, varyings.world, varyings.normal, varyings.tangent, varyings.uv };
    bool local = {};
    metal::float3 surface_normal = {};
    metal::float3 n = {};
    bool local_1 = {};
    metal::float4 _e4 = material.base;
    metal::float4 _e8 = base_map.sample(base_sampler, in.uv);
    metal::float4 base_3 = _e4 * _e8;
    metal::float4 mr = mr_map.sample(mr_sampler, in.uv);
    metal::float4 _e17 = normal_map.sample(normal_sampler, in.uv);
    metal::float3 normal_sample = (_e17.xyz * 2.0) - metal::float3(1.0);
    float _e27 = material.factors.z;
    metal::float4 _e31 = occlusion_map.sample(occlusion_sampler, in.uv);
    float occlusion = 1.0 + (_e27 * (_e31.x - 1.0));
    metal::float4 _e40 = material.emissive_roughness;
    metal::float4 _e45 = emissive_map.sample(emissive_sampler, in.uv);
    metal::float3 emissive = _e40.xyz * _e45.xyz;
    uint _e51 = material.flags.x;
    if (_e51 == 1u) {
        float _e60 = material.factors.w;
        local = base_3.w < _e60;
    } else {
        local = false;
    }
    bool _e63 = local;
    if (_e63) {
        metal::discard_fragment();
    }
    metal::float3 _e65 = unit(in.normal);
    surface_normal = _e65;
    metal::float3 _e67 = surface_normal;
    n = _e67;
    uint _e72 = material.flags.y;
    if (_e72 != 0u) {
        metal::float3 _e77 = n;
        metal::float3 _e78 = n;
        metal::float3 _e84 = unit(in.tangent.xyz - (_e77 * metal::dot(_e78, in.tangent.xyz)));
        metal::float3 _e85 = n;
        metal::float3 b = metal::cross(_e85, _e84) * in.tangent.w;
        float _e93 = material.factors.y;
        float _e97 = material.factors.y;
        metal::float3 _e101 = unit(normal_sample * metal::float3(_e93, _e97, 1.0));
        metal::float3 _e102 = n;
        metal::float3 _e105 = unit(metal::float3x3(_e84, b, _e102) * _e101);
        n = _e105;
    }
    uint _e109 = material.flags.z;
    if (_e109 != 0u) {
        local_1 = !(front);
    } else {
        local_1 = false;
    }
    bool _e116 = local_1;
    if (_e116) {
        metal::float3 _e117 = n;
        n = -(_e117);
        metal::float3 _e119 = surface_normal;
        surface_normal = -(_e119);
    }
    metal::float4 _e123 = frame.eye;
    float _e129 = frame.eye.w;
    metal::float3 _e132 = unit(_e123.xyz - (in.world * _e129));
    metal::float3 _e133 = n;
    float nv_1 = metal::max(metal::dot(_e133, _e132), 0.0);
    float _e140 = material.factors.x;
    float metallic_2 = metal::clamp(_e140 * mr.z, 0.0, 1.0);
    float _e149 = material.emissive_roughness.w;
    float roughness_2 = metal::clamp(_e149 * mr.y, 0.045, 1.0);
    metal::float3 f0_1 = metal::mix(metal::float3(0.04), base_3.xyz, metallic_2);
    metal::float3 _e162 = n;
    metal::float3 _e163 = surface_normal;
    metal::float3 _e165 = direct_lighting(in.position.xy, in.world, _e162, _e163, _e132, base_3.xyz, metallic_2, roughness_2, shadow_maps, shadow_sampler, shadow_data, light_grid, punctual_lights, cluster_counts, cluster_masks, _buffer_sizes);
    metal::float4 _e170 = brdf_lut.sample(environment_sampler, metal::float2(nv_1, roughness_2), metal::level(0.0));
    metal::float2 dfg = _e170.xy;
    metal::float3 reflectance = (f0_1 * dfg.x) + metal::float3(dfg.y);
    metal::float3 _e179 = n;
    metal::float3 _e180 = environment_direction(_e179, frame);
    metal::float4 _e182 = diffuse_environment.sample(environment_sampler, _e180, metal::level(0.0));
    metal::float3 irradiance = _e182.xyz;
    metal::float3 _e187 = n;
    metal::float3 _e189 = environment_direction(metal::reflect(-(_e132), _e187), frame);
    float _e193 = frame.environment.w;
    metal::float4 _e195 = specular_environment.sample(environment_sampler, _e189, metal::level(roughness_2 * _e193));
    metal::float3 reflected = _e195.xyz;
    float _e211 = frame.environment.x;
    metal::float3 indirect = ((((((metal::float3(1.0) - reflectance) * (1.0 - metallic_2)) * base_3.xyz) * irradiance) + (reflectance * reflected)) * _e211) * occlusion;
    metal::float3 color = metal::clamp((_e165 + indirect) + emissive, metal::float3(0.0), metal::float3(65504.0));
    uint _e225 = material.flags.x;
    return fragment_Output { metal::float4(color, (_e225 == 2u) ? base_3.w : 1.0) };
}
