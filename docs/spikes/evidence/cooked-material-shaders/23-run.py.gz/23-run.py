import subprocess,os,json,time,hashlib,datetime
from pathlib import Path
root=Path('/Users/andreyyurlov/.codex/worktrees/native-audio-host/incant');out=Path(__file__).parent
freeze=Path('/Users/andreyyurlov/.codex/incant-evidence/cooked-material-source-001/freeze.json');m=json.loads(freeze.read_text());h=lambda b:hashlib.sha256(b).hexdigest()
def check():
 for r in m['sources']: assert h((root/r['path']).read_bytes())==r['sha256'],r['path']
env=dict(os.environ,CARGO_TARGET_DIR='/Users/andreyyurlov/.codex/incant-physics-variant-target',INCANT_MATERIAL_COOK_EVIDENCE=str(out/'artifacts'))
features='incant_render/cooked-output,incant_render/cooked-geometry,incant_render/cooked-sprites,incant_render/cooked-ui,incant_render/cooked-text,incant_render/cooked-materials'
commands=[['./tools/cargo','test','--locked','--profile','ci','-j2','-p','incant_shader_cook','-p','incant_render','--features',features],['./tools/cargo','clippy','--locked','--profile','ci','-j2','-p','incant_shader_cook','-p','incant_render','--features',features,'--all-targets','--','-D','warnings'],['./tools/cargo','test','--locked','--profile','ci','-j2','-p','incant_render','--lib'],['./tools/cargo','check','--locked','--profile','ci','-j2','-p','incant_render','--target','wasm32-unknown-unknown','--features',features],['./tools/cargo','fmt','--all','--check'],['python3','tools/generate_conventions.py','--check'],['git','diff','--check']]
records=[]
for i,args in enumerate(commands):
 check();start=time.time();label=f'{i:02d}';print(label,' '.join(args),flush=True)
 with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:r=subprocess.run(args,cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=1200)
 check();records.append({'argv':args,'exit':r.returncode,'seconds':time.time()-start,'stdout_sha256':h((out/(label+'.stdout')).read_bytes()),'stderr_sha256':h((out/(label+'.stderr')).read_bytes())});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(label,'exit',r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
(out/'complete.json').write_text(json.dumps({'passed':True,'freeze_sha256':h(freeze.read_bytes()),'commands':len(records),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
