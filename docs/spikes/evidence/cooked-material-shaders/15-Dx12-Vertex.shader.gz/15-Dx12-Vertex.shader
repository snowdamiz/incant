struct NagaConstants {
    int first_vertex;
    int first_instance;
    uint other;
};
ConstantBuffer<NagaConstants> _NagaConstants: register(b5);

struct Frame {
    row_major float4x4 view_projection;
    float4 eye;
    float4 environment;
};

struct VertexOut {
    float4 position : SV_Position;
    float3 world : LOC0;
    float3 normal : LOC1;
    float4 tangent : LOC2;
    float2 uv : LOC3;
};

cbuffer frame : register(b0) { Frame frame; }

struct VertexOutput_vertex {
    float3 world : LOC0;
    float3 normal_1 : LOC1;
    float4 tangent_1 : LOC2;
    float2 uv_1 : LOC3;
    float4 position_1 : SV_Position;
};

VertexOutput_vertex vertex(float3 position : LOC0, float3 normal : LOC1, float4 w0_ : LOC2, float4 w1_ : LOC3, float4 w2_ : LOC4, float4 w3_ : LOC5, float4 n0_ : LOC6, float4 n1_ : LOC7, float4 n2_ : LOC8, float2 uv : LOC9, float4 tangent : LOC10)
{
    VertexOut out_ = (VertexOut)0;

    float4x4 world_1 = float4x4(w0_, w1_, w2_, w3_);
    float3x3 linear_ = float3x3(w0_.xyz, w1_.xyz, w2_.xyz);
    float4 p = mul(float4(position, 1.0), world_1);
    float4x4 _e23 = frame.view_projection;
    out_.position = mul(p, _e23);
    out_.world = p.xyz;
    out_.normal = mul(normal, float3x3(n0_.xyz, n1_.xyz, n2_.xyz));
    out_.tangent = float4(mul(tangent.xyz, linear_), (tangent.w * n0_.w));
    out_.uv = uv;
    VertexOut _e41 = out_;
    const VertexOut vertexout = _e41;
    const VertexOutput_vertex vertexout_1 = { vertexout.world, vertexout.normal, vertexout.tangent, vertexout.uv, vertexout.position };
    return vertexout_1;
}
