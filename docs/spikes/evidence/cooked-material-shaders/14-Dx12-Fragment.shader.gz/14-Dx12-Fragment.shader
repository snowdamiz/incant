struct NagaConstants {
    int first_vertex;
    int first_instance;
    uint other;
};
ConstantBuffer<NagaConstants> _NagaConstants: register(b5);

struct ShadowCascade {
    row_major float4x4 matrix_;
    float4 parameters;
};

struct ShadowData {
    ShadowCascade cascades[16];
};

struct LightGrid {
    row_major float4x4 view;
    float4 viewport;
    uint4 dimensions;
    float4 depth;
    uint4 lights;
};

struct Light {
    float4 position_range;
    float4 direction_outer;
    float4 radiance_inner;
    uint4 kind;
};

struct Frame {
    row_major float4x4 view_projection;
    float4 eye;
    float4 environment;
};

struct Material {
    float4 base;
    float4 emissive_roughness;
    float4 factors;
    uint4 flags;
};

struct VertexOut {
    float4 position : SV_Position;
    float3 world : LOC0;
    float3 normal : LOC1;
    float4 tangent : LOC2;
    float2 uv : LOC3;
};

Texture2DArray<float> shadow_maps : register(t13);
SamplerState nagaSamplerHeap[2048]: register(s0, space0);
SamplerComparisonState nagaComparisonSamplerHeap[2048]: register(s2048, space0);
StructuredBuffer<uint> nagaGroup3SamplerIndexArray : register(t14, space0);
static const SamplerComparisonState shadow_sampler = nagaComparisonSamplerHeap[nagaGroup3SamplerIndexArray[0]];
cbuffer shadow_data : register(b3) { ShadowData shadow_data; }
cbuffer light_grid : register(b2) { LightGrid light_grid; }
ByteAddressBuffer punctual_lights : register(t10);
ByteAddressBuffer cluster_counts : register(t11);
ByteAddressBuffer cluster_masks : register(t12);
cbuffer frame : register(b0) { Frame frame; }
cbuffer material : register(b1) { Material material; }
Texture2D<float4> base_map : register(t0);
StructuredBuffer<uint> nagaGroup1SamplerIndexArray : register(t5, space0);
static const SamplerState base_sampler = nagaSamplerHeap[nagaGroup1SamplerIndexArray[0]];
Texture2D<float4> mr_map : register(t1);
static const SamplerState mr_sampler = nagaSamplerHeap[nagaGroup1SamplerIndexArray[1]];
Texture2D<float4> normal_map : register(t2);
static const SamplerState normal_sampler = nagaSamplerHeap[nagaGroup1SamplerIndexArray[2]];
Texture2D<float4> occlusion_map : register(t3);
static const SamplerState occlusion_sampler = nagaSamplerHeap[nagaGroup1SamplerIndexArray[3]];
Texture2D<float4> emissive_map : register(t4);
static const SamplerState emissive_sampler = nagaSamplerHeap[nagaGroup1SamplerIndexArray[4]];
TextureCube<float4> specular_environment : register(t6);
TextureCube<float4> diffuse_environment : register(t7);
Texture2D<float4> brdf_lut : register(t8);
StructuredBuffer<uint> nagaGroup2SamplerIndexArray : register(t9, space0);
static const SamplerState environment_sampler = nagaSamplerHeap[nagaGroup2SamplerIndexArray[0]];

struct FragmentInput_fragment {
    float3 world_4 : LOC0;
    float3 normal : LOC1;
    float4 tangent : LOC2;
    float2 uv : LOC3;
    float4 position : SV_Position;
    bool front_1 : SV_IsFrontFace;
};

uint2 NagaDepthDimensions2DArray(Texture2DArray<float> tex)
{
    uint4 ret;
    tex.GetDimensions(0, ret.x, ret.y, ret.z, ret.w);
    return ret.xy;
}

float sample_cascade(uint index, float3 world, float3 n_1)
{
    bool local_2 = (bool)0;
    bool local_3 = (bool)0;
    bool local_4 = (bool)0;
    float sum = 0.0;
    int y = int(-1);
    int x = (int)0;

    ShadowCascade cascade = shadow_data.cascades[min(uint(index), 15u)];
    float4 p = mul(float4((world + ((n_1 * cascade.parameters.z) * 0.25)), 1.0), cascade.matrix_);
    float2 uv_1 = ((float2(p.x, -(p.y)) * 0.5) + (0.5).xx);
    if (!(any((uv_1 < (0.0).xx)))) {
        local_2 = any((uv_1 > (1.0).xx));
    } else {
        local_2 = true;
    }
    bool _e38 = local_2;
    if (!(_e38)) {
        local_3 = (p.z < 0.0);
    } else {
        local_3 = true;
    }
    bool _e46 = local_3;
    if (!(_e46)) {
        local_4 = (p.z > 1.0);
    } else {
        local_4 = true;
    }
    bool _e54 = local_4;
    if (_e54) {
        return 1.0;
    }
    float2 texel = ((1.0).xx / float2(NagaDepthDimensions2DArray(shadow_maps)));
    uint2 loop_bound = uint2(4294967295u, 4294967295u);
    bool loop_init = true;
    while(true) {
        if (all(loop_bound == uint2(0u, 0u))) { break; }
        loop_bound -= uint2(loop_bound.y == 0u, 1u);
        if (!loop_init) {
            int _e92 = y;
            y = asint(asuint(_e92) + asuint(int(1)));
        }
        loop_init = false;
        int _e66 = y;
        if ((_e66 <= int(1))) {
        } else {
            break;
        }
        {
            x = int(-1);
            uint2 loop_bound_1 = uint2(4294967295u, 4294967295u);
            bool loop_init_1 = true;
            while(true) {
                if (all(loop_bound_1 == uint2(0u, 0u))) { break; }
                loop_bound_1 -= uint2(loop_bound_1.y == 0u, 1u);
                if (!loop_init_1) {
                    int _e89 = x;
                    x = asint(asuint(_e89) + asuint(int(1)));
                }
                loop_init_1 = false;
                int _e71 = x;
                if ((_e71 <= int(1))) {
                } else {
                    break;
                }
                {
                    float _e74 = sum;
                    int _e77 = x;
                    int _e79 = y;
                    float _e86 = shadow_maps.SampleCmpLevelZero(shadow_sampler, float3((uv_1 + (float2(float(_e77), float(_e79)) * texel)), int(index)), p.z);
                    sum = (_e74 + _e86);
                }
            }
        }
    }
    float _e94 = sum;
    return (_e94 / 9.0);
}

float directional_shadow(uint slot, float3 world_1, float3 n_2)
{
    uint i = 0u;
    bool local_5 = (bool)0;
    float next = (float)0;

    if ((slot == 0u)) {
        return 1.0;
    }
    uint base_2 = ((slot - 1u) * 4u);
    float4x4 _e12 = light_grid.view;
    float depth = -(mul(float4(world_1, 1.0), _e12).z);
    uint2 loop_bound_2 = uint2(4294967295u, 4294967295u);
    bool loop_init_2 = true;
    while(true) {
        if (all(loop_bound_2 == uint2(0u, 0u))) { break; }
        loop_bound_2 -= uint2(loop_bound_2.y == 0u, 1u);
        if (!loop_init_2) {
            uint _e66 = i;
            i = (_e66 + 1u);
        }
        loop_init_2 = false;
        uint _e20 = i;
        if ((_e20 < 4u)) {
        } else {
            break;
        }
        {
            uint _e25 = i;
            float4 params = shadow_data.cascades[min(uint((base_2 + _e25)), 15u)].parameters;
            if ((depth <= params.x)) {
                local_5 = (params.x > 0.0);
            } else {
                local_5 = false;
            }
            bool _e38 = local_5;
            if (_e38) {
                uint _e39 = i;
                const float _e41 = sample_cascade((base_2 + _e39), world_1, n_2);
                if ((depth <= params.y)) {
                    return _e41;
                }
                next = 1.0;
                uint _e46 = i;
                if ((_e46 < 3u)) {
                    uint _e49 = i;
                    const float _e53 = sample_cascade(((base_2 + _e49) + 1u), world_1, n_2);
                    next = _e53;
                }
                float _e54 = next;
                return lerp(_e41, _e54, clamp(((depth - params.y) / (params.x - params.y)), 0.0, 1.0));
            }
        }
    }
    return 1.0;
}

float3 unit(float3 v)
{
    return (v * rsqrt(max(dot(v, v), 1e-16)));
}

float3 shade_light(Light light, float3 world_2, float3 n_3, float3 v_1, float3 base, float metallic, float roughness)
{
    float3 l = (float3)0;
    float attenuation = 1.0;

    l = -(light.direction_outer.xyz);
    if ((light.kind.x != 0u)) {
        float3 delta = (light.position_range.xyz - world_2);
        float distance2_ = dot(delta, delta);
        float range2_ = (light.position_range.w * light.position_range.w);
        if ((distance2_ >= range2_)) {
            return (0.0).xxx;
        }
        const float3 _e29 = unit(delta);
        l = _e29;
        float ratio2_ = (distance2_ / range2_);
        float window = max((1.0 - (ratio2_ * ratio2_)), 0.0);
        attenuation = ((window * window) / max(distance2_, 0.0001));
        if ((light.kind.x == 2u)) {
            float3 _e44 = l;
            float cosine = dot(-(_e44), light.direction_outer.xyz);
            float cone = clamp(((cosine - light.direction_outer.w) / (light.radiance_inner.w - light.direction_outer.w)), 0.0, 1.0);
            float _e61 = attenuation;
            attenuation = (_e61 * (cone * cone));
        }
    }
    float3 _e64 = l;
    const float3 _e66 = unit((v_1 + _e64));
    float nv = max(dot(n_3, v_1), 0.0);
    float3 _e70 = l;
    float nl = max(dot(n_3, _e70), 0.0);
    float nh = max(dot(n_3, _e66), 0.0);
    float vh = max(dot(v_1, _e66), 0.0);
    float a2_ = (((roughness * roughness) * roughness) * roughness);
    float denominator = (((nh * nh) * (a2_ - 1.0)) + 1.0);
    float distribution = (a2_ / ((3.1415927 * denominator) * denominator));
    float visibility = (0.5 / max(((nl * sqrt((((nv * nv) * (1.0 - a2_)) + a2_))) + (nv * sqrt((((nl * nl) * (1.0 - a2_)) + a2_)))), 1e-7));
    float3 f0_ = lerp((0.04).xxx, base, metallic);
    float3 fresnel = (f0_ + (((1.0).xxx - f0_) * pow((1.0 - vh), 5.0)));
    float3 diffuse = (((((1.0).xxx - fresnel) * (1.0 - metallic)) * base) / (3.1415927).xxx);
    float _e140 = attenuation;
    return (((diffuse + ((distribution * visibility) * fresnel)) * light.radiance_inner.xyz) * (nl * _e140));
}

uint2 naga_f2u32(float2 value) {
    return uint2(clamp(value, 0.0, 4294967000.0));
}

uint naga_f2u32(float value) {
    return uint(clamp(value, 0.0, 4294967000.0));
}

Light ConstructLight(float4 arg0, float4 arg1, float4 arg2, uint4 arg3) {
    Light ret = (Light)0;
    ret.position_range = arg0;
    ret.direction_outer = arg1;
    ret.radiance_inner = arg2;
    ret.kind = arg3;
    return ret;
}

float3 direct_lighting(float2 pixel, float3 world_3, float3 n_4, float3 surface_normal_1, float3 v_2, float3 base_1, float metallic_1, float roughness_1)
{
    float3 radiance = (0.0).xxx;
    uint i_1 = 0u;
    uint i_2 = (uint)0;
    uint word = 0u;
    uint mask = (uint)0;

    uint2 loop_bound_3 = uint2(4294967295u, 4294967295u);
    bool loop_init_3 = true;
    while(true) {
        if (all(loop_bound_3 == uint2(0u, 0u))) { break; }
        loop_bound_3 -= uint2(loop_bound_3.y == 0u, 1u);
        if (!loop_init_3) {
            uint _e35 = i_1;
            i_1 = (_e35 + 1u);
        }
        loop_init_3 = false;
        uint _e13 = i_1;
        uint _e17 = light_grid.lights.x;
        if ((_e13 < _e17)) {
        } else {
            break;
        }
        {
            float3 _e19 = radiance;
            uint _e21 = i_1;
            Light _e23 = ConstructLight(asfloat(punctual_lights.Load4(_e21*64+0)), asfloat(punctual_lights.Load4(_e21*64+16)), asfloat(punctual_lights.Load4(_e21*64+32)), asuint(punctual_lights.Load4(_e21*64+48)));
            const float3 _e24 = shade_light(_e23, world_3, n_4, v_2, base_1, metallic_1, roughness_1);
            uint _e26 = i_1;
            uint _e30 = asuint(punctual_lights.Load(4+48+_e26*64));
            const float _e31 = directional_shadow(_e30, world_3, surface_normal_1);
            radiance = (_e19 + (_e24 * _e31));
        }
    }
    uint _e40 = light_grid.lights.y;
    if ((_e40 == 0u)) {
        float3 _e43 = radiance;
        return _e43;
    }
    uint _e47 = light_grid.lights.z;
    if ((_e47 != 0u)) {
        uint _e53 = light_grid.lights.x;
        i_2 = _e53;
        uint2 loop_bound_4 = uint2(4294967295u, 4294967295u);
        bool loop_init_4 = true;
        while(true) {
            if (all(loop_bound_4 == uint2(0u, 0u))) { break; }
            loop_bound_4 -= uint2(loop_bound_4.y == 0u, 1u);
            if (!loop_init_4) {
                uint _e74 = i_2;
                i_2 = (_e74 + 1u);
            }
            loop_init_4 = false;
            uint _e55 = i_2;
            uint _e59 = light_grid.lights.x;
            uint _e63 = light_grid.lights.y;
            if ((_e55 < (_e59 + _e63))) {
            } else {
                break;
            }
            {
                float3 _e66 = radiance;
                uint _e68 = i_2;
                Light _e70 = ConstructLight(asfloat(punctual_lights.Load4(_e68*64+0)), asfloat(punctual_lights.Load4(_e68*64+16)), asfloat(punctual_lights.Load4(_e68*64+32)), asuint(punctual_lights.Load4(_e68*64+48)));
                const float3 _e71 = shade_light(_e70, world_3, n_4, v_2, base_1, metallic_1, roughness_1);
                radiance = (_e66 + _e71);
            }
        }
        float3 _e76 = radiance;
        return _e76;
    }
    float4 _e79 = light_grid.viewport;
    uint4 _e91 = light_grid.dimensions;
    uint2 xy = min(naga_f2u32((max((pixel - _e79.xy), (0.0).xx) / (64.0).xx)), (_e91.xy - (1u).xx));
    float4x4 _e99 = light_grid.view;
    float _e108 = light_grid.depth.x;
    float depth_1 = max(-(mul(float4(world_3, 1.0), _e99).z), _e108);
    float _e113 = light_grid.depth.x;
    float _e119 = light_grid.depth.z;
    uint _e127 = light_grid.dimensions.z;
    uint z = min(naga_f2u32(max((log((depth_1 / _e113)) * _e119), 0.0)), (_e127 - 1u));
    uint _e134 = light_grid.dimensions.y;
    uint _e141 = light_grid.dimensions.x;
    uint cluster = ((((z * _e134) + xy.y) * _e141) + xy.x);
    uint _e147 = asuint(cluster_counts.Load(cluster*4));
    if ((_e147 == 0u)) {
        float3 _e150 = radiance;
        return _e150;
    }
    uint2 loop_bound_5 = uint2(4294967295u, 4294967295u);
    bool loop_init_5 = true;
    while(true) {
        if (all(loop_bound_5 == uint2(0u, 0u))) { break; }
        loop_bound_5 -= uint2(loop_bound_5.y == 0u, 1u);
        if (!loop_init_5) {
            uint _e196 = word;
            word = (_e196 + 1u);
        }
        loop_init_5 = false;
        uint _e153 = word;
        uint _e157 = light_grid.dimensions.w;
        if ((_e153 < _e157)) {
        } else {
            break;
        }
        {
            uint _e163 = light_grid.dimensions.w;
            uint _e165 = word;
            uint _e168 = asuint(cluster_masks.Load(((cluster * _e163) + _e165)*4));
            mask = _e168;
            uint2 loop_bound_6 = uint2(4294967295u, 4294967295u);
            while(true) {
                if (all(loop_bound_6 == uint2(0u, 0u))) { break; }
                loop_bound_6 -= uint2(loop_bound_6.y == 0u, 1u);
                uint _e170 = mask;
                if ((_e170 != 0u)) {
                } else {
                    break;
                }
                {
                    uint _e176 = light_grid.lights.x;
                    uint _e177 = word;
                    uint _e181 = mask;
                    uint index_1 = ((_e176 + (_e177 * 32u)) + firstbitlow(_e181));
                    float3 _e184 = radiance;
                    Light _e187 = ConstructLight(asfloat(punctual_lights.Load4(index_1*64+0)), asfloat(punctual_lights.Load4(index_1*64+16)), asfloat(punctual_lights.Load4(index_1*64+32)), asuint(punctual_lights.Load4(index_1*64+48)));
                    const float3 _e188 = shade_light(_e187, world_3, n_4, v_2, base_1, metallic_1, roughness_1);
                    radiance = (_e184 + _e188);
                    uint _e190 = mask;
                    uint _e191 = mask;
                    mask = (_e190 & (_e191 - 1u));
                }
            }
        }
    }
    float3 _e198 = radiance;
    return _e198;
}

float3 environment_direction(float3 d)
{
    float c = frame.environment.y;
    float s = frame.environment.z;
    return float3(((c * d.x) - (s * d.z)), d.y, ((s * d.x) + (c * d.z)));
}

float4 fragment(FragmentInput_fragment fragmentinput_fragment) : SV_Target0
{
    VertexOut in_ = { fragmentinput_fragment.position, fragmentinput_fragment.world_4, fragmentinput_fragment.normal, fragmentinput_fragment.tangent, fragmentinput_fragment.uv };
    bool front = fragmentinput_fragment.front_1;
    bool local = (bool)0;
    float3 surface_normal = (float3)0;
    float3 n = (float3)0;
    bool local_1 = (bool)0;

    float4 _e4 = material.base;
    float4 _e8 = base_map.Sample(base_sampler, in_.uv);
    float4 base_3 = (_e4 * _e8);
    float4 mr = mr_map.Sample(mr_sampler, in_.uv);
    float4 _e17 = normal_map.Sample(normal_sampler, in_.uv);
    float3 normal_sample = ((_e17.xyz * 2.0) - (1.0).xxx);
    float _e27 = material.factors.z;
    float4 _e31 = occlusion_map.Sample(occlusion_sampler, in_.uv);
    float occlusion = (1.0 + (_e27 * (_e31.x - 1.0)));
    float4 _e40 = material.emissive_roughness;
    float4 _e45 = emissive_map.Sample(emissive_sampler, in_.uv);
    float3 emissive = (_e40.xyz * _e45.xyz);
    uint _e51 = material.flags.x;
    if ((_e51 == 1u)) {
        float _e60 = material.factors.w;
        local = (base_3.w < _e60);
    } else {
        local = false;
    }
    bool _e63 = local;
    if (_e63) {
        discard;
    }
    const float3 _e65 = unit(in_.normal);
    surface_normal = _e65;
    float3 _e67 = surface_normal;
    n = _e67;
    uint _e72 = material.flags.y;
    if ((_e72 != 0u)) {
        float3 _e77 = n;
        float3 _e78 = n;
        const float3 _e84 = unit((in_.tangent.xyz - (_e77 * dot(_e78, in_.tangent.xyz))));
        float3 _e85 = n;
        float3 b = (cross(_e85, _e84) * in_.tangent.w);
        float _e93 = material.factors.y;
        float _e97 = material.factors.y;
        const float3 _e101 = unit((normal_sample * float3(_e93, _e97, 1.0)));
        float3 _e102 = n;
        const float3 _e105 = unit(mul(_e101, float3x3(_e84, b, _e102)));
        n = _e105;
    }
    uint _e109 = material.flags.z;
    if ((_e109 != 0u)) {
        local_1 = !(front);
    } else {
        local_1 = false;
    }
    bool _e116 = local_1;
    if (_e116) {
        float3 _e117 = n;
        n = -(_e117);
        float3 _e119 = surface_normal;
        surface_normal = -(_e119);
    }
    float4 _e123 = frame.eye;
    float _e129 = frame.eye.w;
    const float3 _e132 = unit((_e123.xyz - (in_.world * _e129)));
    float3 _e133 = n;
    float nv_1 = max(dot(_e133, _e132), 0.0);
    float _e140 = material.factors.x;
    float metallic_2 = clamp((_e140 * mr.z), 0.0, 1.0);
    float _e149 = material.emissive_roughness.w;
    float roughness_2 = clamp((_e149 * mr.y), 0.045, 1.0);
    float3 f0_1 = lerp((0.04).xxx, base_3.xyz, metallic_2);
    float3 _e162 = n;
    float3 _e163 = surface_normal;
    const float3 _e165 = direct_lighting(in_.position.xy, in_.world, _e162, _e163, _e132, base_3.xyz, metallic_2, roughness_2);
    float4 _e170 = brdf_lut.SampleLevel(environment_sampler, float2(nv_1, roughness_2), 0.0);
    float2 dfg = _e170.xy;
    float3 reflectance = ((f0_1 * dfg.x) + (dfg.y).xxx);
    float3 _e179 = n;
    const float3 _e180 = environment_direction(_e179);
    float4 _e182 = diffuse_environment.SampleLevel(environment_sampler, _e180, 0.0);
    float3 irradiance = _e182.xyz;
    float3 _e187 = n;
    const float3 _e189 = environment_direction(reflect(-(_e132), _e187));
    float _e193 = frame.environment.w;
    float4 _e195 = specular_environment.SampleLevel(environment_sampler, _e189, (roughness_2 * _e193));
    float3 reflected = _e195.xyz;
    float _e211 = frame.environment.x;
    float3 indirect = ((((((((1.0).xxx - reflectance) * (1.0 - metallic_2)) * base_3.xyz) * irradiance) + (reflectance * reflected)) * _e211) * occlusion);
    float3 color = clamp(((_e165 + indirect) + emissive), (0.0).xxx, (65504.0).xxx);
    uint _e225 = material.flags.x;
    return float4(color, ((_e225 == 2u) ? base_3.w : 1.0));
}
