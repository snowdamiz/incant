from pathlib import Path
import sys,os,json,hashlib,time
root=Path('/Users/andreyyurlov/.codex/worktrees/native-audio-host/incant');out=Path('/Users/andreyyurlov/.codex/incant-evidence/physics-mode-admission-001')
sys.path.insert(0,str(root/'tools'))
from native_process import run
env=dict(os.environ,CARGO_TARGET_DIR='/Users/andreyyurlov/.codex/incant-physics-variant-target');rows=[];code=0
for name,flags in [('deterministic',[]),('fast',['--no-default-features']),('fast-simd8',['--no-default-features','--features','physics-fast-simd8'])]:
 argv=[str(root/'tools/cargo'),'test','--locked','--profile','ci','--target','aarch64-apple-darwin','-j2','-p','incant_runtime','--message-format=json',*flags];start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:r=run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr,text=False,timeout=2400)
 row={'name':name,'argv':argv,'exit_code':r.returncode,'seconds':time.monotonic()-start}
 for stream in ['stdout','stderr']:
  path=out/(name+'.'+stream);row[stream]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:code=r.returncode;break
freeze=json.loads((out/'freeze.json').read_text());changed=[p for p,h in freeze.items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h]
(out/'terminal.json').write_text(json.dumps({'exit_code':code,'changed':changed,'frozen_files':len(freeze)},indent=2)+'\n');sys.exit(code or bool(changed))
