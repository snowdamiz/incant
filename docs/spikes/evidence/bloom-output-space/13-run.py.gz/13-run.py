from pathlib import Path
import json,subprocess,os,time,hashlib,datetime
root=Path('/Users/andreyyurlov/.codex/worktrees/native-fbx-import/incant');out=Path(__file__).parent;target=Path('/tmp/incant-dynamic-resolution-target');env=dict(os.environ);env['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/opt/homebrew/bin:'+env['PATH'];env['CARGO_TARGET_DIR']=str(target)
freeze=json.loads((out/'source-001/freeze.json').read_text());rows=[]
def verify():
 for row in freeze['files']:assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
def run(name,args):
 verify();log=out/(name+'.log');start=time.time()
 with log.open('wb') as stream:p=subprocess.run(args,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
 row={'name':name,'argv':args,'exit':p.returncode,'seconds':time.time()-start,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()};rows.append(row);(out/'results.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'target':str(target),'checks':rows},indent=2)+'\n');print(json.dumps(row),flush=True);verify()
 if p.returncode:raise SystemExit(p.returncode)
# New checkout owner: discard only workspace products, preserving registry dependencies.
meta=json.loads(Path('/tmp/bloom-workspace-metadata.json').read_text());ids=set(meta['workspace_members']);names=[p['name'] for p in meta['packages'] if p['id'] in ids]
run('00-workspace-target-clean',['cargo','clean','--profile','ci']+[a for n in names for a in ['-p',n]])
run('01-render-cpu',['cargo','test','-p','incant_render','--lib','--profile','ci','--locked','-j2','--','--nocapture'])
run('02-render-clippy',['cargo','clippy','-p','incant_render','--all-targets','--profile','ci','--locked','-j2','--','-D','warnings'])
run('03-render-web',['cargo','check','-p','incant_render','--lib','--target','wasm32-unknown-unknown','--profile','ci','--locked','-j2'])
run('04-cooked-refusal',['cargo','test','-p','incant_render','--lib','--features','cooked-output','--profile','ci','--locked','-j2','bloom::tests::typed_admission_rejects_invalid_and_cooked_output_before_device_use','--','--exact','--nocapture'])
run('05-format',['cargo','fmt','--all','--','--check'])
run('06-conventions',['python3','tools/generate_conventions.py','--check'])
run('07-diff',['git','diff','--check'])
