use crate::texture::{ImageRole, import_image_role};
use crate::{AssetError, MAX_SOURCE_BYTES, Result, SourceSet, Texture, invalid};
use std::{
    collections::{BTreeMap, BTreeSet},
    path::Path,
};

pub use incant_assets_runtime::ModelTexture;
pub(crate) fn import_textures(
    doc: &gltf::Document,
    buffers: &[Vec<u8>],
    sources: &mut SourceSet,
    source: &Path,
) -> Result<(Vec<ModelTexture>, Vec<Texture>)> {
    if doc.images().len() > 256 || doc.textures().len() > 1024 {
        return Err(AssetError::Limit("model textures"));
    }
    let mut usage = vec![BTreeSet::new(); doc.textures().len()];
    let mut mark = |index: usize, coord: u32, kind: ImageRole| -> Result<()> {
        if coord != 0 {
            return Err(AssetError::Unsupported(
                "texture coordinate set beyond UV0".into(),
            ));
        }
        usage[index].insert(kind);
        Ok(())
    };
    for material in doc.materials() {
        let pbr = material.pbr_metallic_roughness();
        if let Some(info) = pbr.base_color_texture() {
            let role = if material.alpha_mode() == gltf::material::AlphaMode::Opaque {
                ImageRole::ColorUnweighted
            } else {
                ImageRole::ColorCoverage
            };
            mark(info.texture().index(), info.tex_coord(), role)?;
        }
        if let Some(info) = material.emissive_texture() {
            mark(
                info.texture().index(),
                info.tex_coord(),
                ImageRole::ColorUnweighted,
            )?;
        }
        if let Some(info) = pbr.metallic_roughness_texture() {
            mark(info.texture().index(), info.tex_coord(), ImageRole::Linear)?;
        }
        if let Some(info) = material.occlusion_texture() {
            mark(info.texture().index(), info.tex_coord(), ImageRole::Linear)?;
        }
        if let Some(info) = material.normal_texture() {
            mark(info.texture().index(), info.tex_coord(), ImageRole::Normal)?;
        }
    }
    let mut encoded = Vec::new();
    let mut source_bytes = 0;
    for image in doc.images() {
        let data = match image.source() {
            gltf::image::Source::Uri { uri, .. } => sources.uri(source, uri)?,
            gltf::image::Source::View { view, .. } => buffers[view.buffer().index()]
                [view.offset()..view.offset() + view.length()]
                .to_vec(),
        };
        if !matches!(
            image::guess_format(&data),
            Ok(image::ImageFormat::Png | image::ImageFormat::Jpeg)
        ) {
            return Err(invalid("glTF images require PNG or JPEG"));
        }
        source_bytes += data.len();
        if source_bytes > MAX_SOURCE_BYTES {
            return Err(AssetError::Limit("model image source bytes"));
        }
        encoded.push(data);
    }
    let mut variants = BTreeMap::new();
    let mut images = Vec::new();
    let mut textures = Vec::new();
    let mut total_bytes = 0;
    for texture in doc.textures() {
        let sampler = texture.sampler();
        let mut record = ModelTexture {
            color: None,
            color_unweighted: None,
            linear: None,
            normal: None,
            mag_filter: sampler.mag_filter().map(|v| v.as_gl_enum()),
            min_filter: sampler.min_filter().map(|v| v.as_gl_enum()),
            wrap_s: sampler.wrap_s().as_gl_enum(),
            wrap_t: sampler.wrap_t().as_gl_enum(),
        };
        // Retain unused textures for subsequent material edits.
        if usage[texture.index()].is_empty() {
            usage[texture.index()].insert(ImageRole::Linear);
        }
        for &kind in &usage[texture.index()] {
            let key = (texture.source().index(), kind);
            let id = if let Some(&id) = variants.get(&key) {
                id
            } else {
                if images.len() >= 768 {
                    return Err(AssetError::Limit("model image variants"));
                }
                let mut image = import_image_role(&encoded[key.0], kind)?;
                let other = match kind {
                    ImageRole::ColorCoverage => Some(ImageRole::ColorUnweighted),
                    ImageRole::ColorUnweighted => Some(ImageRole::ColorCoverage),
                    _ => None,
                };
                if let Some(other) = other.and_then(|role| variants.get(&(key.0, role))) {
                    image.share_base_from(&images[*other])?;
                }
                total_bytes += image.payload_bytes();
                if total_bytes > MAX_SOURCE_BYTES {
                    return Err(AssetError::Limit("decoded model textures"));
                }
                let id = images.len();
                images.push(image);
                variants.insert(key, id);
                id
            };
            match kind {
                ImageRole::ColorCoverage => record.color = Some(id),
                ImageRole::ColorUnweighted => record.color_unweighted = Some(id),
                ImageRole::Linear => record.linear = Some(id),
                ImageRole::Normal => record.normal = Some(id),
            }
        }
        textures.push(record);
    }
    Ok((textures, images))
}
