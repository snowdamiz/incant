//! CPU asset import and cooking. No account, renderer or editor is required.
#[cfg(not(target_arch = "wasm32"))]
mod animation_cook;
mod atlas;
mod audio;
mod audio_cook;
mod cache;
#[cfg_attr(target_arch = "wasm32", path = "fbx_browser.rs")]
mod fbx;
mod font_cook;
mod gltf_animation;
mod gltf_import;
mod ktx;
mod material;
mod mesh;
mod navigation;
pub use navigation::model_navigation_geometry;
mod model_textures;
mod project_cache;
mod runtime;
mod source;
mod tangents;
mod texture;
mod texture_cache;

pub use audio::{AUDIO_CHUNK_FRAMES, AudioMetadata, CookedAudio, MAX_AUDIO_PCM_BYTES, load_audio};
pub use audio_cook::cook_audio;
pub use font_cook::cook_font;
pub use incant_assets_runtime::{CookedFont, FontMetadata, MAX_FONT_BYTES};
pub fn load_font(cache: &std::path::Path, fingerprint: &str) -> Result<CookedFont> {
    incant_assets_runtime::load_font(cache, fingerprint).map_err(Into::into)
}
pub use cache::{CookedModel, ModelMetadata, cook_fbx, cook_gltf, cook_model, load_model};
pub use fbx::import_fbx;
pub use gltf_import::{ImportedModel, ModelNode, import_gltf};
pub use ktx::{decode_ktx2, encode_ktx2};
pub use material::{AlphaMode, Material, MaterialTexture};
pub use mesh::{Mesh, Vertex, cook_mesh, decode_mesh};
pub use model_textures::ModelTexture;
pub use project_cache::{CacheKind, project_cache_directory};
pub use runtime::{
    AssetChanges, AssetStore, RuntimeAsset, RuntimeAssetData, RuntimeAssetError, RuntimeAssetInfo,
};
pub use source::{Dependency, SourceSet};
pub use texture::{Texture, TextureFormat, TextureUsage, import_image};
pub use texture_cache::{CookedTexture, TextureMetadata, cook_texture, load_texture};
use thiserror::Error;

pub use incant_assets_runtime::{MAX_INDICES, MAX_SOURCE_BYTES, MAX_VERTICES};

#[derive(Debug, Error)]
pub enum AssetError {
    #[error(transparent)]
    Atlas(#[from] incant_2d::atlas::AtlasError),
    #[error("asset IO: {0}")]
    Io(#[from] std::io::Error),
    #[error("invalid glTF: {0}")]
    Gltf(#[from] gltf::Error),
    #[error("invalid FBX: {0}")]
    Fbx(String),
    #[error("asset JSON: {0}")]
    Json(#[from] serde_json::Error),
    #[error("invalid asset: {0}")]
    Invalid(String),
    #[error("unsupported asset feature: {0}")]
    Unsupported(String),
    #[error("asset exceeds {0} limit")]
    Limit(&'static str),
}
pub type Result<T> = std::result::Result<T, AssetError>;
fn invalid(reason: impl Into<String>) -> AssetError {
    AssetError::Invalid(reason.into())
}
pub use incant_assets_runtime::sha256;
impl From<incant_assets_runtime::AssetError> for AssetError {
    fn from(error: incant_assets_runtime::AssetError) -> Self {
        match error {
            incant_assets_runtime::AssetError::Atlas(e) => Self::Atlas(e),
            incant_assets_runtime::AssetError::Io(e) => Self::Io(e),
            incant_assets_runtime::AssetError::Json(e) => Self::Json(e),
            incant_assets_runtime::AssetError::Invalid(e) => Self::Invalid(e),
            incant_assets_runtime::AssetError::Unsupported(e) => Self::Unsupported(e),
            incant_assets_runtime::AssetError::Limit(e) => Self::Limit(e),
        }
    }
}
