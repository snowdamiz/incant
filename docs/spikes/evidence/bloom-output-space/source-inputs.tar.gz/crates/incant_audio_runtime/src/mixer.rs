pub(crate) mod checkpoint;
use crate::{AudioError, Bus, PlayOptions, Result, config};
#[cfg(feature = "scene")]
pub(crate) use checkpoint::MixerCheckpoint;
pub(crate) use checkpoint::TransportCheckpoint;
use incant_assets_runtime::CookedAudio;
#[cfg(not(target_arch = "wasm32"))]
use kira::sound::streaming::{StreamingSoundData, StreamingSoundHandle};
use kira::{
    AudioManager, AudioManagerSettings, Frame, Tween,
    backend::Backend,
    listener::ListenerHandle,
    sound::{
        PlaybackState, SoundData,
        static_sound::{
            CheckpointData, CheckpointHandle, StaticSoundData, StaticSoundHandle,
            StaticSoundSettings,
        },
    },
    track::{SpatialTrackBuilder, SpatialTrackHandle, TrackBuilder, TrackHandle},
};
use std::{collections::BTreeMap, fmt::Debug, sync::Arc, time::Duration};

pub const MAX_VOICES: usize = 128;
pub const MAX_BUSES: usize = 32;
pub(crate) const MAX_STATIC_FRAMES: usize = 8 * 1024 * 1024;
pub type VoiceId = u64;
pub struct Mixer<B: Backend> {
    manager: AudioManager<B>,
    master: TrackHandle,
    buses: BTreeMap<String, TrackHandle>,
    listener: ListenerHandle,
    voices: BTreeMap<VoiceId, Voice>,
    next: VoiceId,
    samples: BTreeMap<String, Arc<[Frame]>>,
    errors: std::collections::VecDeque<(VoiceId, String)>,
    synchronous_streams: bool,
    definitions: Vec<Bus>,
    listener_pose: ([f32; 3], [f32; 4]),
    main_gain: f32,
    suspended: bool,
    settled: bool,
    startup: bool,
    pause_pending: bool,
    resume_pending: bool,
    sample_rate: u32,
    rendered_frames: u64,
}
struct Voice {
    #[cfg(any(feature = "scene", test))]
    clip: Arc<CookedAudio>,
    options: PlayOptions,
    sound: VoiceSound,
    spatial: Option<SpatialTrackHandle>,
}
enum VoiceSound {
    Static(StaticSoundHandle),
    OfflineStatic(CheckpointHandle),
    // Only scene checkpoints reconstruct removed transport tombstones.
    #[cfg_attr(not(any(feature = "scene", test)), allow(dead_code))]
    Removed(TransportCheckpoint),
    Offline(crate::offline_stream::Handle),
    #[cfg(not(target_arch = "wasm32"))]
    Streaming(StreamingSoundHandle<incant_assets_runtime::AssetError>),
}
impl VoiceSound {
    fn state(&self) -> PlaybackState {
        match self {
            Self::Static(h) => h.state(),
            Self::OfflineStatic(h) => h.state(),
            Self::Removed(_) => PlaybackState::Stopped,
            Self::Offline(h) => h.state(),
            #[cfg(not(target_arch = "wasm32"))]
            Self::Streaming(h) => h.state(),
        }
    }
}
fn immediate() -> Tween {
    Tween {
        duration: Duration::ZERO,
        ..Default::default()
    }
}
fn resource(error: impl Debug) -> AudioError {
    AudioError::Backend(format!("{error:?}"))
}
impl<B: Backend> Mixer<B>
where
    B::Error: Debug,
{
    pub fn new(settings: AudioManagerSettings<B>, definitions: &[Bus]) -> Result<Self> {
        Self::new_at(
            settings,
            definitions,
            ([0.; 3], [0., 0., 0., 1.]),
            None,
            false,
        )
    }
    /// The private master exists paused before any voice can be attached. This
    /// avoids a new-then-pause command racing a backend's first callback.
    pub fn new_suspended(settings: AudioManagerSettings<B>, definitions: &[Bus]) -> Result<Self> {
        Self::new_at(
            settings,
            definitions,
            ([0.; 3], [0., 0., 0., 1.]),
            None,
            true,
        )
    }
    fn new_at(
        mut settings: AudioManagerSettings<B>,
        definitions: &[Bus],
        pose: ([f32; 3], [f32; 4]),
        main_gain: Option<f32>,
        master_paused: bool,
    ) -> Result<Self> {
        if definitions.len() > MAX_BUSES {
            return Err(AudioError::Capacity);
        }
        let mut pending = BTreeMap::new();
        for bus in definitions {
            config::gain(bus.gain_db)?;
            if bus.id.is_empty()
                || bus.id.len() > 128
                || pending.insert(bus.id.clone(), bus).is_some()
            {
                return Err(AudioError::Invalid("bus IDs must be unique and bounded"));
            }
        }
        // Resolve and validate the complete graph before creating an audio backend.
        let mut order = Vec::new();
        while !pending.is_empty() {
            let id = pending
                .iter()
                .find(|(_, bus)| {
                    bus.parent
                        .as_ref()
                        .is_none_or(|p| order.iter().any(|b: &&Bus| b.id == *p))
                })
                .map(|(id, _)| id.clone())
                .ok_or(AudioError::Invalid("bus parent missing or cycle detected"))?;
            order.push(pending.remove(&id).unwrap());
        }
        settings.capacities.sub_track_capacity = 1;
        settings.capacities.listener_capacity = 1;
        if let Some(gain) = main_gain {
            settings.main_track_builder = settings.main_track_builder.volume(gain);
        }
        let mut manager = AudioManager::<B>::new(settings).map_err(resource)?;
        let mut master = manager
            .add_sub_track(
                TrackBuilder::new()
                    .offline_initial_paused(master_paused)
                    .sound_capacity(MAX_VOICES)
                    .sub_track_capacity(MAX_BUSES + MAX_VOICES),
            )
            .map_err(resource)?;
        let listener = manager.add_listener(pose.0, pose.1).map_err(resource)?;
        let mut buses: BTreeMap<String, TrackHandle> = BTreeMap::new();
        for bus in order {
            let builder = TrackBuilder::new()
                .volume(bus.gain_db)
                .sound_capacity(MAX_VOICES)
                .sub_track_capacity(MAX_BUSES + MAX_VOICES);
            let track = if let Some(parent) = &bus.parent {
                buses.get_mut(parent).unwrap().add_sub_track(builder)
            } else {
                master.add_sub_track(builder)
            }
            .map_err(resource)?;
            buses.insert(bus.id.clone(), track);
        }
        Ok(Self {
            manager,
            master,
            buses,
            listener,
            voices: BTreeMap::new(),
            next: 1,
            samples: BTreeMap::new(),
            errors: std::collections::VecDeque::new(),
            synchronous_streams: false,
            definitions: definitions.to_vec(),
            listener_pose: pose,
            main_gain: main_gain.unwrap_or(0.),
            suspended: false,
            settled: false,
            startup: true,
            pause_pending: false,
            resume_pending: false,
            sample_rate: 0,
            rendered_frames: 0,
        })
    }
    pub fn backend_mut(&mut self) -> &mut B {
        self.manager.backend_mut()
    }
    /// Freeze all child transports without changing individual source state.
    /// The device applies this command at its next processing boundary.
    pub fn set_suspended(&mut self, suspended: bool) {
        self.suspended = suspended;
        if suspended {
            self.pause_pending = true;
            self.master.pause(immediate());
        } else {
            self.resume_pending = true;
            self.master.resume(immediate());
        }
    }
    pub fn set_bus_gain(&mut self, id: Option<&str>, db: f32) -> Result<()> {
        config::gain(db)?;
        if let Some(id) = id {
            self.buses
                .get_mut(id)
                .ok_or(AudioError::UnknownBus)?
                .set_volume(db, immediate());
            self.definitions
                .iter_mut()
                .find(|b| b.id == id)
                .unwrap()
                .gain_db = db;
        } else {
            self.manager.main_track().set_volume(db, immediate());
            self.main_gain = db;
        }
        self.settled = false;
        self.startup = false;
        Ok(())
    }
    pub fn set_listener(&mut self, position: [f32; 3], rotation: [f32; 4]) -> Result<()> {
        config::position(position)?;
        if rotation.iter().any(|v| !v.is_finite())
            || (rotation.iter().map(|v| v * v).sum::<f32>() - 1.).abs() > 1e-4
        {
            return Err(AudioError::Invalid("listener requires a unit quaternion"));
        }
        self.listener.set_position(position, immediate());
        self.listener.set_orientation(rotation, immediate());
        self.listener_pose = (position, rotation);
        self.settled = false;
        Ok(())
    }
    pub fn play(&mut self, clip: Arc<CookedAudio>, options: PlayOptions) -> Result<VoiceId> {
        self.play_inner(clip, options, true, None)
    }
    #[cfg(feature = "scene")]
    pub(crate) fn play_owned(
        &mut self,
        clip: Arc<CookedAudio>,
        options: PlayOptions,
    ) -> Result<VoiceId> {
        // The scene host owns every handle until explicit acknowledgement. A
        // device can finish a different voice concurrently with this call.
        self.play_inner(clip, options, false, None)
    }
    fn play_inner(
        &mut self,
        clip: Arc<CookedAudio>,
        options: PlayOptions,
        reap: bool,
        resume: Option<(TransportCheckpoint, bool)>,
    ) -> Result<VoiceId> {
        options.validate(clip.metadata.frames as f64 / f64::from(clip.metadata.sample_rate))?;
        if options
            .bus
            .as_ref()
            .is_some_and(|id| !self.buses.contains_key(id))
        {
            return Err(AudioError::UnknownBus);
        }
        self.collect_stream_errors()?;
        if reap {
            self.voices
                .retain(|_, v| v.sound.state() != PlaybackState::Stopped);
        }
        if self.voices.len() >= MAX_VOICES || self.next == u64::MAX {
            return Err(AudioError::Capacity);
        }
        #[cfg(target_arch = "wasm32")]
        if options.streaming && !self.synchronous_streams {
            return Err(AudioError::Unsupported(
                "browser streaming adapter is not connected",
            ));
        }
        // Decode/check static data before allocating a spatial track or voice ID.
        let static_data = if options.streaming {
            None
        } else {
            if resume.is_none() {
                self.samples
                    .retain(|_, frames| Arc::strong_count(frames) > 1);
            }
            let frames = if let Some(frames) = self.samples.get(&clip.metadata.content_sha256) {
                Arc::clone(frames)
            } else {
                let resident = self.samples.values().map(|f| f.len()).sum::<usize>();
                if clip.metadata.frames as usize > MAX_STATIC_FRAMES.saturating_sub(resident) {
                    return Err(AudioError::Capacity);
                }
                let frames: Arc<[Frame]> = clip
                    .read_all(MAX_STATIC_FRAMES)?
                    .into_iter()
                    .map(|f| Frame::new(f[0], f[1]))
                    .collect::<Vec<_>>()
                    .into();
                self.samples
                    .insert(clip.metadata.content_sha256.clone(), Arc::clone(&frames));
                frames
            };
            let mut data = StaticSoundData {
                sample_rate: clip.metadata.sample_rate,
                frames,
                settings: StaticSoundSettings::default(),
                slice: None,
            }
            .volume(options.gain_db)
            .panning(options.pan)
            .playback_rate(options.rate)
            .start_position(options.start_seconds);
            if options.looping {
                data = data.loop_region(..);
            }
            Some(data)
        };
        let mut spatial = if let Some(s) = options.spatial {
            let builder = SpatialTrackBuilder::new()
                .distances(s.min_distance..=s.max_distance)
                .spatialization_strength(1.)
                .sound_capacity(1);
            Some(
                if let Some(bus) = options.bus.as_ref() {
                    self.buses.get_mut(bus).unwrap().add_spatial_sub_track(
                        self.listener.id(),
                        s.position,
                        builder,
                    )
                } else {
                    self.master
                        .add_spatial_sub_track(self.listener.id(), s.position, builder)
                }
                .map_err(resource)?,
            )
        } else {
            None
        };
        let sound = if let Some((state, false)) = resume {
            VoiceSound::Removed(state)
        } else if let Some(data) = static_data {
            if self.synchronous_streams {
                let data = match resume {
                    Some((TransportCheckpoint::Static(state), true)) => {
                        CheckpointData::resume(data, state)
                    }
                    None => CheckpointData::new(data),
                    _ => return Err(AudioError::Invalid("static transport kind")),
                }
                .map_err(resource)?;
                VoiceSound::OfflineStatic(self.route(
                    data,
                    options.bus.as_deref(),
                    spatial.as_mut(),
                )?)
            } else {
                VoiceSound::Static(self.route(data, options.bus.as_deref(), spatial.as_mut())?)
            }
        } else if self.synchronous_streams {
            VoiceSound::Offline(self.route(
                crate::offline_stream::Data {
                    clip: Arc::clone(&clip),
                    options: options.clone(),
                    resume: match resume {
                        Some((TransportCheckpoint::Stream(state), true)) => Some(state),
                        None => None,
                        _ => return Err(AudioError::Invalid("stream transport kind")),
                    },
                },
                options.bus.as_deref(),
                spatial.as_mut(),
            )?)
        } else {
            #[cfg(not(target_arch = "wasm32"))]
            {
                let mut data =
                    StreamingSoundData::from_decoder(crate::ClipDecoder::new(Arc::clone(&clip)))
                        .volume(options.gain_db)
                        .panning(options.pan)
                        .playback_rate(options.rate)
                        .start_position(options.start_seconds);
                if options.looping {
                    data = data.loop_region(..);
                }
                VoiceSound::Streaming(self.route(data, options.bus.as_deref(), spatial.as_mut())?)
            }
            #[cfg(target_arch = "wasm32")]
            {
                return Err(AudioError::Unsupported(
                    "browser streaming adapter is not connected",
                ));
            }
        };
        let id = self.next;
        self.next += 1;
        self.voices.insert(
            id,
            Voice {
                sound,
                spatial,
                #[cfg(any(feature = "scene", test))]
                clip,
                options,
            },
        );
        self.settled = false;
        Ok(id)
    }
    fn route<D: SoundData>(
        &mut self,
        data: D,
        bus: Option<&str>,
        spatial: Option<&mut SpatialTrackHandle>,
    ) -> Result<D::Handle>
    where
        D::Error: Debug,
    {
        if let Some(track) = spatial {
            track.play(data)
        } else if let Some(bus) = bus {
            self.buses
                .get_mut(bus)
                .ok_or(AudioError::UnknownBus)?
                .play(data)
        } else {
            self.master.play(data)
        }
        .map_err(resource)
    }
    pub fn set_position(&mut self, id: VoiceId, position: [f32; 3]) -> Result<()> {
        config::position(position)?;
        let voice = self.voices.get_mut(&id).ok_or(AudioError::UnknownVoice)?;
        voice
            .spatial
            .as_mut()
            .ok_or(AudioError::Invalid("voice is not spatial"))?
            .set_position(position, immediate());
        voice.options.spatial.as_mut().unwrap().position = position;
        self.settled = false;
        self.startup = false;
        Ok(())
    }
    pub fn stop(&mut self, id: VoiceId) -> Result<()> {
        match &mut self
            .voices
            .get_mut(&id)
            .ok_or(AudioError::UnknownVoice)?
            .sound
        {
            VoiceSound::Static(h) => h.stop(immediate()),
            VoiceSound::OfflineStatic(h) => h.stop(),
            VoiceSound::Removed(_) => {}
            VoiceSound::Offline(h) => h.stop(),
            #[cfg(not(target_arch = "wasm32"))]
            VoiceSound::Streaming(h) => h.stop(immediate()),
        }
        self.settled = false;
        self.startup = false;
        Ok(())
    }
    pub fn set_paused(&mut self, id: VoiceId, paused: bool) -> Result<()> {
        match &mut self
            .voices
            .get_mut(&id)
            .ok_or(AudioError::UnknownVoice)?
            .sound
        {
            VoiceSound::Offline(h) => h.pause(paused),
            VoiceSound::OfflineStatic(h) => h.pause(paused),
            VoiceSound::Removed(_) => {}
            VoiceSound::Static(h) => {
                if paused {
                    h.pause(immediate())
                } else {
                    h.resume(immediate())
                }
            }
            #[cfg(not(target_arch = "wasm32"))]
            VoiceSound::Streaming(h) => {
                if paused {
                    h.pause(immediate())
                } else {
                    h.resume(immediate())
                }
            }
        }
        self.settled = false;
        self.startup = false;
        Ok(())
    }
    pub fn state(&self, id: VoiceId) -> Result<PlaybackState> {
        Ok(self
            .voices
            .get(&id)
            .ok_or(AudioError::UnknownVoice)?
            .sound
            .state())
    }
    pub fn configure_voice(
        &mut self,
        id: VoiceId,
        gain_db: f32,
        pan: f32,
        rate: f64,
    ) -> Result<()> {
        PlayOptions {
            gain_db,
            pan,
            rate,
            ..Default::default()
        }
        .validate(0.)?;
        match &mut self
            .voices
            .get_mut(&id)
            .ok_or(AudioError::UnknownVoice)?
            .sound
        {
            VoiceSound::Static(h) => {
                h.set_volume(gain_db, immediate());
                h.set_panning(pan, immediate());
                h.set_playback_rate(rate, immediate());
            }
            VoiceSound::OfflineStatic(h) => h.configure(gain_db, pan, rate).map_err(resource)?,
            VoiceSound::Removed(_) => {}
            VoiceSound::Offline(h) => h.configure(gain_db, pan, rate),
            #[cfg(not(target_arch = "wasm32"))]
            VoiceSound::Streaming(h) => {
                h.set_volume(gain_db, immediate());
                h.set_panning(pan, immediate());
                h.set_playback_rate(rate, immediate());
            }
        }
        let voice = self.voices.get_mut(&id).unwrap();
        voice.options.gain_db = gain_db;
        voice.options.pan = pan;
        voice.options.rate = rate;
        self.settled = false;
        self.startup = false;
        Ok(())
    }
    fn collect_stream_errors(&mut self) -> Result<()> {
        for (&id, voice) in &mut self.voices {
            if let VoiceSound::Offline(h) = &voice.sound {
                if self.errors.len() >= 1024 {
                    return Err(AudioError::Capacity);
                }
                if let Some(error) = h.pop_error() {
                    self.errors.push_back((id, error));
                }
            }
            #[cfg(not(target_arch = "wasm32"))]
            if let VoiceSound::Streaming(h) = &mut voice.sound {
                loop {
                    if self.errors.len() >= 1024 {
                        return Err(AudioError::Capacity);
                    }
                    let Some(error) = h.pop_error() else {
                        break;
                    };
                    self.errors.push_back((id, error.to_string()));
                }
            }
        }
        Ok(())
    }
    #[cfg(feature = "scene")]
    pub(crate) fn can_start(&mut self, bus: Option<&str>, spatial: bool) -> Result<bool> {
        // A stopped sound remains in Kira's arena until the renderer's next
        // processing boundary. Observe actual capacity rather than treating the
        // handle's Stopped state as proof that its allocation was reclaimed.
        if let Some(bus) = bus {
            let track = self.buses.get(bus).ok_or(AudioError::UnknownBus)?;
            Ok(if spatial {
                track.num_sub_tracks() < track.sub_track_capacity()
            } else {
                track.num_sounds() < track.sound_capacity()
            })
        } else if spatial {
            Ok(self.master.num_sub_tracks() < self.master.sub_track_capacity())
        } else {
            let track = &self.master;
            Ok(track.num_sounds() < track.sound_capacity())
        }
    }
    #[cfg(feature = "scene")]
    pub(crate) fn check_stream_errors(&mut self) -> Result<()> {
        self.collect_stream_errors()?;
        if let Some((_, error)) = self.errors.pop_front() {
            return Err(AudioError::Stream(error));
        }
        Ok(())
    }
    #[cfg(feature = "scene")]
    pub(crate) fn forget_stopped(&mut self, id: VoiceId) -> Result<()> {
        if self.state(id)? != PlaybackState::Stopped {
            return Err(AudioError::Invalid("voice still playing"));
        }
        // The decoder publishes an error before the renderer marks it Stopped.
        // Recheck after observing that state: the initial host poll may have
        // preceded the error. Never silently discard it with its last handle.
        let voice = self.voices.get_mut(&id).ok_or(AudioError::UnknownVoice)?;
        let error = match &mut voice.sound {
            VoiceSound::Static(_) | VoiceSound::OfflineStatic(_) | VoiceSound::Removed(_) => None,
            VoiceSound::Offline(h) => h.pop_error(),
            #[cfg(not(target_arch = "wasm32"))]
            VoiceSound::Streaming(h) => h.pop_error().map(|error| error.to_string()),
        };
        if let Some(error) = error {
            return Err(AudioError::Stream(error));
        }
        self.voices.remove(&id);
        Ok(())
    }
    /// Drain bounded diagnostics, including errors from voices already reaped.
    /// Hosts should poll this regularly; a full error queue blocks new playback.
    pub fn stream_errors(&mut self) -> Vec<(VoiceId, String)> {
        let _ = self.collect_stream_errors();
        self.errors.drain(..).collect()
    }
}

impl Mixer<crate::OfflineBackend> {
    pub fn offline(sample_rate: u32, buses: &[Bus]) -> Result<Self> {
        let mut mixer = Self::new(
            AudioManagerSettings {
                backend_settings: sample_rate,
                ..Default::default()
            },
            buses,
        )?;
        mixer.synchronous_streams = true;
        mixer.sample_rate = sample_rate;
        Ok(mixer)
    }
    pub fn render(&mut self, output: &mut [f32]) -> Result<()> {
        let frames = self
            .rendered_frames
            .checked_add((output.len() / 2) as u64)
            .ok_or(AudioError::Capacity)?;
        self.manager
            .backend_mut()
            .render(output)
            .map_err(|e| AudioError::Backend(e.into()))?;
        if !output.is_empty() {
            self.settled = true;
            self.startup = false;
            self.pause_pending = false;
            self.resume_pending = false;
        }
        self.rendered_frames = frames;
        Ok(())
    }
}

#[cfg(all(test, feature = "scene"))]
mod owned_handle_tests {
    mod support {
        include!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../incant_assets_runtime/tests/support/mod.rs"
        ));
    }
    use super::*;
    #[test]
    fn forgetting_a_finished_voice_cannot_hide_an_error_after_the_last_poll() {
        use std::io::{Seek, SeekFrom, Write};
        let temp = tempfile::tempdir().unwrap();
        let key = support::cooked(temp.path(), &vec![[0.2; 2]; 20000]);
        let clip = Arc::new(incant_assets_runtime::load_audio(temp.path(), &key).unwrap());
        let pcm = temp
            .path()
            .join(format!("{}.ipcm", clip.metadata.content_sha256));
        let mut mixer = Mixer::offline(48000, &[]).unwrap();
        let voice = mixer
            .play_owned(
                clip,
                PlayOptions {
                    streaming: true,
                    ..Default::default()
                },
            )
            .unwrap();
        mixer.render(&mut [0.; 2048]).unwrap();
        mixer.check_stream_errors().unwrap();
        let mut file = std::fs::OpenOptions::new().write(true).open(pcm).unwrap();
        file.seek(SeekFrom::Start(15000 * 8)).unwrap();
        file.write_all(&[255; 8]).unwrap();
        drop(file);
        // A renderer may finish with an error after the host's previous poll.
        mixer.render(&mut vec![0.; 40000]).unwrap();
        assert_eq!(mixer.state(voice).unwrap(), PlaybackState::Stopped);
        assert!(matches!(
            mixer.forget_stopped(voice),
            Err(AudioError::Stream(_))
        ));
    }

    #[test]
    fn scene_play_cannot_reap_another_voice_that_finished_since_host_inspection() {
        let temp = tempfile::tempdir().unwrap();
        let key = support::cooked(temp.path(), &[[0.2; 2]; 16]);
        let clip = Arc::new(incant_assets_runtime::load_audio(temp.path(), &key).unwrap());
        let mut mixer = Mixer::offline(48000, &[]).unwrap();
        let old = mixer
            .play_owned(clip.clone(), PlayOptions::default())
            .unwrap();
        assert_eq!(mixer.state(old).unwrap(), PlaybackState::Playing);
        // Model the device finishing after the host's last observation, before
        // the host starts another source. No scheduling-sensitive sleep needed.
        mixer.render(&mut [0.; 128]).unwrap();
        let _new = mixer
            .play_owned(clip.clone(), PlayOptions::default())
            .unwrap();
        assert_eq!(mixer.state(old).unwrap(), PlaybackState::Stopped);
        mixer.forget_stopped(old).unwrap();
        assert!(matches!(mixer.state(old), Err(AudioError::UnknownVoice)));
        // Preserve the standalone Mixer's original automatic cleanup contract.
        let legacy = mixer.play(clip.clone(), PlayOptions::default()).unwrap();
        mixer.render(&mut [0.; 128]).unwrap();
        mixer.play(clip, PlayOptions::default()).unwrap();
        assert!(matches!(mixer.state(legacy), Err(AudioError::UnknownVoice)));
    }
}
