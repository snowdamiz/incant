use crate::{Result, print, read_project, save};
use incant_assets::TextureUsage;
use incant_cmd::{Actor, CommandBus};
use incant_import::{ImportRequest, ImportSnapshot};
use std::path::Path;

pub fn load_runtime(
    project: &Path,
    document: &incant_doc::Project,
) -> Result<incant_assets::AssetStore> {
    let root = project
        .parent()
        .filter(|p| !p.as_os_str().is_empty())
        .unwrap_or(Path::new("."));
    let mut store = incant_assets::AssetStore::default();
    store.sync_project(document, root)?;
    Ok(store)
}

pub fn import(
    project: &Path,
    source: &Path,
    cache: Option<&Path>,
    texture_usage: Option<&str>,
) -> Result<()> {
    let root = project
        .parent()
        .filter(|p| !p.as_os_str().is_empty())
        .unwrap_or(Path::new("."));
    let request = ImportRequest {
        source: source.to_str().ok_or("Source path must be UTF-8")?.into(),
        texture_usage: match texture_usage {
            Some("color") => Some(TextureUsage::Color),
            Some("linear") => Some(TextureUsage::Linear),
            Some("normal") => Some(TextureUsage::Normal),
            Some(_) => return Err("Unknown texture usage".into()),
            None => None,
        },
    };
    let mut bus = CommandBus::persistent_with_sources(
        project.with_extension("journal.jsonl"),
        read_project(project)?,
        root,
    )?;
    let prepared = ImportSnapshot::capture(&bus).prepare(root, cache, &[request])?;
    let outcome = &prepared.outcomes()[0];
    let actor = Actor::import(&outcome.asset.kind);
    let description = format!("Import {}", outcome.asset.name);
    let committed = prepared.commit(&mut bus, actor, description)?;
    save(project, &bus.project().canonical_text()?)?;
    let mut response = serde_json::to_value(&committed.imports[0])?;
    response["revision"] = serde_json::json!(committed.revision);
    print(response)
}

/// Document semantics plus cached sprite bindings; no source reimport or mutation.
pub fn validate(path: &Path) -> Result<()> {
    let project = read_project(path)?;
    let root = path
        .parent()
        .filter(|p| !p.as_os_str().is_empty())
        .unwrap_or(Path::new("."));
    let diagnostics = incant_import::validate_cached_sprites(&project, root, None)?;
    let valid = !diagnostics
        .iter()
        .any(|d| d.severity == incant_import::SpriteDiagnosticSeverity::Error);
    print(
        serde_json::json!({"valid":valid,"project_id":project.id,"schema_version":project.schema_version,
        "diagnostics":diagnostics}),
    )?;
    if !valid {
        return Err("cached sprite reference validation failed; see diagnostics".into());
    }
    Ok(())
}
