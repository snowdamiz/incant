//! Editor/tooling import coordination. Runtime cooked-asset loading stays in
//! incant_assets, without a dependency on the authoring command bus.
mod sprites;
mod tilemaps;
mod watch;
use incant_assets::{
    AssetError, Dependency, TextureFormat, TextureUsage, cook_audio, cook_font, cook_model,
    cook_texture,
};
use incant_cmd::{Actor, Command, CommandBus, CommandError};
use incant_doc::{Asset, AssetImportSettings, Project, new_id};
use serde::{Deserialize, Serialize};
pub use sprites::{
    SpriteDiagnostic, SpriteDiagnosticCode, SpriteDiagnosticSeverity, SpriteReferenceErrors,
    validate_cached_sprites,
};
use std::{
    collections::BTreeSet,
    path::{Component, Path},
};
use thiserror::Error;
pub use watch::{PreparedWatch, SourceWatcher, WatchDiagnostic, WatchReport};

pub const MAX_BATCH_IMPORTS: usize = 64;

#[derive(Debug, Error)]
pub enum ImportError {
    #[error("an import batch must contain between 1 and {MAX_BATCH_IMPORTS} sources")]
    BatchSize,
    #[error("source must be a canonical, portable project-relative path: {0}")]
    Path(String),
    #[error("source appears more than once in the import batch: {0}")]
    DuplicateSource(String),
    #[error("multiple assets use source {0}; resolve their identities before reimport")]
    AmbiguousSource(String),
    #[error(
        "unsupported import source: {0}; expected glTF, GLB, FBX, PNG, JPEG, EXR, .atlas.json, WAV, OGG, TTF, OTF or WASM"
    )]
    Unsupported(String),
    #[error("texture usage applies only to standalone images: {0}")]
    ModelUsage(String),
    #[error("could not cook {path}: {source}")]
    Cook { path: String, source: AssetError },
    #[error("the prepared import belongs to a different project")]
    DifferentProject,
    #[error("prepared source-watch cycle is stale or belongs to another watcher")]
    StaleWatch,
    #[error("the project changed since import preparation; prepare again")]
    ChangedProject,
    #[error(transparent)]
    SpriteReferences(#[from] SpriteReferenceErrors),
    #[error(transparent)]
    Command(#[from] CommandError),
}
pub type Result<T> = std::result::Result<T, ImportError>;

#[derive(Debug, Clone, Deserialize, Serialize, schemars::JsonSchema)]
#[serde(deny_unknown_fields)]
pub struct ImportRequest {
    pub source: String,
    #[serde(default)]
    pub texture_usage: Option<TextureUsage>,
}

#[derive(Debug, Serialize)]
#[serde(untagged)]
pub enum ImportDetails {
    Wasm {
        bytes: usize,
        input_sha256: String,
        prepared_sha256: String,
        registry_sha256: String,
        dependencies: Vec<Dependency>,
    },
    Font {
        bytes: u32,
        dependencies: Vec<Dependency>,
    },
    Audio {
        sample_rate: u32,
        channels: u8,
        frames: u64,
        duration_seconds: f64,
        dependencies: Vec<Dependency>,
    },
    Model {
        meshes: usize,
        textures: usize,
        vertices: usize,
        dependencies: Vec<Dependency>,
    },
    Texture {
        width: u32,
        height: u32,
        format: TextureFormat,
        mip_levels: usize,
        usage: TextureUsage,
        #[serde(skip_serializing_if = "Option::is_none")]
        atlas: Option<incant_doc::AtlasLayout>,
        dependencies: Vec<Dependency>,
    },
}
#[derive(Debug, Serialize)]
pub struct ImportOutcome {
    pub asset: Asset,
    pub changed: bool,
    pub cache_hit: bool,
    pub details: ImportDetails,
    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub diagnostics: Vec<SpriteDiagnostic>,
}
#[derive(Debug, Serialize)]
pub struct CommittedImports {
    pub imports: Vec<ImportOutcome>,
    pub revision: u64,
}

/// Capture under the caller's bus lock, then move into a worker. Cooking needs
/// neither a live bus borrow nor the editor's event thread.
#[derive(Clone)]
pub struct ImportSnapshot {
    project: Project,
    revision: u64,
}
impl ImportSnapshot {
    pub fn capture(bus: &CommandBus) -> Self {
        Self {
            project: bus.project().clone(),
            revision: bus.revision(),
        }
    }
    /// Cache override is a direct directory for compatibility with CLI --cache.
    /// Otherwise use the project's .incant/cache/{models,textures} directories.
    /// Cache files may be created during preparation; authored data and history
    /// are changed only by commit, after the entire batch succeeds.
    pub fn prepare(
        self,
        root: &Path,
        cache_override: Option<&Path>,
        requests: &[ImportRequest],
    ) -> Result<PreparedImports> {
        if requests.is_empty() || requests.len() > MAX_BATCH_IMPORTS {
            return Err(ImportError::BatchSize);
        }
        let mut seen = BTreeSet::new();
        let mut inputs = Vec::with_capacity(requests.len());
        // Validate identities and options before spending work on any source.
        for request in requests {
            validate_path(&request.source)?;
            if !seen.insert(&request.source) {
                return Err(ImportError::DuplicateSource(request.source.clone()));
            }
            let previous: Vec<_> = self
                .project
                .assets
                .values()
                .filter(|asset| asset.path == request.source)
                .collect();
            if previous.len() > 1 {
                return Err(ImportError::AmbiguousSource(request.source.clone()));
            }
            let extension = Path::new(&request.source)
                .extension()
                .and_then(|v| v.to_str())
                .unwrap_or("")
                .to_ascii_lowercase();
            let kind = match extension.as_str() {
                "gltf" | "glb" | "fbx" => ImportKind::Model,
                "png" | "jpg" | "jpeg" | "exr" => ImportKind::Texture,
                "wav" | "ogg" => ImportKind::Audio,
                "ttf" | "otf" => ImportKind::Font,
                "wasm" => ImportKind::Wasm,
                "json" if request.source.to_ascii_lowercase().ends_with(".atlas.json") => {
                    ImportKind::Texture
                }
                _ => return Err(ImportError::Unsupported(request.source.clone())),
            };
            if kind != ImportKind::Texture && request.texture_usage.is_some() {
                return Err(ImportError::ModelUsage(request.source.clone()));
            }
            inputs.push((request, previous.first().copied(), kind));
        }
        let mut imports = Vec::with_capacity(inputs.len());
        for (request, previous, kind) in inputs {
            let cooked = cook(root, cache_override, request, previous, kind).map_err(|source| {
                ImportError::Cook {
                    path: request.source.clone(),
                    source,
                }
            })?;
            imports.push(cooked);
        }
        sprites::check_imports(&self.project, &mut imports)?;
        Ok(PreparedImports {
            snapshot: self,
            imports,
        })
    }
}

/// A prepared batch cannot be edited or partially committed. On a stale snapshot
/// or invalid command the bus preserves its complete previous document/history.
pub struct PreparedImports {
    snapshot: ImportSnapshot,
    imports: Vec<ImportOutcome>,
}
impl PreparedImports {
    pub fn outcomes(&self) -> &[ImportOutcome] {
        &self.imports
    }
    pub fn commit(
        self,
        bus: &mut CommandBus,
        actor: Actor,
        description: impl Into<String>,
    ) -> Result<CommittedImports> {
        if bus.project().id != self.snapshot.project.id {
            return Err(ImportError::DifferentProject);
        }
        if bus.revision() != self.snapshot.revision {
            return Err(CommandError::Conflict {
                expected: self.snapshot.revision,
                actual: bus.revision(),
            }
            .into());
        }
        // Protect same-ID/revision snapshots supplied to a different bus instance.
        if bus.project() != &self.snapshot.project {
            return Err(ImportError::ChangedProject);
        }
        let commands: Vec<_> = self
            .imports
            .iter()
            .filter(|import| import.changed)
            .map(|import| Command::UpsertAsset {
                asset: import.asset.clone(),
            })
            .collect();
        if !commands.is_empty() {
            bus.execute(commands, actor, description, Some(self.snapshot.revision))?;
        }
        Ok(CommittedImports {
            imports: self.imports,
            revision: bus.revision(),
        })
    }
}

fn validate_path(source: &str) -> Result<()> {
    let path = Path::new(source);
    let parts: Vec<_> = path.components().collect();
    if source.is_empty()
        || source.contains(['\\', ':', '\0'])
        || parts.iter().any(|c| !matches!(c, Component::Normal(_)))
        || parts
            .iter()
            .map(|c| c.as_os_str().to_string_lossy())
            .collect::<Vec<_>>()
            .join("/")
            != source
    {
        return Err(ImportError::Path(source.into()));
    }
    Ok(())
}

#[derive(Clone, Copy, PartialEq)]
enum ImportKind {
    Model,
    Texture,
    Audio,
    Font,
    Wasm,
}

fn cook(
    root: &Path,
    cache_override: Option<&Path>,
    request: &ImportRequest,
    previous: Option<&Asset>,
    kind: ImportKind,
) -> incant_assets::Result<ImportOutcome> {
    let source = Path::new(&request.source);
    let (kind, fingerprint, cache_hit, import_settings, details) = if kind == ImportKind::Wasm {
        let cache = cache_directory(root, cache_override, "wasm")?;
        std::fs::create_dir_all(&cache)?;
        let bytes = incant_assets::SourceSet::new(root)?
            .read_limited(source, incant_wasm_cook::MAX_MODULE_BYTES)?;
        let captured = incant_wasm_cook::CapturedModule::capture(&bytes)
            .map_err(|e| AssetError::Invalid(e.to_string()))?;
        let hit = captured
            .store(&cache)
            .map_err(|e| AssetError::Invalid(e.to_string()))?;
        (
            "wasm",
            captured.fingerprint(),
            hit,
            None,
            ImportDetails::Wasm {
                bytes: bytes.len(),
                input_sha256: captured.input_sha256().into(),
                prepared_sha256: captured.prepared_sha256().into(),
                registry_sha256: captured.registry_sha256().into(),
                dependencies: vec![Dependency {
                    path: request.source.clone(),
                    sha256: captured.input_sha256().into(),
                }],
            },
        )
    } else if kind == ImportKind::Model {
        let cache = cache_directory(root, cache_override, "models")?;
        let cooked = cook_model(root, source, &cache)?;
        (
            "model",
            cooked.metadata.fingerprint,
            cooked.cache_hit,
            None,
            ImportDetails::Model {
                meshes: cooked.meshes.len(),
                textures: cooked.images.len(),
                vertices: cooked.meshes.iter().map(|m| m.vertices.len()).sum(),
                dependencies: cooked.metadata.dependencies,
            },
        )
    } else if kind == ImportKind::Font {
        let cache = cache_directory(root, cache_override, "fonts")?;
        let cooked = cook_font(root, source, &cache)?;
        let metadata = cooked.metadata();
        (
            "font",
            metadata.fingerprint.clone(),
            cooked.cache_hit,
            None,
            ImportDetails::Font {
                bytes: metadata.bytes,
                dependencies: vec![metadata.dependency.clone()],
            },
        )
    } else if kind == ImportKind::Audio {
        let cache = cache_directory(root, cache_override, "audio")?;
        let cooked = cook_audio(root, source, &cache)?;
        let metadata = cooked.metadata;
        (
            "audio",
            metadata.fingerprint,
            cooked.cache_hit,
            None,
            ImportDetails::Audio {
                sample_rate: metadata.sample_rate,
                channels: metadata.channels,
                frames: metadata.frames,
                duration_seconds: metadata.frames as f64 / f64::from(metadata.sample_rate),
                dependencies: vec![metadata.dependency],
            },
        )
    } else {
        let cache = cache_directory(root, cache_override, "textures")?;
        let usage = request.texture_usage.unwrap_or_else(|| {
            match previous.and_then(|asset| asset.import_settings.as_ref()) {
                Some(AssetImportSettings::Texture { usage }) => *usage,
                None => TextureUsage::Color,
            }
        });
        let cooked = cook_texture(root, source, &cache, usage)?;
        let dependencies = cooked.metadata.all_dependencies();
        (
            "texture",
            cooked.metadata.fingerprint,
            cooked.cache_hit,
            Some(AssetImportSettings::Texture { usage }),
            ImportDetails::Texture {
                width: cooked.texture.width,
                height: cooked.texture.height,
                format: cooked.texture.format,
                mip_levels: cooked.texture.levels.len(),
                usage,
                dependencies,
                atlas: cooked.metadata.atlas,
            },
        )
    };
    let asset = Asset {
        id: previous.map(|a| a.id.clone()).unwrap_or_else(new_id),
        name: previous.map(|a| a.name.clone()).unwrap_or_else(|| {
            source
                .file_stem()
                .unwrap_or_default()
                .to_string_lossy()
                .into()
        }),
        path: request.source.clone(),
        kind: kind.into(),
        sha256: fingerprint,
        import_settings,
    };
    Ok(ImportOutcome {
        changed: previous != Some(&asset),
        asset,
        cache_hit,
        details,
        diagnostics: Vec::new(),
    })
}

/// Default cache writes belong to the selected project. Check each directory
/// before descending, so an authored .incant/cache symlink cannot redirect a
/// host-granted import outside the project. CLI's explicit --cache remains a
/// separately caller-authorized path; engine-agent tools never accept it.
fn cache_directory(
    root: &Path,
    override_path: Option<&Path>,
    kind: &str,
) -> incant_assets::Result<std::path::PathBuf> {
    if let Some(path) = override_path {
        return Ok(path.to_path_buf());
    }
    let root = root.canonicalize()?;
    let mut path = root.clone();
    for part in [".incant", "cache", kind] {
        path.push(part);
        match std::fs::create_dir(&path) {
            Ok(()) => {}
            Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => {}
            Err(error) => return Err(error.into()),
        }
        let metadata = std::fs::symlink_metadata(&path)?;
        if metadata.file_type().is_symlink()
            || !metadata.is_dir()
            || !path.canonicalize()?.starts_with(&root)
        {
            return Err(AssetError::Invalid(
                "default cache directories must be real project directories, not symlinks or files"
                    .into(),
            ));
        }
    }
    Ok(path)
}
