from pathlib import Path
import os,subprocess,json,hashlib,time,sys,shutil
root=Path('/Users/andreyyurlov/.codex/worktrees/native-audio-host/incant');out=Path(__file__).parent;target=Path('/Users/andreyyurlov/.codex/incant-physics-variant-target');sys.path.insert(0,str(root/'tools'));from native_process import run
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
freeze=json.loads(Path('/Users/andreyyurlov/.codex/incant-evidence/cooked-sprites-source-002/freeze.json').read_text());env=dict(os.environ,CARGO_TARGET_DIR=str(target));rows=[]
def execute(name,argv):
 start=time.monotonic()
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  p=run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=1800)
 row={'name':name,'argv':list(map(str,argv)),'exit_code':p.returncode,'seconds':time.monotonic()-start,'stdout_sha256':h(out/(name+'.stdout')),'stderr_sha256':h(out/(name+'.stderr'))};rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');assert all(h(root/r['path'])==r['sha256'] for r in freeze);print(name,p.returncode,flush=True)
 if p.returncode:sys.exit(p.returncode)
source=target/'ci/build/incant_render-a2fe7507466113c1/out/sprite-shaders';dest=out/'artifacts';shutil.copytree(source,dest);(out/'artifacts.json').write_text(json.dumps({p.name:h(p) for p in dest.iterdir()},indent=2)+'\n')
execute('metal-version',['xcrun','-sdk','macosx','metal','--version'])
for stage in ['Vertex','Fragment']:
 metal=out/(stage+'.metal');shutil.copyfile(dest/('Metal-'+stage+'.shader'),metal)
 execute(stage+'-metal',['xcrun','-sdk','macosx','metal','-std=macos-metal2.4','-c',str(metal),'-o',str(out/(stage+'.air'))])
 execute(stage+'-metallib',['xcrun','-sdk','macosx','metallib',str(out/(stage+'.air')),'-o',str(out/(stage+'.metallib'))])
cargo=str(root/'tools/cargo')
execute('clippy',[cargo,'clippy','--locked','--profile','ci','-p','incant_shader_cook','-p','incant_render','--all-targets','--features','incant_render/cooked-sprites,incant_render/cooked-geometry','-j2','--','-D','warnings'])
execute('default-test',[cargo,'test','--locked','--profile','ci','-p','incant_render','-j2'])
execute('web-check',[cargo,'check','--locked','--profile','ci','--target','wasm32-unknown-unknown','-p','incant_render','--features','cooked-sprites,cooked-geometry','-j2'])
execute('fmt',[cargo,'fmt','--all','--check']);execute('conventions',['python3','tools/generate_conventions.py','--check']);execute('diff',['git','diff','--check'])
(out/'result.json').write_text(json.dumps({'passed':True,'commands':len(rows),'source_inputs':len(freeze),'no_gpu_execution':True},indent=2)+'\n')
