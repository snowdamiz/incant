// language: metal2.4
#include <metal_stdlib>
#include <simd/simd.h>

using metal::uint;

struct _mslBufferSizes {
    uint buffer_size15;
    uint buffer_size14;
};

struct Input {
    metal::float3 position;
    metal::float2 uv;
    char _pad2[8];
    metal::float4 tint;
    metal::float4 uv_bounds;
    metal::float2 texel;
    uint sampling;
    char _pad6[4];
};
struct Output {
    metal::float4 position;
    metal::float2 uv;
    char _pad2[8];
    metal::float4 tint;
    metal::float4 uv_bounds;
    metal::float2 texel;
    uint sampling;
    char _pad6[4];
    metal::float2 texel_base;
    char _pad7[8];
};
metal::float3 unpackFloat32x3_(uint b0, uint b1, uint b2, uint b3, uint b4, uint b5, uint b6, uint b7, uint b8, uint b9, uint b10, uint b11) {
    return metal::float3(as_type<float>(b3 << 24 | b2 << 16 | b1 << 8 | b0), as_type<float>(b7 << 24 | b6 << 16 | b5 << 8 | b4), as_type<float>(b11 << 24 | b10 << 16 | b9 << 8 | b8));
}
metal::float2 unpackFloat32x2_(uint b0, uint b1, uint b2, uint b3, uint b4, uint b5, uint b6, uint b7) {
    return metal::float2(as_type<float>(b3 << 24 | b2 << 16 | b1 << 8 | b0), as_type<float>(b7 << 24 | b6 << 16 | b5 << 8 | b4));
}
metal::float4 unpackFloat32x4_(uint b0, uint b1, uint b2, uint b3, uint b4, uint b5, uint b6, uint b7, uint b8, uint b9, uint b10, uint b11, uint b12, uint b13, uint b14, uint b15) {
    return metal::float4(as_type<float>(b3 << 24 | b2 << 16 | b1 << 8 | b0), as_type<float>(b7 << 24 | b6 << 16 | b5 << 8 | b4), as_type<float>(b11 << 24 | b10 << 16 | b9 << 8 | b8), as_type<float>(b15 << 24 | b14 << 16 | b13 << 8 | b12));
}
uint unpackUint32_(uint b0, uint b1, uint b2, uint b3) {
    return (b3 << 24 | b2 << 16 | b1 << 8 | b0);
}

struct vertex_Output {
    metal::float4 position [[position]];
    metal::float2 uv [[user(loc0), center_perspective]];
    metal::float4 tint [[user(loc1), center_perspective]];
    metal::float4 uv_bounds [[user(loc2), flat]];
    metal::float2 texel [[user(loc3), center_perspective]];
    uint sampling [[user(loc4), flat]];
    metal::float2 texel_base [[user(loc5), flat]];
};
struct vb_15_type { metal::uchar data[12]; };
struct vb_14_type { metal::uchar data[52]; };
vertex vertex_Output vertex_(
  constant metal::float4x4& camera [[buffer(0)]]
, uint v_id [[vertex_id]]
, const device vb_15_type* vb_15_in [[buffer(15)]]
, const device vb_14_type* vb_14_in [[buffer(14)]]
, constant _mslBufferSizes& _buffer_sizes [[buffer(1)]]
) {
    metal::float3 position = {};
    if (v_id < (_buffer_sizes.buffer_size15 / 12)) {
        const vb_15_type vb_15_elem = vb_15_in[v_id];
        position = unpackFloat32x3_(vb_15_elem.data[0], vb_15_elem.data[1], vb_15_elem.data[2], vb_15_elem.data[3], vb_15_elem.data[4], vb_15_elem.data[5], vb_15_elem.data[6], vb_15_elem.data[7], vb_15_elem.data[8], vb_15_elem.data[9], vb_15_elem.data[10], vb_15_elem.data[11]);
    }
    metal::float2 uv = {};
    metal::float4 tint = {};
    metal::float4 uv_bounds = {};
    metal::float2 texel = {};
    uint sampling = {};
    if (v_id < (_buffer_sizes.buffer_size14 / 52)) {
        const vb_14_type vb_14_elem = vb_14_in[v_id];
        uv = unpackFloat32x2_(vb_14_elem.data[0], vb_14_elem.data[1], vb_14_elem.data[2], vb_14_elem.data[3], vb_14_elem.data[4], vb_14_elem.data[5], vb_14_elem.data[6], vb_14_elem.data[7]);
        tint = unpackFloat32x4_(vb_14_elem.data[8], vb_14_elem.data[9], vb_14_elem.data[10], vb_14_elem.data[11], vb_14_elem.data[12], vb_14_elem.data[13], vb_14_elem.data[14], vb_14_elem.data[15], vb_14_elem.data[16], vb_14_elem.data[17], vb_14_elem.data[18], vb_14_elem.data[19], vb_14_elem.data[20], vb_14_elem.data[21], vb_14_elem.data[22], vb_14_elem.data[23]);
        uv_bounds = unpackFloat32x4_(vb_14_elem.data[24], vb_14_elem.data[25], vb_14_elem.data[26], vb_14_elem.data[27], vb_14_elem.data[28], vb_14_elem.data[29], vb_14_elem.data[30], vb_14_elem.data[31], vb_14_elem.data[32], vb_14_elem.data[33], vb_14_elem.data[34], vb_14_elem.data[35], vb_14_elem.data[36], vb_14_elem.data[37], vb_14_elem.data[38], vb_14_elem.data[39]);
        texel = unpackFloat32x2_(vb_14_elem.data[40], vb_14_elem.data[41], vb_14_elem.data[42], vb_14_elem.data[43], vb_14_elem.data[44], vb_14_elem.data[45], vb_14_elem.data[46], vb_14_elem.data[47]);
        sampling = unpackUint32_(vb_14_elem.data[48], vb_14_elem.data[49], vb_14_elem.data[50], vb_14_elem.data[51]);
    }
    const Input input = { position, uv, {}, tint, uv_bounds, texel, sampling };
    Output out = {};
    metal::float4x4 _e4 = camera;
    out.position = _e4 * metal::float4(input.position, 1.0);
    out.uv = input.uv;
    out.tint = input.tint;
    out.uv_bounds = input.uv_bounds;
    out.texel = input.texel;
    out.sampling = input.sampling;
    out.texel_base = input.uv;
    Output _e21 = out;
    const auto _tmp = _e21;
    return vertex_Output { _tmp.position, _tmp.uv, _tmp.tint, _tmp.uv_bounds, _tmp.texel, _tmp.sampling, _tmp.texel_base };
}
