struct NagaConstants {
    int first_vertex;
    int first_instance;
    uint other;
};
ConstantBuffer<NagaConstants> _NagaConstants: register(b1);

struct Output {
    float4 position : SV_Position;
    float2 uv : LOC0;
    float4 tint : LOC1;
    nointerpolation float4 uv_bounds : LOC2;
    float2 texel : LOC3;
    nointerpolation uint sampling : LOC4;
    nointerpolation float2 texel_base : LOC5;
};

Texture2D<float4> image : register(t0);
SamplerState nagaSamplerHeap[2048]: register(s0, space0);
SamplerComparisonState nagaComparisonSamplerHeap[2048]: register(s2048, space0);
StructuredBuffer<uint> nagaGroup1SamplerIndexArray : register(t1, space0);
static const SamplerState filtering = nagaSamplerHeap[nagaGroup1SamplerIndexArray[0]];

struct FragmentInput_fragment {
    float2 uv : LOC0;
    float4 tint : LOC1;
    nointerpolation float4 uv_bounds : LOC2;
    float2 texel : LOC3;
    nointerpolation uint sampling : LOC4;
    nointerpolation float2 texel_base : LOC5;
    float4 position : SV_Position;
};

int2 naga_f2i32(float2 value) {
    return int2(clamp(value, -2147483600.0, 2147483500.0));
}

float4 fragment(FragmentInput_fragment fragmentinput_fragment) : SV_Target0
{
    Output input = { fragmentinput_fragment.position, fragmentinput_fragment.uv, fragmentinput_fragment.tint, fragmentinput_fragment.uv_bounds, fragmentinput_fragment.texel, fragmentinput_fragment.sampling, fragmentinput_fragment.texel_base };
    float4 pixel = (float4)0;

    float2 dx = ddx(input.texel);
    float2 dy = ddy(input.texel);
    float2 direction = ((abs(dx) >= abs(dy)) ? dx : dy);
    if ((input.sampling == 0u)) {
        float2 whole = floor(input.texel);
        float2 biased = ((input.texel_base + whole) + floor(((input.texel - whole) + (direction * 0.0009765625))));
        int2 nearest = naga_f2i32(clamp(biased, (0.0).xx, (input.uv_bounds.zw - (1.0).xx)));
        float4 _e39 = image.Load(int3(asint(asuint(naga_f2i32(input.uv_bounds.xy)) + asuint(nearest)), int(0)));
        pixel = _e39;
    } else {
        float4 _e49 = image.SampleLevel(filtering, clamp(input.uv, input.uv_bounds.xy, input.uv_bounds.zw), 0.0);
        pixel = _e49;
    }
    float4 _e50 = pixel;
    float _e59 = pixel.w;
    return float4(((_e50.xyz * input.tint.xyz) * input.tint.w), (_e59 * input.tint.w));
}
