// language: metal2.4
#include <metal_stdlib>
#include <simd/simd.h>

using metal::uint;

struct Output {
    metal::float4 position;
    metal::float2 uv;
    char _pad2[8];
    metal::float4 tint;
    metal::float4 uv_bounds;
    metal::float2 texel;
    uint sampling;
    char _pad6[4];
    metal::float2 texel_base;
    char _pad7[8];
};
metal::int2 naga_f2i32(metal::float2 value) {
    return static_cast<metal::int2>(metal::clamp(value, -2147483600.0, 2147483500.0));
}


struct fragment_Input {
    metal::float2 uv [[user(loc0), center_perspective]];
    metal::float4 tint [[user(loc1), center_perspective]];
    metal::float4 uv_bounds [[user(loc2), flat]];
    metal::float2 texel [[user(loc3), center_perspective]];
    uint sampling [[user(loc4), flat]];
    metal::float2 texel_base [[user(loc5), flat]];
};
struct fragment_Output {
    metal::float4 member [[color(0)]];
};
fragment fragment_Output fragment_(
  fragment_Input varyings [[stage_in]]
, metal::float4 position [[position]]
, metal::texture2d<float, metal::access::sample> image [[texture(0)]]
, metal::sampler filtering [[sampler(0)]]
) {
    const Output input = { position, varyings.uv, {}, varyings.tint, varyings.uv_bounds, varyings.texel, varyings.sampling, {}, varyings.texel_base };
    metal::float4 pixel = {};
    metal::float2 dx = metal::dfdx(input.texel);
    metal::float2 dy = metal::dfdy(input.texel);
    metal::float2 direction = metal::select(dy, dx, metal::abs(dx) >= metal::abs(dy));
    if (input.sampling == 0u) {
        metal::float2 whole = metal::floor(input.texel);
        metal::float2 biased = (input.texel_base + whole) + metal::floor((input.texel - whole) + (direction * 0.0009765625));
        metal::int2 nearest = naga_f2i32(metal::clamp(biased, metal::float2(0.0), input.uv_bounds.zw - metal::float2(1.0)));
        uint clamped_lod_e39 = metal::min(uint(0), image.get_num_mip_levels() - 1);
        metal::float4 _e39 = image.read(metal::min(metal::uint2(as_type<metal::int2>(as_type<metal::uint2>(naga_f2i32(input.uv_bounds.xy)) + as_type<metal::uint2>(nearest))), metal::uint2(image.get_width(clamped_lod_e39), image.get_height(clamped_lod_e39)) - 1), clamped_lod_e39);
        pixel = _e39;
    } else {
        metal::float4 _e49 = image.sample(filtering, metal::clamp(input.uv, input.uv_bounds.xy, input.uv_bounds.zw), metal::level(0.0));
        pixel = _e49;
    }
    metal::float4 _e50 = pixel;
    float _e59 = pixel.w;
    return fragment_Output { metal::float4((_e50.xyz * input.tint.xyz) * input.tint.w, _e59 * input.tint.w) };
}
