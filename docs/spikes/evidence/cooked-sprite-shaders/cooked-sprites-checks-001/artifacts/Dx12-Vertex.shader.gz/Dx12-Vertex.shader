struct NagaConstants {
    int first_vertex;
    int first_instance;
    uint other;
};
ConstantBuffer<NagaConstants> _NagaConstants: register(b1);

struct Input {
    float3 position : LOC0;
    float2 uv : LOC1;
    float4 tint : LOC2;
    float4 uv_bounds : LOC3;
    float2 texel : LOC4;
    nointerpolation uint sampling : LOC5;
};

struct Output {
    float4 position : SV_Position;
    float2 uv : LOC0;
    float4 tint : LOC1;
    nointerpolation float4 uv_bounds : LOC2;
    float2 texel : LOC3;
    nointerpolation uint sampling : LOC4;
    nointerpolation float2 texel_base : LOC5;
};

cbuffer camera : register(b0) { row_major float4x4 camera; }

struct VertexOutput_vertex {
    float2 uv : LOC0;
    float4 tint : LOC1;
    nointerpolation float4 uv_bounds : LOC2;
    float2 texel : LOC3;
    nointerpolation uint sampling : LOC4;
    nointerpolation float2 texel_base : LOC5;
    float4 position : SV_Position;
};

VertexOutput_vertex vertex(Input input)
{
    Output out_ = (Output)0;

    float4x4 _e4 = camera;
    out_.position = mul(float4(input.position, 1.0), _e4);
    out_.uv = input.uv;
    out_.tint = input.tint;
    out_.uv_bounds = input.uv_bounds;
    out_.texel = input.texel;
    out_.sampling = input.sampling;
    out_.texel_base = input.uv;
    Output _e21 = out_;
    const Output output = _e21;
    const VertexOutput_vertex output_1 = { output.uv, output.tint, output.uv_bounds, output.texel, output.sampling, output.texel_base, output.position };
    return output_1;
}
