from pathlib import Path
import subprocess,os,json,hashlib
root=Path("/Users/andreyyurlov/.codex/worktrees/cooked-visual-assets/incant")
out=Path(__file__).parent
env=dict(os.environ,PATH="/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:"+os.environ["PATH"],CARGO_TARGET_DIR="/tmp/incant-dynamic-resolution-target",CARGO_BUILD_JOBS="2")
checks=[("cpu",["tools/cargo","test","--locked","-p","incant_render","-p","incant_render_gpu_host"]),("clippy",["tools/cargo","clippy","--locked","-p","incant_render","-p","incant_render_gpu_host","--all-targets","--","-D","warnings"]),("web",["tools/cargo","check","--locked","-p","incant_render","--lib","--target","wasm32-unknown-unknown"]),("fmt",["tools/cargo","fmt","--all","--","--check"]),("conventions",["python3","tools/generate_conventions.py","--check"]),("diff",["git","diff","--check"])]
records=[]
for name,argv in checks:
 path=out/(name+".log")
 with path.open("wb") as f: code=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 records.append(dict(name=name,argv=argv,exit=code,log=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
 (out/"checks.json").write_text(json.dumps(records,indent=2)+"\n")
 print(name,code,flush=True)
 if code: raise SystemExit(code)
