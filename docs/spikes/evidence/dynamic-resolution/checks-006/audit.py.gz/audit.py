from pathlib import Path
import json,gzip,hashlib,re,subprocess
repo=Path('/Users/andreyyurlov/.codex/worktrees/cooked-visual-assets/incant');h=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((repo/'docs/spikes/evidence/dynamic-resolution.json').read_text())
for r in m['sources']:
 assert h((repo/r['path']).read_bytes())==r['sha256'],r['path']
 assert h(Path(r['copy']).read_bytes())==r['sha256'],r['copy']
for r in m['artifacts']:
 b=(repo/r['retained']).read_bytes();assert h(b)==r['sha256'];raw=gzip.decompress(b)
 assert h(raw)==r['raw_sha256'] and len(raw)==r['bytes'];assert Path(r['original']).read_bytes()==raw
for c in m['checks']:
 assert c['exit']==0;assert h(Path(c['log']).read_bytes())==c['sha256']
log=Path(next(c['log'] for c in m['checks'] if c['name']=='cpu')).read_text();g=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',log)
assert m['test_counts']==dict(groups=len(g),passed=sum(int(x[0]) for x in g),failed=sum(int(x[1]) for x in g),ignored=sum(int(x[2]) for x in g))
for b in m['binaries']:
 raw=Path(b['path']).read_bytes();assert h(raw)==b['sha256'] and len(raw)==b['bytes']
for path in subprocess.check_output(['git','ls-files','*.wgsl'],cwd=repo,text=True).splitlines():
 assert subprocess.check_output(['git','show',m['base']+':'+path],cwd=repo)==(repo/path).read_bytes(),path
assert subprocess.check_output(['git','show',m['base']+':Cargo.lock'],cwd=repo)==(repo/'Cargo.lock').read_bytes()
print(json.dumps(dict(sources=len(m['sources']),artifacts=len(m['artifacts']),checks=len(m['checks']),binaries=len(m['binaries']),tests=m['test_counts'],all_wgsl_and_lock_unchanged=True)))
