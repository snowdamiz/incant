// Generated trusted static descriptors. Do not load from project data.
use crate::{Import, ModuleExports};
use std::ffi::c_void;
unsafe extern "C" {
 fn incant_m4_create(cb:Import,ctx:*mut c_void,out:*mut *mut c_void)->i32;
 fn incant_m4_update(p:*mut c_void,cb:Import,ctx:*mut c_void,e:i64,dt:f64)->i32;
 fn incant_m4_free(p:*mut c_void);
}
pub fn linked(name: &str) -> Option<ModuleExports> { match name {
"animation-poses" => Some(unsafe { ModuleExports::from_linked(incant_m4_create, incant_m4_update, incant_m4_free) }),
_ => None } }
