from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path('/Users/andreyyurlov/.codex/worktrees/ci-build-cache/incant');o=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/audio-transport-main161-001');o.mkdir(exist_ok=False)
target=Path('/Users/andreyyurlov/.codex/incant-compound-integration-target');env=dict(os.environ,CARGO_TARGET_DIR=str(target));env['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/Users/andreyyurlov/.local/share/fnm/node-versions/v22.23.3/installation/bin:/opt/homebrew/opt/llvm/bin:/opt/homebrew/bin:'+env['PATH']
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not git('status','--porcelain');assert json.loads((target/'incant-checkout-owner.json').read_text())['checkout']==str(r)
head=git('rev-parse','HEAD');assert head=='ae013e20eb2b60a1440fe20cf7b92d1e481ab44e'
paths=git('ls-files','crates','editor/app','tools','sdk','schemas','third_party','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo','.gitattributes','.github').splitlines();freeze={p:h(r/p) for p in paths if (r/p).is_file()};(o/'freeze.json').write_text(json.dumps({'head':head,'main':'f66f5d9fa4c813dee5600168f5411bfe3100c2ae','producer':'ad669a3d6d83c7070c7907956146ec061abed321','pending_hud':'33fc77c3f0a7fecee0bd48c2611c200d45376558','files':freeze},indent=2)+'\n')
changed=git('diff','--name-only','75503a64^','ad669a3d','--','crates','tools','sdk','Cargo.toml','Cargo.lock').splitlines();accepted={p:{'integrated':h(r/p),'producer':hashlib.sha256(subprocess.check_output(['git','show','ad669a3d:'+p],cwd=r)).hexdigest()} for p in changed};assert {p for p,v in accepted.items() if v['integrated']!=v['producer']}=={'crates/incant_script/src/commands.rs','sdk/ts/src/native.d.ts'};(o/'accepted-sources.json').write_text(json.dumps(accepted,indent=2)+'\n')
producer=json.loads((r/'docs/spikes/evidence/native-audio-transport.json').read_text());cmds=[(c['name'],c['command']) for c in producer['checks'] if c['name'] not in {'mixer','script'}];cmds.append(('public-export',['python3','tools/probes/native-audio-checkpoint-export.py',str(o/'public-export'),'--binary',str(o/'incant_headless'),'--transport']))
results=[]
for name,cmd in cmds:
 assert all(h(r/p)==v for p,v in freeze.items());print('starting',name,flush=True);start=time.monotonic()
 with (o/(name+'.log')).open('w') as log:rc=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 results.append({'name':name,'command':cmd,'exit':rc,'seconds':time.monotonic()-start,'sha256':h(o/(name+'.log'))});(o/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,rc,flush=True)
 if rc:raise SystemExit(rc)
 if name=='headless':
  src=target/'ci/incant_headless';dst=o/'incant_headless';shutil.copy2(src,dst);(o/'headless-binary.json').write_text(json.dumps({'source_head':head,'profile':'ci','features':[],'sha256':h(dst),'bytes':dst.stat().st_size},indent=2)+'\n')
 assert all(h(r/p)==v for p,v in freeze.items())
