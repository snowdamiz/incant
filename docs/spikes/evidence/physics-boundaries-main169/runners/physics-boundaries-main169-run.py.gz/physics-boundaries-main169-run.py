from pathlib import Path
import os,subprocess,json,time,hashlib
r=Path('/Users/andreyyurlov/.codex/worktrees/native-fbx-import/incant');o=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/physics-boundaries-main169-001');o.mkdir(exist_ok=False)
target=Path('/Users/andreyyurlov/.codex/incant-compound-wasm-integration-target');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
assert not git('status','--porcelain');assert git('rev-parse','--short=8','HEAD')=='bc85c676';assert json.loads((target/'incant-checkout-owner.json').read_text())['checkout']==str(r)
paths=git('ls-files','crates','tools','sdk','schemas','third_party','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo').splitlines();freeze={p:h(r/p) for p in paths if (r/p).is_file()};(o/'freeze.json').write_text(json.dumps({'head':git('rev-parse','HEAD'),'root':str(r),'files':freeze},indent=2)+'\n')
producer=[]
for commit,prefix in [('a468be2a','crates'),('08185b27','tools')]:
 for p in git('diff','--name-only',commit+'^',commit,'--',prefix).splitlines():
  b=subprocess.check_output(['git','show',commit+':'+p],cwd=r);assert hashlib.sha256(b).hexdigest()==h(r/p),p;producer.append({'commit':commit,'path':p,'sha256':h(r/p)})
(o/'producer.json').write_text(json.dumps(producer,indent=2)+'\n')
e=dict(os.environ,CARGO_TARGET_DIR=str(target));e['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/opt/homebrew/bin:'+e['PATH'];results=[]
def run(name,cmd,expected=0):
 assert all(h(r/p)==v for p,v in freeze.items());print('starting',name,flush=True);start=time.monotonic()
 with (o/(name+'.stdout')).open('wb') as out,(o/(name+'.stderr')).open('wb') as err:rc=subprocess.run(cmd,cwd=r,env=e,stdout=out,stderr=err).returncode
 rec={'name':name,'command':cmd,'exit':rc,'expected_exit':expected,'seconds':time.monotonic()-start}
 for suffix in ['stdout','stderr']:rec[suffix]={'path':str(o/(name+'.'+suffix)),'sha256':h(o/(name+'.'+suffix))}
 results.append(rec);(o/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,rc,flush=True)
 assert all(h(r/p)==v for p,v in freeze.items())
 if rc!=expected:raise SystemExit(rc or 1)
base=['--locked','--profile','ci','-j2','-p','incant_physics_runtime','-p','incant_physics_2d_runtime','--message-format=json']
for mode,extra in [('deterministic',[]),('fast',['--no-default-features']),('fast-simd8',['--no-default-features','--features','incant_physics_runtime/fast-simd8,incant_physics_2d_runtime/fast-simd8'])]:
 for action in ['test','clippy']:run(mode+'-'+action,['./tools/cargo',action]+base+extra+(['--all-targets','--','-D','warnings'] if action=='clippy' else []))
for mode,extra in [('deterministic',[]),('fast',['--no-default-features'])]:run('wasm-'+mode,['./tools/cargo','check']+base+extra+['--target','wasm32-unknown-unknown'])
run('conflicting-modes',['./tools/cargo','check']+base+['--features','incant_physics_runtime/fast-simd8,incant_physics_2d_runtime/fast-simd8'],101)
assert 'cannot be enabled' in (o/'conflicting-modes.stderr').read_text() or 'cannot be enabled' in (o/'conflicting-modes.stdout').read_text()
manifest='tools/probes/physics-snapshot-boundary/Cargo.toml'
run('diagnostic',['./tools/cargo','run','--locked','--release','-j2','--manifest-path',manifest])
rows=json.loads((o/'diagnostic.stdout').read_text());assert len(rows)==8 and sum(x['continued_ticks'] for x in rows)==960 and all(x['trusted_clone_exact'] and not x['untrusted_bytes_decoded'] for x in rows)
run('diagnostic-clippy',['./tools/cargo','clippy','--locked','--release','-j2','--manifest-path',manifest,'--all-targets','--','-D','warnings'])
run('fmt',['./tools/cargo','fmt','--all','--','--check']);run('diagnostic-fmt',['./tools/cargo','fmt','--manifest-path',manifest,'--','--check']);run('conventions',['python3','tools/generate_conventions.py','--check']);run('diff',['git','diff','--check']);print('all terminal',flush=True)
