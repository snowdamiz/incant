from pathlib import Path
import json,gzip,hashlib,subprocess,re,shutil
r=Path('/Users/andreyyurlov/.codex/worktrees/native-fbx-import/incant');o=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/physics-boundaries-main169-001');d=r/'docs/spikes/evidence/physics-boundaries-main169';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();hb=lambda b:hashlib.sha256(b).hexdigest();j=lambda p:json.loads(p.read_text());git=lambda *a:subprocess.check_output(['git',*a],cwd=r,text=True).strip()
f=j(o/'freeze.json');assert all(h(r/p)==v for p,v in f['files'].items());checks=j(o/'results.json');assert len(checks)==15 and all(x['exit']==x['expected_exit'] for x in checks)
for x in checks:
 for stream in ['stdout','stderr']:assert h(Path(x[stream]['path']))==x[stream]['sha256']
counts={};features={}
original=j(r/'docs/spikes/evidence/physics-runtime-variants.json')
for name in ['deterministic-test','fast-test','fast-simd8-test','wasm-deterministic','wasm-fast']:
 text=(o/(name+'.stdout')).read_text();features[name]={}
 for line in text.splitlines():
  if not line.startswith('{'):continue
  q=json.loads(line)
  if q.get('reason')!='compiler-artifact':continue
  for n in ['simba','parry2d','parry3d','rapier2d','rapier3d']:
   if '#'+n+'@' in q['package_id']:features[name][n]=q['features']
 assert features[name]==original['actual_compiler_features'][name],name
 if name.endswith('-test'):
  rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',text);total=[sum(int(x[i]) for x in rows) for i in range(3)];assert total==[10,0,0];counts[name]={'passed':10,'failed':0,'ignored':0,'groups':len(rows)}
(o/'feature-comparison.json').write_text(json.dumps({'exact_original_features':True,'actual':features},indent=2)+'\n')
rows=j(o/'diagnostic.stdout');assert len(rows)==8 and sum(x['continued_ticks'] for x in rows)==960 and all(x['trusted_clone_exact'] and not x['untrusted_bytes_decoded'] for x in rows)
original_rows=j(r/'docs/spikes/evidence/native-physics-snapshot-boundary/result-003.json');assert rows==original_rows
(o/'diagnostic-comparison.json').write_text(json.dumps({'all_eight_results_equal_producer':True,'cases':8,'continuation_ticks':960},indent=2)+'\n')
producer=j(o/'producer.json');assert len(producer)==9 and all(h(r/x['path'])==x['sha256'] for x in producer)
verified=[]
for name in ['physics-runtime-variants','native-physics-snapshot-boundary']:
 for x in j(r/('docs/spikes/evidence/'+name+'.json'))['artifacts']:
  p=r/x.get('path',x.get('retained'));assert h(p)==x['sha256'];raw=gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes();assert hb(raw)==x['raw_sha256'];verified.append({'path':str(p.relative_to(r)),'sha256':h(p),'raw_sha256':hb(raw)})
(o/'producer-artifacts.json').write_text(json.dumps(verified,indent=2)+'\n')
assert git('diff','4fc128f9','HEAD','--','Cargo.toml','Cargo.lock','crates/incant_runtime','crates/incant_script','crates/incant_game_runtime')==''
b=Path('/Users/andreyyurlov/.codex/incant-compound-wasm-integration-target/release/incant-physics-snapshot-boundary-probe');shutil.copy2(b,o/b.name)
binrec={'path':str(o/b.name),'sha256':h(b),'bytes':b.stat().st_size};(o/'binary.json').write_text(json.dumps(binrec,indent=2)+'\n')
d.mkdir(exist_ok=False);art={}
def keep(p,name):
 dst=d/(name+'.gz');dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(gzip.compress(p.read_bytes(),mtime=0));art[str(dst.relative_to(d))]={'sha256':h(dst),'raw_sha256':h(p),'source':str(p),'bytes':p.stat().st_size}
for p in sorted(o.rglob('*')):
 if p.is_file() and p.name!=b.name:keep(p,str(p.relative_to(o)))
for p in [o.parent/'physics-boundaries-main169-run.py',Path(__file__)]:keep(p,'runners/'+p.name)
review=Path('/Users/andreyyurlov/.codex/incant-reviews/physics-runtime-variants-independent-20261012.json');shutil.copy2(review,d/'leaf-review.json')
packet={'scope':'Accepted separately compiled 2D/3D kernel features plus trusted typed physics snapshot diagnostic on actual main169.','tested_source':f['head'],'main':'4fc128f9aba4d5992b9dfd5476d998db7a9a4b7a','source_inputs':len(f['files']),'accepted_source_comparisons':producer,'checks':checks,'test_counts':counts,'count_qualification':'Same ten behavior cases in each of three independently compiled variants; not thirty distinct cases. Diagnostic eight scenarios are not Rust test count.','features_equal_original':True,'diagnostic':{'cases':8,'continuation_ticks':960,'full_result_equal_original':True,'binary':binrec},'artifacts':art,'producer_artifacts_verified':len(verified),'leaf_review':{'path':str((d/'leaf-review.json').relative_to(r)),'sha256':h(review)},'independent_review':'pending integrated final audit','limits':['Deterministic defaults unchanged; project/process feature selection remains separate local work.','No renderer, GPU, phone, performance or numerical backend adoption claim.','Trusted typed solver clone only; no decoder, persisted graph, NativeWorld restore or PhysicsUnsupported relaxation.','No unsafe code added; prior underlying dependency ownership obligations remain open.'],'integration':'STATUS additive only; all nine accepted production/probe source inputs exact; root manifest/lock and runtime/script/session/save unchanged.'}
(r/'docs/spikes/evidence/physics-boundaries-main169.json').write_text(json.dumps(packet,indent=2)+'\n');print(json.dumps({'manifest_sha256':h(r/'docs/spikes/evidence/physics-boundaries-main169.json'),'artifacts':len(art),'sources':len(f['files']),'producer_artifacts':len(verified)}))
