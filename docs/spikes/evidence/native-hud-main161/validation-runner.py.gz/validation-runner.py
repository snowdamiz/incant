from pathlib import Path
import hashlib,json,os,shutil,subprocess,time
r=Path('/Users/andreyyurlov/.codex/worktrees/native-fbx-import/incant');o=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/hud-main160-001');o.mkdir(exist_ok=False)
target=Path('/Users/andreyyurlov/.codex/incant-compound-wasm-integration-target');env=dict(os.environ,CARGO_TARGET_DIR=str(target));env['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/Users/andreyyurlov/.local/share/fnm/node-versions/v22.23.3/installation/bin:/opt/homebrew/opt/llvm/bin:/opt/homebrew/bin:'+env['PATH']
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert not git('status','--porcelain');assert json.loads((target/'incant-checkout-owner.json').read_text())['checkout']==str(r)
head=git('rev-parse','HEAD');assert head=='33fc77c3f0a7fecee0bd48c2611c200d45376558'
paths=git('ls-files','crates','editor/app','tools','sdk','schemas','third_party','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo','.gitattributes','.github').splitlines();freeze={p:h(r/p) for p in paths if (r/p).is_file()};(o/'freeze.json').write_text(json.dumps({'head':head,'main':'d1ef35ee32b92e6756b528463ab092fdc79c7ef4','producer':'78fae9a10795622b89dbbd20c69382455c1343f8','pending_root_motion':'163563fccc80865ba50180c714c1baba4f643441','files':freeze},indent=2)+'\n')
changed=git('diff','--name-only','a16491d7^','a16491d7','--','crates','tools','sdk','Cargo.toml','Cargo.lock').splitlines();assert all((r/p).read_bytes()==subprocess.check_output(['git','show','78fae9a:'+p],cwd=r) for p in changed);(o/'accepted-sources.json').write_text(json.dumps({p:h(r/p) for p in changed},indent=2)+'\n')
c=['--locked','--profile','ci','-j2']
cmds=[('affected-tests',['./tools/cargo','test']+c+['-p','incant_runtime','-p','incant_script','-p','incant_render_game','--features','incant_script/compiler']),('player-tests',['./tools/cargo','test']+c+['-p','incant_game_player','--features','render-input']),('clippy',['./tools/cargo','clippy']+c+['-p','incant_runtime','-p','incant_script','-p','incant_render_game','-p','incant_game_player','--features','incant_script/compiler,incant_game_player/render-input','--all-targets','--','-D','warnings']),('no-compiler',['./tools/cargo','check']+c+['-p','incant_script','--no-default-features','--features','ui,audio,static-module']),('wasm32',['./tools/cargo','check']+c+['-p','incant_runtime','--target','wasm32-unknown-unknown']),('strict-sdk',['node','node_modules/typescript/bin/tsc','--noEmit','-p','sdk/ts/tsconfig.json']),('generated-sdk',['node','tools/generate_sdk.mjs','--check']),('bridge',['node','tools/build_bridge.mjs','--check']),('graph',['python3','tools/check_runtime_dependencies.py','incant_runtime','incant_script','incant_game_runtime','incant_render_game','incant_game_player','--features','incant_game_player/render-input']),('headless',['./tools/cargo','build']+c+['-p','incant_headless']),('fmt',['./tools/cargo','fmt','--all','--check']),('conventions',['python3','tools/generate_conventions.py','--check']),('diff',['git','diff','--check']),('public-export',['python3','tools/probes/native-hud-export.py',str(o/'public-export'),'--binary',str(o/'incant_headless')])]
results=[]
for name,cmd in cmds:
 assert all(h(r/p)==v for p,v in freeze.items());print('starting',name,flush=True);start=time.monotonic()
 with (o/(name+'.log')).open('w') as log:rc=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 results.append({'name':name,'command':cmd,'exit':rc,'seconds':time.monotonic()-start,'sha256':h(o/(name+'.log'))});(o/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,rc,flush=True)
 if rc:raise SystemExit(rc)
 if name=='headless':
  src=target/'ci/incant_headless';dst=o/'incant_headless';shutil.copy2(src,dst);(o/'headless-binary.json').write_text(json.dumps({'source_head':head,'profile':'ci','features':[],'sha256':h(dst),'bytes':dst.stat().st_size},indent=2)+'\n')
 assert all(h(r/p)==v for p,v in freeze.items())
