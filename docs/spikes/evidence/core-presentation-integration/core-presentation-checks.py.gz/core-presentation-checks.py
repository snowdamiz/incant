from pathlib import Path
import json,hashlib,subprocess,os,time
r=Path('/Users/andreyyurlov/.codex/worktrees/local-service-stack/incant');o=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/core-presentation-main162-002');o.mkdir(exist_ok=False)
a=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/audio-transport-main161-001');h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
f=json.loads((a/'freeze.json').read_text());assert all(h(r/p)==v for p,v in f['files'].items());b=a/'incant_headless';m=json.loads((a/'headless-binary.json').read_text());assert h(b)==m['sha256']
freeze=json.loads((o.parent/'core-presentation-main162-001/freeze.json').read_text());assert all(h(r/p)==v for p,v in freeze['files'].items());(o/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
env=dict(os.environ);env['PATH']='/Users/andreyyurlov/.local/share/fnm/node-versions/v22.23.3/installation/bin:/opt/homebrew/bin:'+env['PATH']
checks=[('types',['node_modules/.bin/tsc','-p','samples/core/tsconfig.json']),('gameplay',['python3','samples/core/verify.py',str(o/'gameplay'),'--binary',str(b)]),('syntax',['python3','-c',"import ast;from pathlib import Path;ast.parse(Path('samples/core/verify_presentation.py').read_text())"]),('conventions',['python3','tools/generate_conventions.py','--check']),('diff',['git','diff','--check'])]
result=[]
for n,c in checks:
 print('starting',n,flush=True);start=time.monotonic()
 with (o/(n+'.log')).open('w') as out:rc=subprocess.run(c,cwd=r,env=env,stdout=out,stderr=subprocess.STDOUT).returncode
 result.append({'name':n,'command':c,'exit':rc,'seconds':time.monotonic()-start,'sha256':h(o/(n+'.log'))});(o/'results.json').write_text(json.dumps(result,indent=2)+'\n');print(n,rc,flush=True)
 if rc:raise SystemExit(rc)
 assert all(h(r/p)==v for p,v in freeze['files'].items())
