from pathlib import Path
import os,subprocess,time,json,hashlib,sys
root=Path('/Users/andreyyurlov/.codex/worktrees/cooked-visual-assets/incant')
out=Path(__file__).parent
freeze=json.loads(Path('/Users/andreyyurlov/.codex/incant-evidence/motion-history-source-001/freeze.json').read_text())
def verify():
 for row in freeze['sources']+freeze['unchanged_baselines']:
  assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
verify()
env=os.environ.copy();env['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:'+env.get('PATH','');env['CARGO_TARGET_DIR']='/tmp/incant-cpu-profiler-target'
commands=[
 ('cpu-all', ['tools/cargo','test','--locked','--profile','ci','-j2','-p','incant_render','-p','incant_render_gpu_host']),
 ('clippy-all', ['tools/cargo','clippy','--locked','--profile','ci','-j2','-p','incant_render','-p','incant_render_gpu_host','--all-targets','--','-D','warnings']),
 ('cooked-refusal', ['tools/cargo','test','--locked','--profile','ci','-j2','-p','incant_render','--features','cooked-output,cooked-geometry,cooked-sprites,cooked-ui,cooked-text,cooked-materials,cooked-clusters','motion']),
 ('wasm-check', ['tools/cargo','check','--locked','--profile','ci','-j2','-p','incant_render','-p','incant_render_gpu_host','--target','wasm32-unknown-unknown','--lib']),
 ('runtime-graph',['python3','tools/check_runtime_dependencies.py','incant_render','incant_render_gpu_host']),
 ('format',['tools/cargo','fmt','--all','--','--check']),
 ('conventions',['python3','tools/generate_conventions.py','--check']),
]
results=[]
for label,argv in commands:
 verify();start=time.time();log=out/(label+'.log')
 with log.open('wb') as f:
  child=subprocess.Popen(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
  try:code=child.wait()
  except BaseException:
   child.terminate()
   try:child.wait(timeout=10)
   except subprocess.TimeoutExpired:child.kill();child.wait()
   raise
 verify();row={'label':label,'argv':argv,'exit':code,'elapsed_seconds':time.time()-start,'pid':child.pid,'reaped':True,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()};results.append(row)
 (out/'checks.json').write_text(json.dumps(results,indent=2)+'\n');print(label,code,flush=True)
 if code:sys.exit(code)
