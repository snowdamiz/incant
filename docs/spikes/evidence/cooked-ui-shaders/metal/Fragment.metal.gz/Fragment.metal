// language: metal2.4
#include <metal_stdlib>
#include <simd/simd.h>

using metal::uint;

struct Frame {
    metal::float4 region;
    metal::float2 scale;
    metal::float2 surface;
    metal::float4 encode;
};
struct Varyings {
    metal::float4 position;
    metal::float2 texel;
    char _pad2[8];
    metal::float4 texels;
    metal::float4 rect;
    metal::float2 shape;
    char _pad5[8];
    metal::float4 color;
    uint kind;
    char _pad7[12];
};

float rounded(
    metal::float2 p,
    metal::float2 half_,
    float radius
) {
    metal::float2 q = (metal::abs(p) - half_) + metal::float2(radius);
    return (metal::length(metal::max(q, metal::float2(0.0))) + metal::min(metal::max(q.x, q.y), 0.0)) - radius;
}

metal::float3 decode(
    metal::float3 c
) {
    return metal::select(metal::pow((c + metal::float3(0.055)) / metal::float3(1.055), metal::float3(2.4)), c / metal::float3(12.92), c <= metal::float3(0.04045));
}
uint naga_f2u32(float value) {
    return static_cast<uint>(metal::clamp(value, 0.0, 4294967000.0));
}


struct fragment_Input {
    metal::float2 texel [[user(loc0), center_perspective]];
    metal::float4 texels [[user(loc1), flat]];
    metal::float4 rect [[user(loc2), flat]];
    metal::float2 shape [[user(loc3), flat]];
    metal::float4 color [[user(loc4), flat]];
    uint kind [[user(loc5), flat]];
};
struct fragment_Output {
    metal::float4 member [[color(0)]];
};
fragment fragment_Output fragment_(
  fragment_Input varyings [[stage_in]]
, metal::float4 position [[position]]
, constant Frame& frame [[buffer(0)]]
, metal::texture2d<float, metal::access::sample> atlas [[texture(0)]]
, metal::sampler bilinear [[sampler(0)]]
) {
    const Varyings input = { position, varyings.texel, {}, varyings.texels, varyings.rect, varyings.shape, {}, varyings.color, varyings.kind };
    float coverage = 1.0;
    float sum = 0.0;
    uint j = 0u;
    uint i = {};
    metal::float3 color = {};
    metal::float2 dx = metal::dfdx(input.texel);
    metal::float2 dy = metal::dfdy(input.texel);
    if (input.kind == 2u) {
        uint taps = naga_f2u32(metal::clamp(metal::ceil(metal::max(metal::length(dx), metal::length(dy)) - 0.25), 1.0, 4.0));
        metal::float2 size = static_cast<metal::float2>(metal::uint2(atlas.get_width(), atlas.get_height()));
        metal::float2 low = input.texels.xy + metal::float2(0.5);
        metal::float2 high = input.texels.zw - metal::float2(0.5);
        uint2 loop_bound = uint2(4294967295u);
        bool loop_init = true;
        while(true) {
            if (metal::all(loop_bound == uint2(0u))) { break; }
            loop_bound -= uint2(loop_bound.y == 0u, 1u);
            if (!loop_init) {
                uint _e77 = j;
                j = _e77 + 1u;
            }
            loop_init = false;
            uint _e37 = j;
            if (_e37 < taps) {
            } else {
                break;
            }
            {
                i = 0u;
                uint2 loop_bound_1 = uint2(4294967295u);
                bool loop_init_1 = true;
                while(true) {
                    if (metal::all(loop_bound_1 == uint2(0u))) { break; }
                    loop_bound_1 -= uint2(loop_bound_1.y == 0u, 1u);
                    if (!loop_init_1) {
                        uint _e74 = i;
                        i = _e74 + 1u;
                    }
                    loop_init_1 = false;
                    uint _e41 = i;
                    if (_e41 < taps) {
                    } else {
                        break;
                    }
                    {
                        uint _e43 = i;
                        uint _e45 = j;
                        metal::float2 offset = ((metal::float2(static_cast<float>(_e43), static_cast<float>(_e45)) + metal::float2(0.5)) / metal::float2(static_cast<float>(taps))) - metal::float2(0.5);
                        metal::float2 at = metal::clamp((input.texel + (dx * offset.x)) + (dy * offset.y), low, high);
                        float _e65 = sum;
                        metal::float4 _e70 = atlas.sample(bilinear, at / size, metal::level(0.0));
                        sum = _e65 + _e70.x;
                    }
                }
            }
        }
        float _e79 = sum;
        coverage = _e79 / static_cast<float>(taps * taps);
    } else {
        metal::float2 p_1 = input.position.xy;
        metal::float2 center = (input.rect.xy + input.rect.zw) * 0.5;
        metal::float2 half_1 = metal::max((input.rect.zw - input.rect.xy) * 0.5, metal::float2(0.0));
        float radius_1 = metal::min(input.shape.x, metal::min(half_1.x, half_1.y));
        float _e109 = rounded(p_1 - center, half_1, radius_1);
        coverage = metal::clamp(0.5 - _e109, 0.0, 1.0);
        if (input.kind == 1u) {
            metal::float2 inner = half_1 - metal::float2(input.shape.y);
            if (metal::all(inner > metal::float2(0.0))) {
                float _e132 = rounded(p_1 - center, inner, metal::max(radius_1 - input.shape.y, 0.0));
                float hole = metal::clamp(0.5 - _e132, 0.0, 1.0);
                float _e138 = coverage;
                coverage = metal::max(_e138 - hole, 0.0);
            }
        }
    }
    float _e144 = coverage;
    float alpha = input.color.w * _e144;
    if (alpha <= 0.0) {
        metal::discard_fragment();
    }
    color = input.color.xyz;
    float _e154 = frame.encode.x;
    if (_e154 == 0.0) {
        metal::float3 _e157 = color;
        metal::float3 _e158 = decode(_e157);
        color = _e158;
    }
    metal::float3 _e159 = color;
    return fragment_Output { metal::float4(_e159 * alpha, alpha) };
}
