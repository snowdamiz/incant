from pathlib import Path
import json,hashlib,subprocess,time,sys
out=Path(__file__).parent;freeze=json.loads((out/'freeze.json').read_text());root=Path(freeze['root']);rows=[]
h=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
commands=[('version',['xcrun','-sdk','macosx','metal','--version'])]
for stage in ['Vertex','Fragment']:
 metal=out/(stage+'.metal');metal.write_bytes((out/'artifacts'/('Metal-'+stage+'.shader')).read_bytes())
 commands += [(stage+'-compile',['xcrun','-sdk','macosx','metal','-std=macos-metal2.4','-c',str(metal),'-o',str(out/(stage+'.air'))]),(stage+'-link',['xcrun','-sdk','macosx','metallib',str(out/(stage+'.air')),'-o',str(out/(stage+'.metallib'))])]
for name,cmd in commands:
 start=time.monotonic();r=subprocess.run(cmd,capture_output=True,timeout=180)
 for suffix,data in [('stdout',r.stdout),('stderr',r.stderr)]: (out/(name+'.'+suffix)).write_bytes(data)
 rows.append({'name':name,'command':cmd,'exit':r.returncode,'seconds':time.monotonic()-start,'stdout_sha256':h(out/(name+'.stdout')),'stderr_sha256':h(out/(name+'.stderr'))});(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 assert all(h(root/f['path'])==f['sha256'] for f in freeze['sources'])
 if r.returncode:raise SystemExit(r.returncode)
(out/'result.json').write_text(json.dumps({'passed':True,'source_unchanged':True,'native_compiler_only':True,'gpu_submitted':False,'commands':len(rows)})+'\n')
