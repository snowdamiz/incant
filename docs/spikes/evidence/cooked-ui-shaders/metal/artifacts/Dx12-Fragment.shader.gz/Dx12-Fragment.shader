struct NagaConstants {
    int first_vertex;
    int first_instance;
    uint other;
};
ConstantBuffer<NagaConstants> _NagaConstants: register(b1);

struct Frame {
    float4 region;
    float2 scale;
    float2 surface;
    float4 encode;
};

struct Varyings {
    float4 position : SV_Position;
    float2 texel : LOC0;
    nointerpolation float4 texels : LOC1;
    nointerpolation float4 rect : LOC2;
    nointerpolation float2 shape : LOC3;
    nointerpolation float4 color : LOC4;
    nointerpolation uint kind : LOC5;
};

cbuffer frame : register(b0) { Frame frame; }
Texture2D<float4> atlas : register(t0);
SamplerState nagaSamplerHeap[2048]: register(s0, space0);
SamplerComparisonState nagaComparisonSamplerHeap[2048]: register(s2048, space0);
StructuredBuffer<uint> nagaGroup1SamplerIndexArray : register(t1, space0);
static const SamplerState bilinear = nagaSamplerHeap[nagaGroup1SamplerIndexArray[0]];

struct FragmentInput_fragment {
    float2 texel : LOC0;
    nointerpolation float4 texels : LOC1;
    nointerpolation float4 rect : LOC2;
    nointerpolation float2 shape : LOC3;
    nointerpolation float4 color_1 : LOC4;
    nointerpolation uint kind : LOC5;
    float4 position : SV_Position;
};

float rounded(float2 p, float2 half_, float radius)
{
    float2 q = ((abs(p) - half_) + (radius).xx);
    return ((length(max(q, (0.0).xx)) + min(max(q.x, q.y), 0.0)) - radius);
}

float3 decode(float3 c)
{
    return ((c <= (0.04045).xxx) ? (c / (12.92).xxx) : pow(((c + (0.055).xxx) / (1.055).xxx), (2.4).xxx));
}

uint naga_f2u32(float value) {
    return uint(clamp(value, 0.0, 4294967000.0));
}

uint2 NagaDimensions2D(Texture2D<float4> tex)
{
    uint4 ret;
    tex.GetDimensions(0, ret.x, ret.y, ret.z);
    return ret.xy;
}

float4 fragment(FragmentInput_fragment fragmentinput_fragment) : SV_Target0
{
    Varyings input = { fragmentinput_fragment.position, fragmentinput_fragment.texel, fragmentinput_fragment.texels, fragmentinput_fragment.rect, fragmentinput_fragment.shape, fragmentinput_fragment.color_1, fragmentinput_fragment.kind };
    float coverage = 1.0;
    float sum = 0.0;
    uint j = 0u;
    uint i = (uint)0;
    float3 color = (float3)0;

    float2 dx = ddx(input.texel);
    float2 dy = ddy(input.texel);
    if ((input.kind == 2u)) {
        uint taps = naga_f2u32(clamp(ceil((max(length(dx), length(dy)) - 0.25)), 1.0, 4.0));
        float2 size = float2(NagaDimensions2D(atlas));
        float2 low = (input.texels.xy + (0.5).xx);
        float2 high = (input.texels.zw - (0.5).xx);
        uint2 loop_bound = uint2(4294967295u, 4294967295u);
        bool loop_init = true;
        while(true) {
            if (all(loop_bound == uint2(0u, 0u))) { break; }
            loop_bound -= uint2(loop_bound.y == 0u, 1u);
            if (!loop_init) {
                uint _e77 = j;
                j = (_e77 + 1u);
            }
            loop_init = false;
            uint _e37 = j;
            if ((_e37 < taps)) {
            } else {
                break;
            }
            {
                i = 0u;
                uint2 loop_bound_1 = uint2(4294967295u, 4294967295u);
                bool loop_init_1 = true;
                while(true) {
                    if (all(loop_bound_1 == uint2(0u, 0u))) { break; }
                    loop_bound_1 -= uint2(loop_bound_1.y == 0u, 1u);
                    if (!loop_init_1) {
                        uint _e74 = i;
                        i = (_e74 + 1u);
                    }
                    loop_init_1 = false;
                    uint _e41 = i;
                    if ((_e41 < taps)) {
                    } else {
                        break;
                    }
                    {
                        uint _e43 = i;
                        uint _e45 = j;
                        float2 offset = (((float2(float(_e43), float(_e45)) + (0.5).xx) / (float(taps)).xx) - (0.5).xx);
                        float2 at = clamp(((input.texel + (dx * offset.x)) + (dy * offset.y)), low, high);
                        float _e65 = sum;
                        float4 _e70 = atlas.SampleLevel(bilinear, (at / size), 0.0);
                        sum = (_e65 + _e70.x);
                    }
                }
            }
        }
        float _e79 = sum;
        coverage = (_e79 / float((taps * taps)));
    } else {
        float2 p_1 = input.position.xy;
        float2 center_ = ((input.rect.xy + input.rect.zw) * 0.5);
        float2 half_1 = max(((input.rect.zw - input.rect.xy) * 0.5), (0.0).xx);
        float radius_1 = min(input.shape.x, min(half_1.x, half_1.y));
        const float _e109 = rounded((p_1 - center_), half_1, radius_1);
        coverage = clamp((0.5 - _e109), 0.0, 1.0);
        if ((input.kind == 1u)) {
            float2 inner = (half_1 - (input.shape.y).xx);
            if (all((inner > (0.0).xx))) {
                const float _e132 = rounded((p_1 - center_), inner, max((radius_1 - input.shape.y), 0.0));
                float hole = clamp((0.5 - _e132), 0.0, 1.0);
                float _e138 = coverage;
                coverage = max((_e138 - hole), 0.0);
            }
        }
    }
    float _e144 = coverage;
    float alpha = (input.color.w * _e144);
    if ((alpha <= 0.0)) {
        discard;
    }
    color = input.color.xyz;
    float _e154 = frame.encode.x;
    if ((_e154 == 0.0)) {
        float3 _e157 = color;
        const float3 _e158 = decode(_e157);
        color = _e158;
    }
    float3 _e159 = color;
    return float4((_e159 * alpha), alpha);
}
