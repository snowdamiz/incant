struct NagaConstants {
    int first_vertex;
    int first_instance;
    uint other;
};
ConstantBuffer<NagaConstants> _NagaConstants: register(b1);

struct Frame {
    float4 region;
    float2 scale;
    float2 surface;
    float4 encode;
};

struct Quad {
    float4 rect : LOC0;
    float4 clip_ : LOC1;
    float4 extra : LOC2;
    float2 pen : LOC3;
    float4 color : LOC4;
    nointerpolation uint kind : LOC5;
};

struct Varyings {
    float4 position : SV_Position;
    float2 texel : LOC0;
    nointerpolation float4 texels : LOC1;
    nointerpolation float4 rect : LOC2;
    nointerpolation float2 shape : LOC3;
    nointerpolation float4 color : LOC4;
    nointerpolation uint kind : LOC5;
};

cbuffer frame : register(b0) { Frame frame; }

struct VertexOutput_vertex {
    float2 texel : LOC0;
    nointerpolation float4 texels : LOC1;
    nointerpolation float4 rect : LOC2;
    nointerpolation float2 shape : LOC3;
    nointerpolation float4 color : LOC4;
    nointerpolation uint kind : LOC5;
    float4 position : SV_Position;
};

float2 snap(float2 v)
{
    return floor((v + (0.5).xx));
}

float2 physical(float2 logical)
{
    float4 _e3 = frame.region;
    float2 _e7 = frame.scale;
    return (_e3.xy + (logical * _e7));
}

typedef float2 ret_Constructarray6_float2_[6];
ret_Constructarray6_float2_ Constructarray6_float2_(float2 arg0, float2 arg1, float2 arg2, float2 arg3, float2 arg4, float2 arg5) {
    float2 ret[6] = { arg0, arg1, arg2, arg3, arg4, arg5 };
    return ret;
}

VertexOutput_vertex vertex(uint index : SV_VertexID, Quad quad)
{
    float2 p0_ = (float2)0;
    float2 p1_ = (float2)0;
    Varyings out_ = (Varyings)0;

    float2 corners[6] = Constructarray6_float2_(float2(0.0, 0.0), float2(1.0, 0.0), float2(0.0, 1.0), float2(0.0, 1.0), float2(1.0, 0.0), float2(1.0, 1.0));
    if ((quad.kind == 2u)) {
        const float2 _e27 = physical(quad.pen);
        const float2 _e28 = snap(_e27);
        float2 _e33 = frame.scale;
        p0_ = (_e28 + (quad.rect.xy * _e33));
        float2 _e40 = frame.scale;
        p1_ = (_e28 + (quad.rect.zw * _e40));
    } else {
        const float2 _e45 = physical(quad.rect.xy);
        const float2 _e46 = snap(_e45);
        p0_ = _e46;
        const float2 _e49 = physical(quad.rect.zw);
        const float2 _e50 = snap(_e49);
        p1_ = _e50;
    }
    const float2 _e53 = physical(quad.clip_.xy);
    const float2 _e54 = snap(_e53);
    float4 _e57 = frame.region;
    const float2 _e59 = snap(_e57.xy);
    float2 c0_ = max(_e54, _e59);
    const float2 _e63 = physical(quad.clip_.zw);
    const float2 _e64 = snap(_e63);
    float4 _e67 = frame.region;
    float4 _e71 = frame.region;
    const float2 _e74 = snap((_e67.xy + _e71.zw));
    float2 c1_ = min(_e64, _e74);
    float2 _e76 = p0_;
    float2 low = max(_e76, c0_);
    float2 _e78 = p1_;
    float2 high = max(min(_e78, c1_), low);
    float2 q = lerp(low, high, corners[min(uint((_NagaConstants.first_vertex + index)), 5u)]);
    float _e89 = frame.surface.x;
    float _e99 = frame.surface.y;
    out_.position = float4((((q.x / _e89) * 2.0) - 1.0), (1.0 - ((q.y / _e99) * 2.0)), 0.0, 1.0);
    float2 _e113 = p0_;
    float2 _e115 = p1_;
    float2 _e116 = p0_;
    out_.texel = lerp(quad.extra.xy, quad.extra.zw, ((q - _e113) / max((_e115 - _e116), (1e-6).xx)));
    out_.texels = quad.extra;
    float2 _e126 = p0_;
    float2 _e127 = p1_;
    out_.rect = float4(_e126, _e127);
    float _e132 = frame.scale.x;
    float _e136 = frame.scale.y;
    float unit = min(_e132, _e136);
    out_.shape = float2((quad.extra.x * unit), max(1.0, floor(((quad.extra.y * unit) + 0.5))));
    out_.color = quad.color;
    out_.kind = quad.kind;
    Varyings _e155 = out_;
    const Varyings varyings = _e155;
    const VertexOutput_vertex varyings_1 = { varyings.texel, varyings.texels, varyings.rect, varyings.shape, varyings.color, varyings.kind, varyings.position };
    return varyings_1;
}
