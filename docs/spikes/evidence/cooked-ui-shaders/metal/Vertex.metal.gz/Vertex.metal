// language: metal2.4
#include <metal_stdlib>
#include <simd/simd.h>

using metal::uint;

struct _mslBufferSizes {
    uint buffer_size15;
};

struct Frame {
    metal::float4 region;
    metal::float2 scale;
    metal::float2 surface;
    metal::float4 encode;
};
struct Quad {
    metal::float4 rect;
    metal::float4 clip;
    metal::float4 extra;
    metal::float2 pen;
    char _pad4[8];
    metal::float4 color;
    uint kind;
    char _pad6[12];
};
struct Varyings {
    metal::float4 position;
    metal::float2 texel;
    char _pad2[8];
    metal::float4 texels;
    metal::float4 rect;
    metal::float2 shape;
    char _pad5[8];
    metal::float4 color;
    uint kind;
    char _pad7[12];
};
struct type_3 {
    metal::float2 inner[6];
};
metal::float4 unpackFloat32x4_(uint b0, uint b1, uint b2, uint b3, uint b4, uint b5, uint b6, uint b7, uint b8, uint b9, uint b10, uint b11, uint b12, uint b13, uint b14, uint b15) {
    return metal::float4(as_type<float>(b3 << 24 | b2 << 16 | b1 << 8 | b0), as_type<float>(b7 << 24 | b6 << 16 | b5 << 8 | b4), as_type<float>(b11 << 24 | b10 << 16 | b9 << 8 | b8), as_type<float>(b15 << 24 | b14 << 16 | b13 << 8 | b12));
}
metal::float2 unpackFloat32x2_(uint b0, uint b1, uint b2, uint b3, uint b4, uint b5, uint b6, uint b7) {
    return metal::float2(as_type<float>(b3 << 24 | b2 << 16 | b1 << 8 | b0), as_type<float>(b7 << 24 | b6 << 16 | b5 << 8 | b4));
}
metal::float4 unpackUnorm8x4_(metal::uchar b0, metal::uchar b1, metal::uchar b2, metal::uchar b3) {
    return metal::float4(float(b0) / 255.0f, float(b1) / 255.0f, float(b2) / 255.0f, float(b3) / 255.0f);
}
uint unpackUint32_(uint b0, uint b1, uint b2, uint b3) {
    return (b3 << 24 | b2 << 16 | b1 << 8 | b0);
}

metal::float2 snap(
    metal::float2 v
) {
    return metal::floor(v + metal::float2(0.5));
}

metal::float2 physical(
    metal::float2 logical,
    constant Frame& frame
) {
    metal::float4 _e3 = frame.region;
    metal::float2 _e7 = frame.scale;
    return _e3.xy + (logical * _e7);
}

struct vertex_Output {
    metal::float4 position [[position]];
    metal::float2 texel [[user(loc0), center_perspective]];
    metal::float4 texels [[user(loc1), flat]];
    metal::float4 rect [[user(loc2), flat]];
    metal::float2 shape [[user(loc3), flat]];
    metal::float4 color [[user(loc4), flat]];
    uint kind [[user(loc5), flat]];
};
struct vb_15_type { metal::uchar data[64]; };
vertex vertex_Output vertex_(
  uint index [[vertex_id]]
, constant Frame& frame [[buffer(0)]]
, uint i_id [[instance_id]]
, const device vb_15_type* vb_15_in [[buffer(15)]]
, constant _mslBufferSizes& _buffer_sizes [[buffer(1)]]
) {
    metal::float4 rect = {};
    metal::float4 clip = {};
    metal::float4 extra = {};
    metal::float2 pen = {};
    metal::float4 color = {};
    uint kind = {};
    if (i_id < (_buffer_sizes.buffer_size15 / 64)) {
        const vb_15_type vb_15_elem = vb_15_in[i_id];
        rect = unpackFloat32x4_(vb_15_elem.data[0], vb_15_elem.data[1], vb_15_elem.data[2], vb_15_elem.data[3], vb_15_elem.data[4], vb_15_elem.data[5], vb_15_elem.data[6], vb_15_elem.data[7], vb_15_elem.data[8], vb_15_elem.data[9], vb_15_elem.data[10], vb_15_elem.data[11], vb_15_elem.data[12], vb_15_elem.data[13], vb_15_elem.data[14], vb_15_elem.data[15]);
        clip = unpackFloat32x4_(vb_15_elem.data[16], vb_15_elem.data[17], vb_15_elem.data[18], vb_15_elem.data[19], vb_15_elem.data[20], vb_15_elem.data[21], vb_15_elem.data[22], vb_15_elem.data[23], vb_15_elem.data[24], vb_15_elem.data[25], vb_15_elem.data[26], vb_15_elem.data[27], vb_15_elem.data[28], vb_15_elem.data[29], vb_15_elem.data[30], vb_15_elem.data[31]);
        extra = unpackFloat32x4_(vb_15_elem.data[32], vb_15_elem.data[33], vb_15_elem.data[34], vb_15_elem.data[35], vb_15_elem.data[36], vb_15_elem.data[37], vb_15_elem.data[38], vb_15_elem.data[39], vb_15_elem.data[40], vb_15_elem.data[41], vb_15_elem.data[42], vb_15_elem.data[43], vb_15_elem.data[44], vb_15_elem.data[45], vb_15_elem.data[46], vb_15_elem.data[47]);
        pen = unpackFloat32x2_(vb_15_elem.data[48], vb_15_elem.data[49], vb_15_elem.data[50], vb_15_elem.data[51], vb_15_elem.data[52], vb_15_elem.data[53], vb_15_elem.data[54], vb_15_elem.data[55]);
        color = unpackUnorm8x4_(vb_15_elem.data[56], vb_15_elem.data[57], vb_15_elem.data[58], vb_15_elem.data[59]);
        kind = unpackUint32_(vb_15_elem.data[60], vb_15_elem.data[61], vb_15_elem.data[62], vb_15_elem.data[63]);
    }
    const Quad quad_ = { rect, clip, extra, pen, {}, color, kind };
    metal::float2 p0_ = {};
    metal::float2 p1_ = {};
    Varyings out = {};
    type_3 corners = type_3 {{metal::float2(0.0, 0.0), metal::float2(1.0, 0.0), metal::float2(0.0, 1.0), metal::float2(0.0, 1.0), metal::float2(1.0, 0.0), metal::float2(1.0, 1.0)}};
    if (quad_.kind == 2u) {
        metal::float2 _e27 = physical(quad_.pen, frame);
        metal::float2 _e28 = snap(_e27);
        metal::float2 _e33 = frame.scale;
        p0_ = _e28 + (quad_.rect.xy * _e33);
        metal::float2 _e40 = frame.scale;
        p1_ = _e28 + (quad_.rect.zw * _e40);
    } else {
        metal::float2 _e45 = physical(quad_.rect.xy, frame);
        metal::float2 _e46 = snap(_e45);
        p0_ = _e46;
        metal::float2 _e49 = physical(quad_.rect.zw, frame);
        metal::float2 _e50 = snap(_e49);
        p1_ = _e50;
    }
    metal::float2 _e53 = physical(quad_.clip.xy, frame);
    metal::float2 _e54 = snap(_e53);
    metal::float4 _e57 = frame.region;
    metal::float2 _e59 = snap(_e57.xy);
    metal::float2 c0_ = metal::max(_e54, _e59);
    metal::float2 _e63 = physical(quad_.clip.zw, frame);
    metal::float2 _e64 = snap(_e63);
    metal::float4 _e67 = frame.region;
    metal::float4 _e71 = frame.region;
    metal::float2 _e74 = snap(_e67.xy + _e71.zw);
    metal::float2 c1_ = metal::min(_e64, _e74);
    metal::float2 _e76 = p0_;
    metal::float2 low = metal::max(_e76, c0_);
    metal::float2 _e78 = p1_;
    metal::float2 high = metal::max(metal::min(_e78, c1_), low);
    metal::float2 q = metal::mix(low, high, corners.inner[metal::min(unsigned(index), 5u)]);
    float _e89 = frame.surface.x;
    float _e99 = frame.surface.y;
    out.position = metal::float4(((q.x / _e89) * 2.0) - 1.0, 1.0 - ((q.y / _e99) * 2.0), 0.0, 1.0);
    metal::float2 _e113 = p0_;
    metal::float2 _e115 = p1_;
    metal::float2 _e116 = p0_;
    out.texel = metal::mix(quad_.extra.xy, quad_.extra.zw, (q - _e113) / metal::max(_e115 - _e116, metal::float2(0.000001)));
    out.texels = quad_.extra;
    metal::float2 _e126 = p0_;
    metal::float2 _e127 = p1_;
    out.rect = metal::float4(_e126, _e127);
    float _e132 = frame.scale.x;
    float _e136 = frame.scale.y;
    float unit = metal::min(_e132, _e136);
    out.shape = metal::float2(quad_.extra.x * unit, metal::max(1.0, metal::floor((quad_.extra.y * unit) + 0.5)));
    out.color = quad_.color;
    out.kind = quad_.kind;
    Varyings _e155 = out;
    const auto _tmp = _e155;
    return vertex_Output { _tmp.position, _tmp.texel, _tmp.texels, _tmp.rect, _tmp.shape, _tmp.color, _tmp.kind };
}
