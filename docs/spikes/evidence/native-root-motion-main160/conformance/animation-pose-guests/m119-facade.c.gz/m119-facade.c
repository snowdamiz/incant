#include "m119.h"
#include "imports.h"
#include <stdlib.h>
typedef struct { w2c_m119 guest; struct w2c_incant__v1 imports; struct w2c_incant__input__v1 input; struct w2c_incant__flipbook__v1 flipbook; struct w2c_incant__log__v1 log; struct w2c_incant__localization__v1 localization; struct w2c_incant__animation__v1 animation; struct w2c_incant__animation__v2 animationv2; struct w2c_incant__navigation__v1 navigation; struct w2c_incant__animation__v3 animationv3; struct w2c_incant__animation__graph__v1 animationgraph; struct w2c_incant__physics__v1 physics; struct w2c_incant__animation__v4 animationv4; struct w2c_incant__animation__ik__v1 animationik; struct w2c_incant__animation__v5 animation5; struct w2c_incant__animation__ik__v2 animationik2; struct w2c_incant__animation__graph__v2 animationgraph2; struct w2c_incant__root__motion__v1 rootmotion; } Instance;
int32_t incant_m119_create(incant_import callback,void* context,void** output) {
  *output=NULL;
  Instance* p=calloc(1,sizeof(Instance));
  if(!p) return -1;
  p->imports=(struct w2c_incant__v1){callback,context,w2c_m119_memory(&p->guest)};
  p->input.core=p->imports;
  p->flipbook.core=p->imports;
  p->log.core=p->imports;
  p->localization.core=p->imports;
  p->animation.core=p->imports;
  p->animationv2.core=p->imports;
  p->navigation.core=p->imports;
  p->animationv3.core=p->imports;
  p->animationgraph.core=p->imports;
  p->physics.core=p->imports;
  p->animationv4.core=p->imports;
  p->animationik.core=p->imports;
  p->animation5.core=p->imports;
  p->animationik2.core=p->imports;
  p->animationgraph2.core=p->imports;
  p->rootmotion.core=p->imports;
  wasm_rt_init();
  /* setjmp target and every potentially trapping guest frame stay in C. */
  int32_t status=0;
  incant_trap_prepare();
  if(incant_try()==0) {
    wasm2c_m119_instantiate(&p->guest, &p->animationgraph, &p->animationik, &p->animationv2, &p->log, &p->imports);
    if(w2c_m119_incant_abi(&p->guest)!= 1) status=-2;
  } else { status=*w2c_m119_incant_private_fuel(&p->guest)==0 ? -3 : 1; }
  g_wasm_rt_jmp_buf.initialized=false;
  p->imports.callback=NULL; p->imports.context=NULL;
  p->input.core.callback=NULL; p->input.core.context=NULL;
  p->flipbook.core.callback=NULL; p->flipbook.core.context=NULL;
  p->log.core.callback=NULL; p->log.core.context=NULL;
  p->localization.core.callback=NULL; p->localization.core.context=NULL;
  p->animation.core.callback=NULL; p->animation.core.context=NULL;
  p->animationv2.core.callback=NULL; p->animationv2.core.context=NULL;
  p->navigation.core.callback=NULL; p->navigation.core.context=NULL;
  p->animationv3.core.callback=NULL; p->animationv3.core.context=NULL;
  p->animationgraph.core.callback=NULL; p->animationgraph.core.context=NULL;
  p->physics.core.callback=NULL; p->physics.core.context=NULL;
  p->animationv4.core.callback=NULL; p->animationv4.core.context=NULL;
  p->animationik.core.callback=NULL; p->animationik.core.context=NULL;
  p->animation5.core.callback=NULL; p->animation5.core.context=NULL;
  p->animationik2.core.callback=NULL; p->animationik2.core.context=NULL;
  p->animationgraph2.core.callback=NULL; p->animationgraph2.core.context=NULL;
  p->rootmotion.core.callback=NULL; p->rootmotion.core.context=NULL;
  if(status) { wasm2c_m119_free(&p->guest); free(p); return status; }
  *output=p; return 0;
}
int32_t incant_m119_update(void* instance,incant_import callback,void* context,int64_t epoch,double dt) {
  Instance* p=instance;
  p->imports.callback=callback; p->imports.context=context;
  p->input.core.callback=callback; p->input.core.context=context;
  p->flipbook.core.callback=callback; p->flipbook.core.context=context;
  p->log.core.callback=callback; p->log.core.context=context;
  p->localization.core.callback=callback; p->localization.core.context=context;
  p->animation.core.callback=callback; p->animation.core.context=context;
  p->animationv2.core.callback=callback; p->animationv2.core.context=context;
  p->navigation.core.callback=callback; p->navigation.core.context=context;
  p->animationv3.core.callback=callback; p->animationv3.core.context=context;
  p->animationgraph.core.callback=callback; p->animationgraph.core.context=context;
  p->physics.core.callback=callback; p->physics.core.context=context;
  p->animationv4.core.callback=callback; p->animationv4.core.context=context;
  p->animationik.core.callback=callback; p->animationik.core.context=context;
  p->animation5.core.callback=callback; p->animation5.core.context=context;
  p->animationik2.core.callback=callback; p->animationik2.core.context=context;
  p->animationgraph2.core.callback=callback; p->animationgraph2.core.context=context;
  p->rootmotion.core.callback=callback; p->rootmotion.core.context=context;
  *w2c_m119_incant_private_fuel(&p->guest)=10000000;
  int32_t status=0;
  incant_trap_prepare();
  if(incant_try()==0) w2c_m119_update(&p->guest,(uint64_t)epoch,dt);
  else status=*w2c_m119_incant_private_fuel(&p->guest)==0 ? -3 : 1;
  g_wasm_rt_jmp_buf.initialized=false;
  p->imports.callback=NULL; p->imports.context=NULL;
  p->input.core.callback=NULL; p->input.core.context=NULL;
  p->flipbook.core.callback=NULL; p->flipbook.core.context=NULL;
  p->log.core.callback=NULL; p->log.core.context=NULL;
  p->localization.core.callback=NULL; p->localization.core.context=NULL;
  p->animation.core.callback=NULL; p->animation.core.context=NULL;
  p->animationv2.core.callback=NULL; p->animationv2.core.context=NULL;
  p->navigation.core.callback=NULL; p->navigation.core.context=NULL;
  p->animationv3.core.callback=NULL; p->animationv3.core.context=NULL;
  p->animationgraph.core.callback=NULL; p->animationgraph.core.context=NULL;
  p->physics.core.callback=NULL; p->physics.core.context=NULL;
  p->animationv4.core.callback=NULL; p->animationv4.core.context=NULL;
  p->animationik.core.callback=NULL; p->animationik.core.context=NULL;
  p->animation5.core.callback=NULL; p->animation5.core.context=NULL;
  p->animationik2.core.callback=NULL; p->animationik2.core.context=NULL;
  p->animationgraph2.core.callback=NULL; p->animationgraph2.core.context=NULL;
  p->rootmotion.core.callback=NULL; p->rootmotion.core.context=NULL;
  return status;
}
void incant_m119_free(void* instance) { Instance* p=instance; wasm2c_m119_free(&p->guest); free(p); }
