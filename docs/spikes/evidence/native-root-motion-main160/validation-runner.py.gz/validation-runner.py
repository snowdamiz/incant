from pathlib import Path
import os,subprocess,json,time,hashlib,shutil
r=Path('/Users/andreyyurlov/.codex/worktrees/ci-build-cache/incant');o=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/root-motion-main158-001');o.mkdir(exist_ok=False)
target=Path('/Users/andreyyurlov/.codex/incant-compound-integration-target');env=dict(os.environ,CARGO_TARGET_DIR=str(target));env['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/Users/andreyyurlov/.local/share/fnm/node-versions/v22.23.3/installation/bin:/opt/homebrew/opt/llvm/bin:/opt/homebrew/bin:'+env['PATH'];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
assert not git('status','--porcelain');assert json.loads((target/'incant-checkout-owner.json').read_text())['checkout']==str(r)
paths=git('ls-files','crates','editor/app','tools','sdk','schemas','third_party','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo','.gitattributes','.github').splitlines();freeze={p:h(r/p) for p in paths if (r/p).is_file()};head=git('rev-parse','HEAD');(o/'freeze.json').write_text(json.dumps({'head':head,'base':'1276a2a7','producer':'ddaf1ec25e9c60a42bb5977b702d8355ffbe1eec','files':freeze},indent=2)+'\n')
changed=git('diff','--name-only','ed1cc577','ddaf1ec2','--','crates','tools','sdk','schemas','Cargo.toml','Cargo.lock').splitlines();assert all((r/p).read_bytes()==subprocess.check_output(['git','show','ddaf1ec2:'+p],cwd=r) for p in changed);(o/'accepted-sources.json').write_text(json.dumps({p:h(r/p) for p in changed},indent=2)+'\n')
common=['--locked','--profile','ci','-j2'];cmds=[
('native-tests',['./tools/cargo','test']+common+sum((['-p',p] for p in ['incant_anim','incant_runtime','incant_script','incant_physics_runtime','incant_render_native','incant_cook','incant_assets']),[])+['--all-targets']),
('clippy',['./tools/cargo','clippy']+common+sum((['-p',p] for p in ['incant_anim','incant_runtime','incant_script','incant_physics_runtime','incant_assets_runtime','incant_cook','incant_render_native','incant_render','incant_render_authoring']),[])+['--all-targets','--','-D','warnings']),
('conformance',['python3','tools/probes/shipping-wasm2c.py',str(o/'conformance'),'--rustup','/opt/homebrew/bin/rustup','--profile','ci','--conformance-only']),
('wasm',['./tools/cargo','check']+common+['-p','incant_anim','-p','incant_runtime','--target','wasm32-unknown-unknown']),
('guest-sdk',['./tools/cargo','check','--manifest-path','sdk/rust/Cargo.toml','--locked','--target','wasm32-unknown-unknown']),
('graph',['python3','tools/check_runtime_dependencies.py','incant_anim','incant_runtime','incant_script','incant_render_native']),
('typescript',['node','node_modules/typescript/bin/tsc','--noEmit','-p','sdk/ts/tsconfig.json']),
('generated',['python3','tools/generate_wasm_sdk.py','--check']),
('tools',['python3','-m','unittest','discover','-s','tools/tests','-p','test_wasm*.py']),
('headless',['./tools/cargo','build']+common+['-p','incant_headless','--features','wasmtime-host']),
('oracle',['./tools/cargo','build']+common+['-p','incant_cook','--example','root_motion_package_oracle']),
('fmt',['./tools/cargo','fmt','--all','--','--check']),('conventions',['python3','tools/generate_conventions.py','--check']),('diff',['git','diff','--check']),
('public-export',['python3','tools/probes/native-wasm-root-motion-export.py',str(o/'public-export'),'--binary',str(o/'incant_headless'),'--oracle',str(o/'root_motion_package_oracle')])]
results=[]
for name,cmd in cmds:
 assert all(h(r/p)==v for p,v in freeze.items());print('starting',name,flush=True);start=time.monotonic()
 with (o/(name+'.log')).open('w') as log:rc=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 results.append({'name':name,'command':cmd,'exit':rc,'seconds':time.monotonic()-start,'sha256':h(o/(name+'.log'))});(o/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(name,rc,flush=True)
 if rc:raise SystemExit(rc)
 if name in ['headless','oracle']:
  binary='incant_headless' if name=='headless' else 'root_motion_package_oracle';src=target/'ci'/binary if name=='headless' else target/'ci/examples'/binary;dst=o/binary;shutil.copy2(src,dst);(o/(name+'-binary.json')).write_text(json.dumps({'source_head':head,'profile':'ci','features':['wasmtime-host'] if name=='headless' else [],'sha256':h(dst),'bytes':dst.stat().st_size},indent=2)+'\n')
 assert all(h(r/p)==v for p,v in freeze.items())
