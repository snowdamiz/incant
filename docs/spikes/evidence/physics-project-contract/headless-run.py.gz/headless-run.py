from pathlib import Path
import json,sys,os,shutil,time,hashlib
root=Path('/Users/andreyyurlov/.codex/worktrees/native-audio-host/incant');out=Path(__file__).parent;sys.path.insert(0,str(root/'tools'))
from native_process import run
from physics_features import validate_artifacts,compiler_messages
from play_native import executable
from native_package import write_json,sha256
freeze=json.loads(Path('/Users/andreyyurlov/.codex/incant-evidence/physics-project-main171-001/freeze.json').read_text());write_json(out/'freeze.json',freeze)
assert all(sha256((root/p).read_bytes())==h for p,h in freeze.items())
td=Path('/Users/andreyyurlov/.codex/incant-physics-variant-target');target='aarch64-apple-darwin';argv=[str(root/'tools/cargo'),'build','--locked','--profile','ci','-j2','-p','incant_headless','--bin','incant_headless','--no-default-features','--features','physics-deterministic','--target',target,'--target-dir',str(td),'--message-format=json']
env={k:v for k,v in os.environ.items() if not k.startswith(('INCANT_NATIVE_','INCANT_MOBILE_','INCANT_WASM_','INCANT_AUTHORED_'))};start=time.monotonic()
with (out/'cargo.jsonl').open('w') as stdout,(out/'cargo.stderr').open('w') as stderr:r=run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=3600)
receipt={'argv':argv,'exit_code':r.returncode,'seconds':time.monotonic()-start,'changed':[p for p,h in freeze.items() if sha256((root/p).read_bytes())!=h]}
write_json(out/'result.json',receipt);assert r.returncode==0 and not receipt['changed']
messages=compiler_messages(out/'cargo.jsonl');receipt['physics']=validate_artifacts(messages,'deterministic',target_dir=td,target=target,profile='ci');binary=executable(messages,td,target);shutil.copy2(binary,out/'incant_headless');receipt['binary_sha256']=sha256((out/'incant_headless').read_bytes());write_json(out/'result.json',receipt);print(json.dumps({'passed':True,'binary':str(out/'incant_headless')}))
