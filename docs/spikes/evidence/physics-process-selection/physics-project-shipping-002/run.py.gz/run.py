from pathlib import Path
import sys,json,hashlib,time
root=Path('/Users/andreyyurlov/.codex/worktrees/native-audio-host/incant');out=Path(__file__).parent;sys.path.insert(0,str(root/'tools'));from native_process import run
argv=[sys.executable,'tools/probes/physics-mode-export.py','/Users/andreyyurlov/.codex/incant-evidence/physics-project-play-002',str(out/'exports'),'--binary','/Users/andreyyurlov/.codex/incant-evidence/physics-project-headless-001/incant_headless'];start=time.monotonic()
with (out/'stdout').open('w') as stdout,(out/'stderr').open('w') as stderr:r=run(argv,cwd=root,stdout=stdout,stderr=stderr,timeout=7200)
freeze=json.loads((out/'freeze.json').read_text());changed=[p for p,h in freeze.items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];result={'argv':argv,'exit_code':r.returncode,'seconds':time.monotonic()-start,'frozen_inputs':len(freeze),'changed':changed};(out/'terminal.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));sys.exit(r.returncode or bool(changed))
