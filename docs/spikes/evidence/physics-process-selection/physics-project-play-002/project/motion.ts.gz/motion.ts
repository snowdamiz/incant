import type { NativeBehavior } from "@incant/runtime/native";
export default { update({ chunks, dt }) {
  for (const chunk of chunks) for (let i = 0; i < chunk.ids.length; i++)
    chunk.transforms[i * chunk.transformStride] += 6 * dt;
}} satisfies NativeBehavior;
