struct NagaConstants {
    int first_vertex;
    int first_instance;
    uint other;
};
ConstantBuffer<NagaConstants> _NagaConstants: register(b2);

struct Frame {
    row_major float4x4 matrix_;
    float4 color;
};

struct Glyph {
    float4 rect : LOC0;
    float4 texels : LOC1;
};

struct Varyings {
    float4 position : SV_Position;
    float2 texel : LOC0;
    nointerpolation float4 texels : LOC1;
};

cbuffer frame : register(b0) { Frame frame; }
cbuffer node : register(b1) { row_major float4x4 node; }

struct VertexOutput_vertex {
    float2 texel : LOC0;
    nointerpolation float4 texels : LOC1;
    float4 position : SV_Position;
};

typedef float2 ret_Constructarray6_float2_[6];
ret_Constructarray6_float2_ Constructarray6_float2_(float2 arg0, float2 arg1, float2 arg2, float2 arg3, float2 arg4, float2 arg5) {
    float2 ret[6] = { arg0, arg1, arg2, arg3, arg4, arg5 };
    return ret;
}

VertexOutput_vertex vertex(uint index : SV_VertexID, Glyph glyph)
{
    Varyings out_ = (Varyings)0;

    float2 corners[6] = Constructarray6_float2_(float2(0.0, 0.0), float2(1.0, 0.0), float2(0.0, 1.0), float2(0.0, 1.0), float2(1.0, 0.0), float2(1.0, 1.0));
    float2 corner = corners[min(uint((_NagaConstants.first_vertex + index)), 5u)];
    float4x4 _e26 = frame.matrix_;
    float4x4 _e28 = node;
    out_.position = mul(float4(lerp(glyph.rect.xy, glyph.rect.zw, corner), 0.0, 1.0), mul(_e28, _e26));
    out_.texel = lerp(glyph.texels.xy, glyph.texels.zw, corner);
    out_.texels = glyph.texels;
    Varyings _e47 = out_;
    const Varyings varyings = _e47;
    const VertexOutput_vertex varyings_1 = { varyings.texel, varyings.texels, varyings.position };
    return varyings_1;
}
