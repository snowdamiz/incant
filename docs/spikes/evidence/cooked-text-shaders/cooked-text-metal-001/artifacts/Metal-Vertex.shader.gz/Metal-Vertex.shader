// language: metal2.4
#include <metal_stdlib>
#include <simd/simd.h>

using metal::uint;

struct _mslBufferSizes {
    uint buffer_size15;
};

struct Frame {
    metal::float4x4 matrix_;
    metal::float4 color;
};
struct Glyph {
    metal::float4 rect;
    metal::float4 texels;
};
struct Varyings {
    metal::float4 position;
    metal::float2 texel;
    char _pad2[8];
    metal::float4 texels;
};
struct type_4 {
    metal::float2 inner[6];
};
metal::float4 unpackFloat32x4_(uint b0, uint b1, uint b2, uint b3, uint b4, uint b5, uint b6, uint b7, uint b8, uint b9, uint b10, uint b11, uint b12, uint b13, uint b14, uint b15) {
    return metal::float4(as_type<float>(b3 << 24 | b2 << 16 | b1 << 8 | b0), as_type<float>(b7 << 24 | b6 << 16 | b5 << 8 | b4), as_type<float>(b11 << 24 | b10 << 16 | b9 << 8 | b8), as_type<float>(b15 << 24 | b14 << 16 | b13 << 8 | b12));
}

struct vertex_Output {
    metal::float4 position [[position]];
    metal::float2 texel [[user(loc0), center_perspective]];
    metal::float4 texels [[user(loc1), flat]];
};
struct vb_15_type { metal::uchar data[32]; };
vertex vertex_Output vertex_(
  uint index [[vertex_id]]
, constant Frame& frame [[buffer(0)]]
, constant metal::float4x4& node [[buffer(1)]]
, uint i_id [[instance_id]]
, const device vb_15_type* vb_15_in [[buffer(15)]]
, constant _mslBufferSizes& _buffer_sizes [[buffer(2)]]
) {
    metal::float4 rect = {};
    metal::float4 texels = {};
    if (i_id < (_buffer_sizes.buffer_size15 / 32)) {
        const vb_15_type vb_15_elem = vb_15_in[i_id];
        rect = unpackFloat32x4_(vb_15_elem.data[0], vb_15_elem.data[1], vb_15_elem.data[2], vb_15_elem.data[3], vb_15_elem.data[4], vb_15_elem.data[5], vb_15_elem.data[6], vb_15_elem.data[7], vb_15_elem.data[8], vb_15_elem.data[9], vb_15_elem.data[10], vb_15_elem.data[11], vb_15_elem.data[12], vb_15_elem.data[13], vb_15_elem.data[14], vb_15_elem.data[15]);
        texels = unpackFloat32x4_(vb_15_elem.data[16], vb_15_elem.data[17], vb_15_elem.data[18], vb_15_elem.data[19], vb_15_elem.data[20], vb_15_elem.data[21], vb_15_elem.data[22], vb_15_elem.data[23], vb_15_elem.data[24], vb_15_elem.data[25], vb_15_elem.data[26], vb_15_elem.data[27], vb_15_elem.data[28], vb_15_elem.data[29], vb_15_elem.data[30], vb_15_elem.data[31]);
    }
    const Glyph glyph = { rect, texels };
    Varyings out = {};
    type_4 corners = type_4 {{metal::float2(0.0, 0.0), metal::float2(1.0, 0.0), metal::float2(0.0, 1.0), metal::float2(0.0, 1.0), metal::float2(1.0, 0.0), metal::float2(1.0, 1.0)}};
    metal::float2 corner = corners.inner[metal::min(unsigned(index), 5u)];
    metal::float4x4 _e26 = frame.matrix_;
    metal::float4x4 _e28 = node;
    out.position = (_e26 * _e28) * metal::float4(metal::mix(glyph.rect.xy, glyph.rect.zw, corner), 0.0, 1.0);
    out.texel = metal::mix(glyph.texels.xy, glyph.texels.zw, corner);
    out.texels = glyph.texels;
    Varyings _e47 = out;
    const auto _tmp = _e47;
    return vertex_Output { _tmp.position, _tmp.texel, _tmp.texels };
}
