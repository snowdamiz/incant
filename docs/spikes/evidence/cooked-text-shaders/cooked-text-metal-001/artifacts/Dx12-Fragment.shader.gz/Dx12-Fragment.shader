struct NagaConstants {
    int first_vertex;
    int first_instance;
    uint other;
};
ConstantBuffer<NagaConstants> _NagaConstants: register(b2);

struct Frame {
    row_major float4x4 matrix_;
    float4 color;
};

struct Varyings {
    float4 position : SV_Position;
    float2 texel : LOC0;
    nointerpolation float4 texels : LOC1;
};

cbuffer frame : register(b0) { Frame frame; }
Texture2D<float4> atlas : register(t0);
SamplerState nagaSamplerHeap[2048]: register(s0, space0);
SamplerComparisonState nagaComparisonSamplerHeap[2048]: register(s2048, space0);
StructuredBuffer<uint> nagaGroup2SamplerIndexArray : register(t1, space0);
static const SamplerState bilinear = nagaSamplerHeap[nagaGroup2SamplerIndexArray[0]];

struct FragmentInput_fragment {
    float2 texel : LOC0;
    nointerpolation float4 texels : LOC1;
    float4 position : SV_Position;
};

uint naga_f2u32(float value) {
    return uint(clamp(value, 0.0, 4294967000.0));
}

uint2 NagaDimensions2D(Texture2D<float4> tex)
{
    uint4 ret;
    tex.GetDimensions(0, ret.x, ret.y, ret.z);
    return ret.xy;
}

float4 fragment(FragmentInput_fragment fragmentinput_fragment) : SV_Target0
{
    Varyings input = { fragmentinput_fragment.position, fragmentinput_fragment.texel, fragmentinput_fragment.texels };
    float sum = 0.0;
    uint j = 0u;
    uint i = (uint)0;

    float2 dx = ddx(input.texel);
    float2 dy = ddy(input.texel);
    uint taps = naga_f2u32(clamp(ceil((max(length(dx), length(dy)) - 0.25)), 1.0, 4.0));
    float2 size = float2(NagaDimensions2D(atlas));
    float2 low = (input.texels.xy + (0.5).xx);
    float2 high = (input.texels.zw - (0.5).xx);
    uint2 loop_bound = uint2(4294967295u, 4294967295u);
    bool loop_init = true;
    while(true) {
        if (all(loop_bound == uint2(0u, 0u))) { break; }
        loop_bound -= uint2(loop_bound.y == 0u, 1u);
        if (!loop_init) {
            uint _e72 = j;
            j = (_e72 + 1u);
        }
        loop_init = false;
        uint _e32 = j;
        if ((_e32 < taps)) {
        } else {
            break;
        }
        {
            i = 0u;
            uint2 loop_bound_1 = uint2(4294967295u, 4294967295u);
            bool loop_init_1 = true;
            while(true) {
                if (all(loop_bound_1 == uint2(0u, 0u))) { break; }
                loop_bound_1 -= uint2(loop_bound_1.y == 0u, 1u);
                if (!loop_init_1) {
                    uint _e69 = i;
                    i = (_e69 + 1u);
                }
                loop_init_1 = false;
                uint _e36 = i;
                if ((_e36 < taps)) {
                } else {
                    break;
                }
                {
                    uint _e38 = i;
                    uint _e40 = j;
                    float2 offset = (((float2(float(_e38), float(_e40)) + (0.5).xx) / (float(taps)).xx) - (0.5).xx);
                    float2 at = clamp(((input.texel + (dx * offset.x)) + (dy * offset.y)), low, high);
                    float _e60 = sum;
                    float4 _e65 = atlas.SampleLevel(bilinear, (at / size), 0.0);
                    sum = (_e60 + _e65.x);
                }
            }
        }
    }
    float _e74 = sum;
    float coverage = (_e74 / float((taps * taps)));
    float4 _e80 = frame.color;
    return float4((_e80.xyz * coverage), coverage);
}
