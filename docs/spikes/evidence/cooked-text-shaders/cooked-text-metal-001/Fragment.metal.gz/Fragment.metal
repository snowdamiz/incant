// language: metal2.4
#include <metal_stdlib>
#include <simd/simd.h>

using metal::uint;

struct Frame {
    metal::float4x4 matrix_;
    metal::float4 color;
};
struct Varyings {
    metal::float4 position;
    metal::float2 texel;
    char _pad2[8];
    metal::float4 texels;
};
uint naga_f2u32(float value) {
    return static_cast<uint>(metal::clamp(value, 0.0, 4294967000.0));
}


struct fragment_Input {
    metal::float2 texel [[user(loc0), center_perspective]];
    metal::float4 texels [[user(loc1), flat]];
};
struct fragment_Output {
    metal::float4 member [[color(0)]];
};
fragment fragment_Output fragment_(
  fragment_Input varyings [[stage_in]]
, metal::float4 position [[position]]
, constant Frame& frame [[buffer(0)]]
, metal::texture2d<float, metal::access::sample> atlas [[texture(0)]]
, metal::sampler bilinear [[sampler(0)]]
) {
    const Varyings input = { position, varyings.texel, {}, varyings.texels };
    float sum = 0.0;
    uint j = 0u;
    uint i = {};
    metal::float2 dx = metal::dfdx(input.texel);
    metal::float2 dy = metal::dfdy(input.texel);
    uint taps = naga_f2u32(metal::clamp(metal::ceil(metal::max(metal::length(dx), metal::length(dy)) - 0.25), 1.0, 4.0));
    metal::float2 size = static_cast<metal::float2>(metal::uint2(atlas.get_width(), atlas.get_height()));
    metal::float2 low = input.texels.xy + metal::float2(0.5);
    metal::float2 high = input.texels.zw - metal::float2(0.5);
    uint2 loop_bound = uint2(4294967295u);
    bool loop_init = true;
    while(true) {
        if (metal::all(loop_bound == uint2(0u))) { break; }
        loop_bound -= uint2(loop_bound.y == 0u, 1u);
        if (!loop_init) {
            uint _e72 = j;
            j = _e72 + 1u;
        }
        loop_init = false;
        uint _e32 = j;
        if (_e32 < taps) {
        } else {
            break;
        }
        {
            i = 0u;
            uint2 loop_bound_1 = uint2(4294967295u);
            bool loop_init_1 = true;
            while(true) {
                if (metal::all(loop_bound_1 == uint2(0u))) { break; }
                loop_bound_1 -= uint2(loop_bound_1.y == 0u, 1u);
                if (!loop_init_1) {
                    uint _e69 = i;
                    i = _e69 + 1u;
                }
                loop_init_1 = false;
                uint _e36 = i;
                if (_e36 < taps) {
                } else {
                    break;
                }
                {
                    uint _e38 = i;
                    uint _e40 = j;
                    metal::float2 offset = ((metal::float2(static_cast<float>(_e38), static_cast<float>(_e40)) + metal::float2(0.5)) / metal::float2(static_cast<float>(taps))) - metal::float2(0.5);
                    metal::float2 at = metal::clamp((input.texel + (dx * offset.x)) + (dy * offset.y), low, high);
                    float _e60 = sum;
                    metal::float4 _e65 = atlas.sample(bilinear, at / size, metal::level(0.0));
                    sum = _e60 + _e65.x;
                }
            }
        }
    }
    float _e74 = sum;
    float coverage = _e74 / static_cast<float>(taps * taps);
    metal::float4 _e80 = frame.color;
    return fragment_Output { metal::float4(_e80.xyz * coverage, coverage) };
}
