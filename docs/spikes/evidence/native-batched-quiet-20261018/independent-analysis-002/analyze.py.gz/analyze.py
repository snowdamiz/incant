"""Bounded saved-data analysis; does not run an engine or rewrite original receipts."""
import collections
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ARMS = ("ordinary", "display-link60", "latest-display-link60")


def read(path):
    raw = path.read_bytes()
    if len(raw) > 8 * 1024 * 1024:
        raise ValueError("input exceeds 8 MiB")
    return json.loads(raw), {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def stats(values):
    values = sorted(x for x in values if x is not None)
    if not values:
        return {"count": 0}
    if not all(math.isfinite(x) for x in values):
        raise ValueError("nonfinite metric")
    result = {"count": len(values), "min": values[0], "max": values[-1],
              "sum": sum(values), "mean": sum(values) / len(values)}
    for label, q in (("p50", .5), ("p95", .95), ("p99", .99)):
        result[label] = values[math.ceil(q * len(values)) - 1]
    return result


def ms(a, b):
    if a is None or b is None:
        return None
    if b < a:
        raise ValueError("Rust Instant clock regressed")
    return (b - a) / 1e6


def arm(name):
    folder = ROOT / ("window-" + name + "-002")
    data, raw_identity = read(folder / "presentations.json")
    original, original_identity = read(folder / "result.json")
    report, report_identity = read(folder / "stdout.json")
    assert data["version"] == (3 if name.startswith("latest") else 2)
    assert data["requested_host_steps"] == report["host_steps"] == 2156
    assert len(data["rows"]) <= 4096 and len(data["host"]["attempts"]) <= 4096
    attempts = {a["id"]: a for a in data["host"]["attempts"]}
    segments = {s["id"]: s for s in data["host"]["segments"]}
    assert len(attempts) == len(data["host"]["attempts"])
    role_bit = 1 << data["boundary_bit_order"].index("role")
    gaps, breaks, grouped = [], [], collections.defaultdict(list)
    for index, (a, b) in enumerate(zip(data["rows"], data["rows"][1:])):
        aa, bb = attempts[a["attempt"]], attempts[b["attempt"]]
        sa, sb = segments[a["segment"]], segments[b["segment"]]
        same_owner = (a["surface_generation"], aa["session_generation"]) == (b["surface_generation"], bb["session_generation"])
        role_only = sb["id"] == sa["id"] + 1 and sb["boundary_bits"] == role_bit
        reason = None
        if not same_owner or not (sa["id"] == sb["id"] or role_only):
            reason = "owner_or_lifecycle_boundary"
        elif bb["id"] != aa["id"] + 1:
            reason = "intervening_attempt_without_drawable"
        elif any(x["status"] not in ("host_committed", "refresh_completed") for x in (aa, bb)):
            reason = "partial_attempt_status"
        elif a["outcome"] != "presented" or b["outcome"] != "presented":
            reason = "nonpositive_or_missing_outcome"
        if reason:
            breaks.append({"before_row": index, "after_row": index + 1, "reason": reason,
                           "before_outcome": a["outcome"], "after_outcome": b["outcome"]})
            continue
        gap = (b["presented_seconds"] - a["presented_seconds"]) * 1000
        if not math.isfinite(gap) or gap <= 0:
            breaks.append({"before_row": index, "after_row": index + 1, "reason": "equal_backward_or_nonfinite", "gap_ms": gap})
            continue
        t, u = aa["host_timing"], bb["host_timing"]
        s, w = u["schedule"], u["wake"]
        row = {"before_row": index, "after_row": index + 1, "before_attempt": aa["id"], "after_attempt": bb["id"],
               "before_role": aa["role"], "after_role": bb["role"], "role_only_boundary": role_only,
               "display_gap_ms": gap, "accepted_ticks": bb.get("batch", {}).get("accepted_ticks"),
               "begin_gap_ms": ms(t["began_ns"], u["began_ns"]),
               "completion_gap_ms": ms(t["completed_ns"], u["completed_ns"]),
               "prior_completion_to_begin_ms": ms(t["completed_ns"], u["began_ns"]),
               "reserve_ms": ms(u["began_ns"], u["reserved_ns"]),
               "body_ms": ms(u["reserved_ns"], u["completed_ns"]),
               "prior_body_ms": ms(t["reserved_ns"], t["completed_ns"]),
               "schedule_lateness_ms": ms(s["deadline_ns"], s["pulse_ns"]) if s else None,
               "pre_attempt_ms": ms(w["pulse_ns"], u["began_ns"]) if w else None,
               "acquire_ms": sum(ms(x["began_ns"], x["ended_ns"]) for x in u["acquisitions"] if x),
               "finished_total_ms": ms(u["began_ns"], u["finished_ns"])}
        gaps.append(row)
        grouped[(aa["role"], bb["role"], gap > 20)].append(row)
    issues = original.get("analysis", {}).get("partial_reasons", [])
    summaries = []
    for (before, after, long), rows in grouped.items():
        summaries.append({"before_role": before, "after_role": after, "display_gap_over_20ms": long,
                          "count": len(rows), "accepted_ticks": dict(collections.Counter(str(r["accepted_ticks"]) for r in rows)),
                          "metrics_ms": {k: stats(r[k] for r in rows) for k in rows[0] if k.endswith("_ms")}})
    return {"inputs": [raw_identity, original_identity, report_identity], "original_status": original["status"],
            "original_receipt_unchanged": True, "capture_coverage": data["coverage"],
            "finalization": data["finalization"], "host_timing_errors": data["host"]["timing_errors"],
            "reported_issues": dict(collections.Counter(x["reason"] for x in issues)),
            "missing_wakes_by_role": dict(collections.Counter(a["role"] for a in attempts.values() if a["host_timing"]["wake"] is None)),
            "recorded_wake_sequences": {"rows": sum(a["host_timing"]["wake"] is not None for a in attempts.values()),
                                        "unique": len({a["host_timing"]["wake"]["sequence"] for a in attempts.values() if a["host_timing"]["wake"]})},
            "display_gap_ms": stats(r["display_gap_ms"] for r in gaps),
            "gaps_over_20ms": sum(r["display_gap_ms"] > 20 for r in gaps),
            "gaps_over_30ms": sum(r["display_gap_ms"] > 30 for r in gaps),
            "role_only_boundaries_included": sum(r["role_only_boundary"] for r in gaps),
            "decomposition": summaries, "breaks": breaks, "intervals": gaps,
            "native_wake_summary": report.get("native_wake"), "batch_summary": report.get("native_batch")}


if __name__ == "__main__":
    result = {"schema": 1, "kind": "independent-saved-data-display-intervals", "source": "6f69ab299d33a864e5fb7e91c3e60f8cef87f819",
              "performance_acceptance": False, "display_acceptance": False,
              "quantiles": "nearest rank ceil(q*n), all retained positive adjacent intervals",
              "clock_rule": "Metal-to-Metal intervals and Rust-Instant-to-Rust-Instant spans only; no cross-epoch subtraction",
              "bounds": "3 arms; each input <=8MiB; each arm <=4096 attempts/rows",
              "limitations": ["One fixed sequential comparison; no run retry or exclusion.",
                              "Zero/missing/equal/partial rows and lifecycle boundaries break adjacency, and are explicitly retained.",
                              "Role-only boundaries retain adjacency; no gameplay-only tail filtering.",
                              "Host body contains simulation, audio and renderer work; it does not isolate GPU execution or renderer CPU cost.",
                              "Idle attempts lack wake metadata; their wake-to-attempt delay cannot be recovered.",
                              "Original latest-arm failed receipt remains failed."],
              "arms": {name: arm(name) for name in ARMS}}
    print(json.dumps(result, indent=2))
