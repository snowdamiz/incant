"""One recorded interrupted-export recovery; never a repository/production API."""
from pathlib import Path
import argparse, ast, difflib, hashlib, json, os, re, shutil, subprocess, sys, tarfile, textwrap

ROOT=Path('/Users/andreyyurlov/.codex/worktrees/native-fbx-import/incant')
RUN=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/compound-wasm-main156-001')
OUT=RUN/'public-export'
HERE=Path(__file__).resolve().parent
STORAGE=OUT/'private-builds/incant-project-build-lx89mipx'
OLD_STAGE=OUT/'private-builds/incant-native-export-wlek12rf'
PROBE=ROOT/'tools/probes/native-wasm-compound-export.py'
EXPORT=ROOT/'tools/export_native.py'
SHA=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def require(v,s):
    if not v:raise RuntimeError(s)
def identity(p):return {'path':str(p),'sha256':SHA(p),'bytes':p.stat().st_size}
def source_check():
    f=load(RUN/'freeze.json')
    require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==f['head'],'Changed source commit')
    require(not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True),'Dirty source')
    require(all(SHA(ROOT/p)==v for p,v in f['files'].items()),'Changed frozen input')
    return f

def fragments():
    original=EXPORT.read_text();tree=ast.parse(original)
    build=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='build')
    start=next(n for n in build.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='flags')
    tail=''.join(original.splitlines(keepends=True)[start.lineno-1:build.end_lineno])
    # Every original post-build audit/packaging statement, byte-for-byte.
    function='def recovered_tail(project, staging, storage, scene, camera, mode, compiler, host, kind, split, llvm_bin, project_hash, module, graph, link_map, log):\n'+tail
    compile(function,str(EXPORT)+'#unchanged-post-build-tail','exec')
    probe=PROBE.read_text()
    old="trusted=out/'trusted-tools';trusted.mkdir();scratch=out/'private-builds';scratch.mkdir();tempfile.tempdir=str(scratch)"
    new="trusted=out/'trusted-tools';scratch=out/'private-builds';recovery_directories(trusted,scratch);tempfile.tempdir=str(scratch)"
    old2="provision=runpy.run_path(str(ROOT/'tools/probes/shipping-wasm2c.py'))['provision'];wabt,provenance=provision(trusted);write_json(out/'wabt.json',provenance)"
    new2="wabt,provenance=recovery_provision(trusted);write_json(out/'wabt.json',provenance)"
    require(probe.count(old)==1 and probe.count(old2)==1,'Unexpected probe text')
    modified=probe.replace(old,new).replace(old2,new2)
    return function,modified,''.join(difflib.unified_diff(probe.splitlines(True),modified.splitlines(True),fromfile='original frozen probe',tofile='external recovery execution only'))

def verify_original():
    frozen=source_check()
    ps=subprocess.check_output(['ps','-axo','pid=,command='],text=True)
    require(not any(str(STORAGE) in l for l in ps.splitlines()),'Original build still active')
    require(not (OUT/'package').exists(),'Package already exists')
    require(set((OUT/'private-builds').iterdir())=={STORAGE,OLD_STAGE},'Unexpected private storage')
    commands=load(OUT/'commands.json')
    require(len(commands)==24 and all(d['exit_code']==0 for d in commands[18:]),'Original command log changed')
    paths={RUN/'freeze.json',RUN/'headless-binary.json',RUN/'oracle-binary.json',OUT/'preflight.json',OUT/'commands.json',OUT/'wabt.json',OUT/'removed.json',OUT/'oracle.scene',OUT/'oracle.json',OUT/'development.json',OUT/'development.pcm',OUT/'observe.json',OUT/'positive-input.json',OUT/'authoring/project.json',OUT/'authoring/project.journal.jsonl',STORAGE/'cargo.jsonl',OLD_STAGE/'build.log'}
    for d in commands:
        for s in ('stdout','stderr'):
            if s in d:
                p=OUT/d[s]['file'];require(SHA(p)==d[s]['sha256'],'Changed original command stream');paths.add(p)
    pre=load(OUT/'preflight.json')
    require(pre['passed'] and all(SHA(ROOT/p)==v for p,v in pre['sources'].items()),'Preflight source mismatch')
    for n,key in [('incant_headless','headless_sha256'),('animation_compound_package_oracle','oracle_binary_sha256')]:
        require(SHA(RUN/n)==pre[key],'Preflight executable changed');paths.add(RUN/n)
    require(SHA(OUT/'oracle.scene')==pre['oracle_scene_sha256'],'Oracle scene mismatch')
    require(SHA(OUT/'authoring/project.json')==pre['project_sha256'],'Project mismatch')
    messages=[json.loads(l) for l in (STORAGE/'cargo.jsonl').read_text().splitlines() if l.startswith('{')]
    require(messages[-1]=={'reason':'build-finished','success':True},'Original Cargo did not report success')
    require([m for m in messages if m.get('reason')=='build-finished']==[messages[-1]],'Ambiguous Cargo completion')
    a=[m for m in messages if m.get('reason')=='compiler-artifact' and m['target']['name']=='incant_game_player' and m.get('executable')]
    require(len(a)==1 and not a[0]['fresh'],'Missing unique fresh player')
    require(set(a[0]['features'])=={'default','project','render-input','static-module'},'Unexpected feature closure')
    exe=Path(a[0]['executable']);require(exe.is_relative_to(STORAGE),'Player outside private build')
    paths.add(exe);paths.update(p for p in exe.with_suffix('.dSYM').rglob('*') if p.is_file())
    producers=[Path(m['out_dir']) for m in messages if m.get('reason')=='build-script-executed' and m['package_id']==a[0]['package_id'] and (Path(m['out_dir'])/'project-export.json').is_file()]
    require(len(producers)==1,'Ambiguous cook output')
    producer=producers[0];paths.update(p for p in producer.rglob('*') if p.is_file())
    paths.update(p for p in (OUT/'authoring').rglob('*') if p.is_file())
    paths.update(p for p in (OUT/'trusted-tools').rglob('*') if p.is_file())
    paths.update(p for d in ['captured','wasm-bundle'] for p in (STORAGE/d).rglob('*') if p.is_file())
    module=load(OUT/'command-022-stdout.txt');receipt=load(producer/'project-export.json')
    require(all(receipt['program'][k]==v for k,v in module.items()),'Cook/capture identity mismatch')
    require(receipt['project_sha256']==pre['project_sha256'],'Cook project identity mismatch')
    bundle=load(STORAGE/'wasm-bundle/manifest.json')
    require(bundle['wabt']=='1.0.42' and len(bundle['modules'])==1,'Unexpected translated bundle')
    require(all(SHA(STORAGE/'wasm-bundle'/p)==v for p,v in bundle['files'].items()),'Translated bundle bytes mismatch')
    for filename,key in [('original.wasm','input_sha256'),('prepared.wasm','prepared_sha256')]:
        require(SHA(STORAGE/'captured'/filename)==module[key],'Captured Wasm mismatch')
    require(bundle['modules'][0]['input_sha256']==module['input_sha256'] and bundle['modules'][0]['prepared_sha256']==module['prepared_sha256'],'Bundle input mismatch')
    compiler=(OUT/'command-019-stdout.txt').read_text();rustc=Path(commands[19]['argv'][0]);paths.add(rustc)
    require(subprocess.check_output([rustc,'-vV'],text=True)==compiler,'Compiler identity changed')
    host=re.search(r'^host: (.+)$',compiler,re.M).group(1)
    require(host=='aarch64-apple-darwin' and receipt['target']==host,'Unexpected target')
    require(subprocess.check_output([rustc,'--print','sysroot'],text=True)==(OUT/'command-020-stdout.txt').read_text(),'Sysroot changed')
    llvm=Path((OUT/'command-020-stdout.txt').read_text().strip())/'lib/rustlib'/host/'bin'
    paths.update(llvm/n for n in ['llvm-nm','llvm-objcopy','llvm-dwarfdump'] if (llvm/n).is_file())
    paths.add(Path(commands[22]['argv'][0]))
    provenance=load(OUT/'wabt.json');archive=OUT/'trusted-tools/wabt.tar.gz'
    require(provenance['release']=='1.0.42' and SHA(archive)==provenance['archive_sha256']=='3f654779b436c628db3ca4323c51538815f5fbc887a6d5f3bb1c18d36281e240','Pinned translator archive mismatch')
    with tarfile.open(archive) as tar:
        for n in ['wasm2c','wat2wasm']:
            entries=[m for m in tar.getmembers() if m.isfile() and m.name.endswith('/bin/'+n)]
            require(len(entries)==1,'Ambiguous translator archive')
            require(hashlib.sha256(tar.extractfile(entries[0]).read()).hexdigest()==SHA(OUT/'trusted-tools/wabt/bin'/n),'Translator binary mismatch')
    for n in ('RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER'):
        require(not os.environ.get(n),'Ambient compiler override')
    require(not any(v for n,v in os.environ.items() if n.startswith('CARGO_PROFILE_') or n.endswith('_RUSTFLAGS')),'Ambient profile override')
    return {'head':frozen['head'],'frozen_input_count':len(frozen['files']),'cargo_finished':messages[-1],'original_controller_exit_code':None,'qualification':'Original controller interrupted; no original Cargo process exit status retained. Original final Cargo JSON success is verified; recovery does not rebuild or infer package/run success.', 'artifact':a[0], 'files':[identity(p) for p in sorted(paths)],'compiler':compiler,'host':host,'module':module,'llvm':str(llvm),'project_hash':pre['project_sha256'],'producer':str(producer)}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');args=parser.parse_args()
    function,modified,diff=fragments();before=verify_original()
    sys.path.insert(0,str(ROOT/'tools'));import export_native
    metadata=load(OUT/'command-023-stdout.txt');graph=export_native.normal_dependencies(metadata)
    before['normal_dependencies']=graph
    before['codegen']=export_native.verify_codegen((OLD_STAGE/'build.log').read_text(),before['host'],'packed')
    before['launcher']=identity(Path(__file__).resolve())
    if not args.execute:
        save(HERE/'before.json',before);(HERE/'probe-execution.patch').write_text(diff);(HERE/'unchanged-export-tail.py').write_text(function)
        print(json.dumps({'verified':True,'files':len(before['files']),'before_sha256':SHA(HERE/'before.json'),'patch_sha256':SHA(HERE/'probe-execution.patch'),'launcher_sha256':SHA(Path(__file__))}));return
    expected=load(HERE/'before.json');require(before==expected,'Reviewed recovery inputs changed')
    require((HERE/'probe-execution.patch').read_text()==diff and (HERE/'unchanged-export-tail.py').read_text()==function,'Reviewed execution fragments changed')
    # Preserve the originals before the unchanged proof resumes and deletes its own private inputs.
    archive=HERE/'original';archive.mkdir()
    for row in before['files']:
        p=Path(row['path'])
        if p.is_relative_to(OUT) and not p.is_relative_to(STORAGE/'target') and not p.is_relative_to(STORAGE/'cook-target'):
            dst=archive/p.relative_to(OUT);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
    producer=Path(before['producer']);shutil.copytree(producer,archive/'producer')
    namespace=dict(export_native.__dict__);exec(compile(function,str(EXPORT)+'#unchanged-post-build-tail','exec'),namespace)
    tail=namespace['recovered_tail'];used=False
    def recovered_build(project,staging,storage,scene,camera,mode,wabt=None):
        nonlocal used
        require(not used and project==OUT/'authoring/project.json' and scene is None and camera=='0000000000000000000000009C' and mode=='headless','Unexpected recovery request')
        used=True;source_check()
        require(wabt==OUT/'trusted-tools/wabt','Unexpected trusted translator')
        require(storage.is_relative_to(OUT/'private-builds') and storage!=STORAGE and not any(storage.iterdir()),'Unexpected new scratch')
        require(all(SHA(Path(row['path']))==row['sha256'] for row in before['files']),'Recovery input changed before packaging')
        shutil.copy2(OLD_STAGE/'build.log',staging/'build.log')
        player,report=tail(project,staging,STORAGE,scene,camera,mode,before['compiler'],before['host'],'dsym','packed',Path(before['llvm']),before['project_hash'],before['module'],graph,staging/'player-link.map',(OLD_STAGE/'build.log').read_text())
        save(HERE/'packaging.json',{'player_sha256':SHA(player),'normal_report':report,'unchanged_tail_sha256':hashlib.sha256(function.encode()).hexdigest(),'original_cargo_exit_code':None})
        # Old directories were created solely by this interrupted proof and verified above.
        for path in (STORAGE,OLD_STAGE):
            require(path.is_dir() and not path.is_symlink() and path.parent==OUT/'private-builds','Unsafe private cleanup');shutil.rmtree(path)
        require(not STORAGE.exists() and not OLD_STAGE.exists(),'Original build storage survived')
        return player,report
    def directories(trusted,scratch):
        require(trusted==OUT/'trusted-tools' and scratch==OUT/'private-builds','Unexpected recovery directories')
        require(set(scratch.iterdir())=={STORAGE,OLD_STAGE},'Unexpected recovered scratch contents')
    def provision(trusted):
        require(trusted==OUT/'trusted-tools','Unexpected translator directory')
        return trusted/'wabt',load(OUT/'wabt.json')
    export_native.build=recovered_build
    sys.argv=[str(PROBE),str(OUT),'--binary',str(RUN/'incant_headless'),'--oracle',str(RUN/'animation_compound_package_oracle'),'--stage','export']
    execution={'__name__':'__main__','__file__':str(PROBE),'recovery_directories':directories,'recovery_provision':provision}
    exec(compile(modified,str(PROBE)+'#two-recovery-setup-substitutions','exec'),execution)
    require(used and load(OUT/'result.json')['passed'],'Recovered proof incomplete')
    source_check()
    save(HERE/'result.json',{'passed':True,'original_controller_exit_code':None,'cargo_build_success_record':True,'same_shipping_artifact':load(HERE/'packaging.json')['player_sha256']==load(OUT/'result.json')['player_sha256'],'fresh_process_result':identity(OUT/'result.json'),'before':identity(HERE/'before.json'),'launcher':identity(Path(__file__)),'probe_execution_patch':identity(HERE/'probe-execution.patch'),'scope':'Original successful fresh shipping build reused only after full pinned input and Cargo completion verification. Original unchanged post-build audits/package/cleanup/startup and remaining proof assertions executed. Two harness setup substitutions; no repository edits or new Cargo build.'})
if __name__=='__main__':main()
