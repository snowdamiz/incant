def recovered_tail(project, staging, storage, scene, camera, mode, compiler, host, kind, split, llvm_bin, project_hash, module, graph, link_map, log):
    flags = verify_codegen(log, host, split)
    messages = cargo_messages(storage / 'cargo.jsonl')
    artifacts = [a for a in messages if a.get('reason') == 'compiler-artifact' and a['target']['name'] == NAME and a.get('executable')]
    require(len(artifacts) == 1, 'Missing unique actual player artifact')
    artifact = artifacts[0]
    executable = Path(artifact['executable'])
    outputs = [Path(a['out_dir']) for a in messages if a.get('reason') == 'build-script-executed'
               and a['package_id'] == artifact['package_id'] and (Path(a['out_dir']) / 'project-export.json').is_file()]
    require(len(outputs) == 1, 'Missing unique project cook output')
    producer = outputs[0]
    receipt = json.loads(read(producer / 'project-export.json', 4 * 1024**2))
    require(receipt['project_sha256'] == project_hash == sha256(read(project, 64 * 1024**2)), 'Project changed during build')
    require(receipt['target'] == host and receipt['startup_source_parsing'] is False, 'Project producer target/mode mismatch')
    if module is not None:
        require(all(receipt['program'].get(k) == v for k, v in module.items()), 'Wasm program changed during export')
    chosen_camera = select_camera(receipt, camera, mode == 'window')
    symbol_audit = runtime_symbol_audit(executable, kind, llvm_bin, link_map)
    player, identity = package(executable, staging, kind, llvm_bin)
    data = data_package(project.parent, producer, receipt, player.parent / 'data', chosen_camera)
    # Source maps are developer crash artifacts, never part of the runtime tree.
    for name in ('script-symbols.json', 'behavior.js.map'):
        source = producer / name
        if source.exists():
            shutil.copy2(source, staging / 'symbols' / name)
    write_json(staging / 'project-build.json', receipt)
    return player, {'format': 'incant-native-export', 'version': 1, 'target': host, 'mode': mode,
                    'project_sha256': project_hash, 'scene_id': receipt['scene_id'], 'camera': chosen_camera,
                    'program': receipt.get('program'), 'compiler': compiler, 'codegen': flags, 'normal_dependencies': graph, 'symbols': identity,
                    'symbol_audit': symbol_audit,
                    'player_sha256': sha256(read(player, 256 * 1024**2)), 'data': data,
                    'startup_source_parsing': False, 'signed': False,
                    'limits': ['host==target desktop only', 'existing cooked caches required',
                               'window export GPU execution requires a desktop', 'no phone or performance gate']}
