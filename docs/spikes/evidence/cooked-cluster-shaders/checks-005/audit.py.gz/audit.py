from pathlib import Path
import gzip,json,hashlib,re,subprocess,struct
repo=Path('/Users/andreyyurlov/.codex/worktrees/native-audio-host/incant')
h=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((repo/'docs/spikes/evidence/cooked-cluster-shaders.json').read_text())
for a in m['artifacts']:
 stored=(repo/a['retained']).read_bytes();assert h(stored)==a['sha256'],a['retained']
 raw=gzip.decompress(stored) if a['compression']=='gzip' else stored
 assert len(raw)==a['bytes'] and h(raw)==a['raw_sha256'],a['retained']
 assert Path(a['original']).read_bytes()==raw,a['original']
for s in m['sources']:
 assert h((repo/s['path']).read_bytes())==s['sha256'],s['path']
 assert h(Path(s['copy']).read_bytes())==s['sha256']
for c in m['checks']:
 assert c['exit']==0 and h(Path(c['log']).read_bytes())==c['sha256']
for t in m['test_counts']:
 c=next(c for c in m['checks'] if c['name']==t['name'])
 groups=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',Path(c['log']).read_text())
 assert [sum(int(g[i]) for g in groups) for i in range(3)]==[t['passed'],t['failed'],t['ignored']]
for c in m['offline']['commands']:
 assert c['exit']==0 and h(Path(c['output']).read_bytes())==c['sha256']
for a in m['offline']['artifacts']:
 data=Path(a['path']).read_bytes();assert len(data)==a['bytes'] and h(data)==a['sha256']
for c in m.get('ci_checks',{}).get('commands',[]):
 assert h(Path(c['log']).read_bytes())==c['sha256']
 assert c['exit']==(101 if c['name']=='original_ci_diagnostic' else 0)
for c in m.get('ci_validation',{}).get('commands',[]):
 assert c['exit']==0 and h(Path(c['log']).read_bytes())==c['sha256']
base=Path('/Users/andreyyurlov/.codex/incant-evidence')
before=(base/'cooked-cluster-checks-001/artifacts/Vulkan-Compute.shader').read_bytes()
after=(base/'cooked-cluster-checks-005/artifacts/Vulkan-Compute.shader').read_bytes()
w=struct.unpack('<%dI'%(len(before)//4),before);at=5;removed=0
while at<len(w):
 n=w[at]>>16;assert n>0 and at+n<=len(w)
 if n==4 and w[at]&65535==71 and w[at+2:at+4]==(6,4) and before[:4*at]+before[4*(at+n):]==after: removed+=1
 at+=n
assert removed==1
wgsl='crates/incant_render/src/lighting/grid.wgsl'
assert subprocess.check_output(['git','show',m['base']+':'+wgsl],cwd=repo)==(repo/wgsl).read_bytes()
print(json.dumps(dict(artifacts=len(m['artifacts']),sources=len(m['sources']),checks=len(m['checks']),offline_checks=len(m['offline']['commands']),single_stride_row_removed=True,wgsl_unchanged=True)))
