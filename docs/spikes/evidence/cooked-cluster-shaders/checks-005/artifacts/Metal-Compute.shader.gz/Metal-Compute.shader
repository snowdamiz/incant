// language: metal2.4
#include <metal_stdlib>
#include <simd/simd.h>

using metal::uint;

struct _mslBufferSizes {
    uint size1;
    uint size2;
    uint size3;
};

struct Light {
    metal::float4 position_range;
    metal::float4 direction_outer;
    metal::float4 radiance_inner;
    metal::uint4 kind;
};
struct Grid {
    metal::float4x4 view;
    metal::float4 viewport;
    metal::uint4 dimensions;
    metal::float4 depth;
    metal::uint4 lights;
};
typedef Light type_3[1];
typedef uint type_5[1];
struct type_7 {
    metal::atomic_uint inner[128];
};

bool intersects(
    metal::float3 position,
    float radius,
    metal::uint3 id_1,
    constant Grid& grid
) {
    bool local_1 = {};
    bool local_2 = {};
    bool local_3 = {};
    bool local_4 = {};
    bool local_5 = {};
    bool local_6 = {};
    bool local_7 = {};
    float r = radius + (0.00001 * metal::max(1.0, metal::max(metal::max(metal::abs(position.x), metal::abs(position.y)), metal::abs(position.z))));
    float _e19 = grid.depth.x;
    float _e25 = grid.depth.z;
    float z0_ = _e19 * metal::exp(static_cast<float>(id_1.z) / _e25);
    float _e32 = grid.depth.x;
    float _e40 = grid.depth.z;
    float z1_ = _e32 * metal::exp(static_cast<float>(id_1.z + 1u) / _e40);
    metal::float3 p = metal::float3(position.xy, -(position.z));
    if (!(((p.z + r) < z0_))) {
        local_1 = (p.z - r) > z1_;
    } else {
        local_1 = true;
    }
    bool _e58 = local_1;
    if (_e58) {
        return false;
    }
    metal::float4 _e66 = grid.viewport;
    metal::float2 lo = (static_cast<metal::float2>(id_1.xy) * 64.0) / _e66.zw;
    metal::float4 _e78 = grid.viewport;
    metal::float2 hi = metal::min((static_cast<metal::float2>(id_1.xy + metal::uint2(1u)) * 64.0) / _e78.zw, metal::float2(1.0));
    float tan_y = grid.depth.w;
    float _e91 = grid.viewport.z;
    float _e96 = grid.viewport.w;
    float tan_x = (tan_y * _e91) / _e96;
    float left = ((lo.x * 2.0) - 1.0) * tan_x;
    float right = ((hi.x * 2.0) - 1.0) * tan_x;
    float top = (1.0 - (lo.y * 2.0)) * tan_y;
    float bottom = (1.0 - (hi.y * 2.0)) * tan_y;
    uint _e125 = grid.lights.w;
    if (_e125 != 0u) {
        if ((p.x + r) >= left) {
            local_2 = (p.x - r) <= right;
        } else {
            local_2 = false;
        }
        bool _e137 = local_2;
        if (_e137) {
            local_3 = (p.y + r) >= bottom;
        } else {
            local_3 = false;
        }
        bool _e144 = local_3;
        if (_e144) {
            local_4 = (p.y - r) <= top;
        } else {
            local_4 = false;
        }
        bool _e151 = local_4;
        return _e151;
    }
    if ((p.x - (left * p.z)) >= (-(r) * metal::sqrt(1.0 + (left * left)))) {
        local_5 = ((right * p.z) - p.x) >= (-(r) * metal::sqrt(1.0 + (right * right)));
    } else {
        local_5 = false;
    }
    bool _e177 = local_5;
    if (_e177) {
        local_6 = (p.y - (bottom * p.z)) >= (-(r) * metal::sqrt(1.0 + (bottom * bottom)));
    } else {
        local_6 = false;
    }
    bool _e192 = local_6;
    if (_e192) {
        local_7 = ((top * p.z) - p.y) >= (-(r) * metal::sqrt(1.0 + (top * top)));
    } else {
        local_7 = false;
    }
    bool _e207 = local_7;
    return _e207;
}
uint naga_div(uint lhs, uint rhs) {
    return lhs / metal::select(rhs, 1u, rhs == 0u);
}

uint naga_mod(uint lhs, uint rhs) {
    return lhs % metal::select(rhs, 1u, rhs == 0u);
}


struct buildInput {
};
kernel void build(
  metal::uint3 id [[threadgroup_position_in_grid]]
, uint lane [[thread_index_in_threadgroup]]
, metal::uint3 __local_invocation_id [[thread_position_in_threadgroup]]
, constant Grid& grid [[buffer(0)]]
, device type_3 const& lights [[buffer(1)]]
, device type_5& counts [[buffer(2)]]
, device type_5& masks [[buffer(3)]]
, constant _mslBufferSizes& _buffer_sizes [[buffer(4)]]
) {
    threadgroup metal::atomic_uint hits;
    threadgroup type_7 membership;
    if (metal::all(__local_invocation_id == metal::uint3(0u))) {
        metal::atomic_store_explicit(&hits, 0, metal::memory_order_relaxed);
        for (int __i0 = 0; __i0 < 128; __i0++) {
            metal::atomic_store_explicit(&membership.inner[__i0], 0, metal::memory_order_relaxed);
        }
    }
    metal::threadgroup_barrier(metal::mem_flags::mem_threadgroup);
    uint word = {};
    uint local = {};
    uint word_1 = {};
    if (lane == 0u) {
        metal::atomic_store_explicit(&hits, 0u, metal::memory_order_relaxed);
    }
    word = lane;
    uint2 loop_bound = uint2(4294967295u);
    bool loop_init = true;
    while(true) {
        if (metal::all(loop_bound == uint2(0u))) { break; }
        loop_bound -= uint2(loop_bound.y == 0u, 1u);
        if (!loop_init) {
            uint _e17 = word;
            word = _e17 + 64u;
        }
        loop_init = false;
        uint _e7 = word;
        uint _e11 = grid.dimensions.w;
        if (_e7 < _e11) {
        } else {
            break;
        }
        {
            uint _e14 = word;
            metal::atomic_store_explicit(&membership.inner[metal::min(unsigned(_e14), 127u)], 0u, metal::memory_order_relaxed);
        }
    }
    metal::threadgroup_barrier(metal::mem_flags::mem_threadgroup);
    uint _e24 = grid.dimensions.y;
    uint _e31 = grid.dimensions.x;
    uint cluster = (((id.z * _e24) + id.y) * _e31) + id.x;
    local = lane;
    uint2 loop_bound_1 = uint2(4294967295u);
    bool loop_init_1 = true;
    while(true) {
        if (metal::all(loop_bound_1 == uint2(0u))) { break; }
        loop_bound_1 -= uint2(loop_bound_1.y == 0u, 1u);
        if (!loop_init_1) {
            uint _e77 = local;
            local = _e77 + 64u;
        }
        loop_init_1 = false;
        uint _e36 = local;
        uint _e40 = grid.lights.y;
        if (_e36 < _e40) {
        } else {
            break;
        }
        {
            uint _e46 = grid.lights.x;
            uint _e47 = local;
            Light light = lights[metal::min(unsigned(_e46 + _e47), (_buffer_sizes.size1 - 0 - 64) / 64)];
            metal::float4x4 _e53 = grid.view;
            metal::float3 p_1 = (_e53 * metal::float4(light.position_range.xyz, 1.0)).xyz;
            bool _e62 = intersects(p_1, light.position_range.w, id, grid);
            if (_e62) {
                uint _e65 = metal::atomic_fetch_add_explicit(&hits, 1u, metal::memory_order_relaxed);
                uint _e67 = local;
                uint _e72 = local;
                uint _e76 = metal::atomic_fetch_or_explicit(&membership.inner[metal::min(unsigned(naga_div(_e67, 32u)), 127u)], 1u << naga_mod(_e72, 32u), metal::memory_order_relaxed);
            }
        }
    }
    metal::threadgroup_barrier(metal::mem_flags::mem_threadgroup);
    word_1 = lane;
    uint2 loop_bound_2 = uint2(4294967295u);
    bool loop_init_2 = true;
    while(true) {
        if (metal::all(loop_bound_2 == uint2(0u))) { break; }
        loop_bound_2 -= uint2(loop_bound_2.y == 0u, 1u);
        if (!loop_init_2) {
            uint _e100 = word_1;
            word_1 = _e100 + 64u;
        }
        loop_init_2 = false;
        uint _e81 = word_1;
        uint _e85 = grid.dimensions.w;
        if (_e81 < _e85) {
        } else {
            break;
        }
        {
            uint _e91 = grid.dimensions.w;
            uint _e93 = word_1;
            uint _e97 = word_1;
            uint _e99 = metal::atomic_load_explicit(&membership.inner[metal::min(unsigned(_e97), 127u)], metal::memory_order_relaxed);
            masks[metal::min(unsigned((cluster * _e91) + _e93), (_buffer_sizes.size3 - 0 - 4) / 4)] = _e99;
        }
    }
    if (lane == 0u) {
        uint _e108 = metal::atomic_load_explicit(&hits, metal::memory_order_relaxed);
        counts[metal::min(unsigned(cluster), (_buffer_sizes.size2 - 0 - 4) / 4)] = _e108;
        return;
    } else {
        return;
    }
}
