import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path(__file__).parent
repo=Path('/Users/andreyyurlov/.codex/worktrees/native-audio-host/incant')
env=dict(os.environ);env.update(PATH='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:'+env.get('PATH',''),CARGO_TARGET_DIR='/tmp/incant-physics-variant-target',CARGO_BUILD_JOBS='2')
env['INCANT_CLUSTER_COOK_EVIDENCE']=str(root/'artifacts')
features='cooked-geometry,cooked-sprites,cooked-ui,cooked-text,cooked-materials,cooked-clusters'
cargo=str(repo/'tools/cargo')
commands=[
('cook',[cargo,'test','--locked','-p','incant_shader_cook']),
('cluster-alone',[cargo,'test','--locked','-p','incant_render','--features','cooked-clusters']),
('all-cooked',[cargo,'test','--locked','-p','incant_render','--features',features]),
('clippy',[cargo,'clippy','--locked','-p','incant_shader_cook','-p','incant_render','--all-targets','--features',features,'--','-D','warnings']),
('default',[cargo,'test','--locked','-p','incant_render','--lib']),
('web',[cargo,'check','--locked','-p','incant_render','--lib','--target','wasm32-unknown-unknown','--features',features]),
('web-alone',[cargo,'check','--locked','-p','incant_render','--lib','--target','wasm32-unknown-unknown','--features','cooked-clusters']),
('graph',['python3','tools/check_runtime_dependencies.py','incant_render','--features',','.join('incant_render/'+f for f in features.split(','))]),
('fmt',[cargo,'fmt','--all','--','--check']),
('conventions',['python3','tools/generate_conventions.py','--check']),
('diff',['git','diff','--check'])]
rows=[]
for name,argv in commands:
 print('START '+name,flush=True);start=time.time();path=root/(name+'.log')
 with path.open('wb') as log:r=subprocess.run(argv,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(name=name,argv=argv,exit=r.returncode,elapsed_seconds=time.time()-start,log=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
 (root/'checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 print('END '+name+' '+str(r.returncode),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
