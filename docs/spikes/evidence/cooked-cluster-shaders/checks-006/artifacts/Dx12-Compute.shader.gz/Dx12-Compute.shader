struct NagaConstants {
    int first_vertex;
    int first_instance;
    uint other;
};
ConstantBuffer<NagaConstants> _NagaConstants: register(b2);

struct Light {
    float4 position_range;
    float4 direction_outer;
    float4 radiance_inner;
    uint4 kind;
};

struct Grid {
    row_major float4x4 view;
    float4 viewport;
    uint4 dimensions;
    float4 depth;
    uint4 lights;
};

cbuffer grid : register(b0) { Grid grid; }
ByteAddressBuffer lights : register(t0);
RWByteAddressBuffer counts : register(u0);
RWByteAddressBuffer masks : register(u1);
groupshared uint hits;
groupshared uint membership[128];

bool intersects(float3 position, float radius, uint3 id_1)
{
    bool local_1 = (bool)0;
    bool local_2 = (bool)0;
    bool local_3 = (bool)0;
    bool local_4 = (bool)0;
    bool local_5 = (bool)0;
    bool local_6 = (bool)0;
    bool local_7 = (bool)0;

    float r = (radius + (1e-5 * max(1.0, max(max(abs(position.x), abs(position.y)), abs(position.z)))));
    float _e19 = grid.depth.x;
    float _e25 = grid.depth.z;
    float z0_ = (_e19 * exp((float(id_1.z) / _e25)));
    float _e32 = grid.depth.x;
    float _e40 = grid.depth.z;
    float z1_ = (_e32 * exp((float((id_1.z + 1u)) / _e40)));
    float3 p = float3(position.xy, -(position.z));
    if (!(((p.z + r) < z0_))) {
        local_1 = ((p.z - r) > z1_);
    } else {
        local_1 = true;
    }
    bool _e58 = local_1;
    if (_e58) {
        return false;
    }
    float4 _e66 = grid.viewport;
    float2 lo = ((float2(id_1.xy) * 64.0) / _e66.zw);
    float4 _e78 = grid.viewport;
    float2 hi = min(((float2((id_1.xy + (1u).xx)) * 64.0) / _e78.zw), (1.0).xx);
    float tan_y = grid.depth.w;
    float _e91 = grid.viewport.z;
    float _e96 = grid.viewport.w;
    float tan_x = ((tan_y * _e91) / _e96);
    float left = (((lo.x * 2.0) - 1.0) * tan_x);
    float right = (((hi.x * 2.0) - 1.0) * tan_x);
    float top = ((1.0 - (lo.y * 2.0)) * tan_y);
    float bottom = ((1.0 - (hi.y * 2.0)) * tan_y);
    uint _e125 = grid.lights.w;
    if ((_e125 != 0u)) {
        if (((p.x + r) >= left)) {
            local_2 = ((p.x - r) <= right);
        } else {
            local_2 = false;
        }
        bool _e137 = local_2;
        if (_e137) {
            local_3 = ((p.y + r) >= bottom);
        } else {
            local_3 = false;
        }
        bool _e144 = local_3;
        if (_e144) {
            local_4 = ((p.y - r) <= top);
        } else {
            local_4 = false;
        }
        bool _e151 = local_4;
        return _e151;
    }
    if (((p.x - (left * p.z)) >= (-(r) * sqrt((1.0 + (left * left)))))) {
        local_5 = (((right * p.z) - p.x) >= (-(r) * sqrt((1.0 + (right * right)))));
    } else {
        local_5 = false;
    }
    bool _e177 = local_5;
    if (_e177) {
        local_6 = ((p.y - (bottom * p.z)) >= (-(r) * sqrt((1.0 + (bottom * bottom)))));
    } else {
        local_6 = false;
    }
    bool _e192 = local_6;
    if (_e192) {
        local_7 = (((top * p.z) - p.y) >= (-(r) * sqrt((1.0 + (top * top)))));
    } else {
        local_7 = false;
    }
    bool _e207 = local_7;
    return _e207;
}

uint naga_div(uint lhs, uint rhs) {
    return lhs / (rhs == 0u ? 1u : rhs);
}

uint naga_mod(uint lhs, uint rhs) {
    return lhs % (rhs == 0u ? 1u : rhs);
}

Light ConstructLight(float4 arg0, float4 arg1, float4 arg2, uint4 arg3) {
    Light ret = (Light)0;
    ret.position_range = arg0;
    ret.direction_outer = arg1;
    ret.radiance_inner = arg2;
    ret.kind = arg3;
    return ret;
}

[numthreads(64, 1, 1)]
void build(uint3 id : SV_GroupID, uint lane : SV_GroupIndex, uint3 local_invocation_id : SV_GroupThreadID)
{
    if (all(local_invocation_id == uint3(0u, 0u, 0u))) {
        hits = (uint)0;
        membership = (uint[128])0;
    }
    GroupMemoryBarrierWithGroupSync();
    uint word = (uint)0;
    uint local = (uint)0;
    uint word_1 = (uint)0;

    if ((lane == 0u)) {
        hits = 0u;
    }
    word = lane;
    uint2 loop_bound = uint2(4294967295u, 4294967295u);
    bool loop_init = true;
    while(true) {
        if (all(loop_bound == uint2(0u, 0u))) { break; }
        loop_bound -= uint2(loop_bound.y == 0u, 1u);
        if (!loop_init) {
            uint _e17 = word;
            word = (_e17 + 64u);
        }
        loop_init = false;
        uint _e7 = word;
        uint _e11 = grid.dimensions.w;
        if ((_e7 < _e11)) {
        } else {
            break;
        }
        {
            uint _e14 = word;
            membership[min(uint(_e14), 127u)] = 0u;
        }
    }
    GroupMemoryBarrierWithGroupSync();
    uint _e24 = grid.dimensions.y;
    uint _e31 = grid.dimensions.x;
    uint cluster = ((((id.z * _e24) + id.y) * _e31) + id.x);
    local = lane;
    uint2 loop_bound_1 = uint2(4294967295u, 4294967295u);
    bool loop_init_1 = true;
    while(true) {
        if (all(loop_bound_1 == uint2(0u, 0u))) { break; }
        loop_bound_1 -= uint2(loop_bound_1.y == 0u, 1u);
        if (!loop_init_1) {
            uint _e77 = local;
            local = (_e77 + 64u);
        }
        loop_init_1 = false;
        uint _e36 = local;
        uint _e40 = grid.lights.y;
        if ((_e36 < _e40)) {
        } else {
            break;
        }
        {
            uint _e46 = grid.lights.x;
            uint _e47 = local;
            Light light = ConstructLight(asfloat(lights.Load4((_e46 + _e47)*64+0)), asfloat(lights.Load4((_e46 + _e47)*64+16)), asfloat(lights.Load4((_e46 + _e47)*64+32)), asuint(lights.Load4((_e46 + _e47)*64+48)));
            float4x4 _e53 = grid.view;
            float3 p_1 = mul(float4(light.position_range.xyz, 1.0), _e53).xyz;
            const bool _e62 = intersects(p_1, light.position_range.w, id);
            if (_e62) {
                uint _e65; InterlockedAdd(hits, 1u, _e65);
                uint _e67 = local;
                uint _e72 = local;
                uint _e76; InterlockedOr(membership[min(uint(naga_div(_e67, 32u)), 127u)], (1u << naga_mod(_e72, 32u)), _e76);
            }
        }
    }
    GroupMemoryBarrierWithGroupSync();
    word_1 = lane;
    uint2 loop_bound_2 = uint2(4294967295u, 4294967295u);
    bool loop_init_2 = true;
    while(true) {
        if (all(loop_bound_2 == uint2(0u, 0u))) { break; }
        loop_bound_2 -= uint2(loop_bound_2.y == 0u, 1u);
        if (!loop_init_2) {
            uint _e100 = word_1;
            word_1 = (_e100 + 64u);
        }
        loop_init_2 = false;
        uint _e81 = word_1;
        uint _e85 = grid.dimensions.w;
        if ((_e81 < _e85)) {
        } else {
            break;
        }
        {
            uint _e91 = grid.dimensions.w;
            uint _e93 = word_1;
            uint _e97 = word_1;
            uint _e99 = membership[min(uint(_e97), 127u)];
            masks.Store(((cluster * _e91) + _e93)*4, asuint(_e99));
        }
    }
    if ((lane == 0u)) {
        uint _e108 = hits;
        counts.Store(cluster*4, asuint(_e108));
        return;
    } else {
        return;
    }
}
