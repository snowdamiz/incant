//! Conservative clustered forward lighting with exact, bounded membership masks.
//! Buffers are retained at one grid size/light count; encoded commands preserve
//! replaced buffers across resize. No cluster truncates lights or falls back.
#[cfg(all(feature = "cooked-clusters", not(target_arch = "wasm32")))]
mod cooked;
#[cfg(test)]
#[path = "../../tests/lighting_gpu/mod.rs"]
mod gpu_tests;
pub(crate) mod scene;
use crate::{ResourceError, Result};
use std::sync::{Arc, Mutex};
use wgpu::util::DeviceExt;
pub(crate) const DEPTH_SLICES: u32 = 24;
const MAX_MASK_WORDS: u32 = (scene::MAX_LOCAL as u32).div_ceil(32);

/// Read-only light selection for a prepared scene. This does not edit the project.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum LocalLightSelection {
    /// Select conservative view clusters; the normal rendering path.
    #[default]
    Clustered,
    /// Evaluate every local light, bypassing spatial selection for diagnostics.
    /// This deliberately expensive reference path shares only the shading math.
    All,
}
const MAX_CLUSTERS: u32 = 131072;
#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
pub(crate) struct GridUniform {
    pub view: [[f32; 4]; 4],
    pub viewport: [f32; 4],
    pub dimensions: [u32; 4],
    pub depth: [f32; 4],
    pub lights: [u32; 4],
}
const _: () = {
    assert!(size_of::<GridUniform>() == 128);
    assert!(std::mem::offset_of!(GridUniform, view) == 0);
    assert!(std::mem::offset_of!(GridUniform, viewport) == 64);
    assert!(std::mem::offset_of!(GridUniform, dimensions) == 80);
    assert!(std::mem::offset_of!(GridUniform, depth) == 96);
    assert!(std::mem::offset_of!(GridUniform, lights) == 112);
};
pub(crate) struct GpuLights {
    buffer: wgpu::Buffer,
    directional: u32,
    local: u32,
    positions: Vec<glam::Vec3>,
    pub shadows: Vec<crate::shadows::ShadowLight>,
}
impl GpuLights {
    pub fn validate_view(&self, view: glam::Mat4) -> std::result::Result<(), crate::SceneError> {
        if self
            .positions
            .iter()
            .any(|p| !view.transform_point3(*p).is_finite())
        {
            return Err(crate::SceneError::LightTransform);
        }
        Ok(())
    }

    pub fn stage(&mut self, plan: &mut scene::LightPlan, packed: &mut Vec<scene::Light>) {
        self.directional = plan.copy_into(packed, &mut self.shadows);
        self.local = packed.len() as u32 - self.directional;
        self.positions.clear();
        self.positions.extend(
            packed[self.directional as usize..]
                .iter()
                .map(|l| glam::Vec3::from_slice(&l.position_range[..3])),
        );
    }
    pub fn write(&self, queue: &wgpu::Queue, packed: &[scene::Light]) {
        queue.write_buffer(&self.buffer, 0, bytemuck::cast_slice(packed));
    }

    pub fn upload(device: &wgpu::Device, plan: scene::LightPlan) -> Self {
        let (lights, directional, shadows) = plan.finish();
        Self {
            shadows,
            positions: lights[directional as usize..]
                .iter()
                .map(|l| glam::Vec3::from_slice(&l.position_range[..3]))
                .collect(),
            buffer: device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: Some("Immutable authored lights"),
                contents: bytemuck::cast_slice(&lights),
                usage: wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_DST,
            }),
            directional,
            local: lights.len() as u32 - directional,
        }
    }
}
pub(crate) struct GridBuffers {
    dimensions: [u32; 2],
    pub counts: wgpu::Buffer,
    words: u32,
    pub masks: wgpu::Buffer,
}
pub(crate) struct LightingSystem {
    pub layout: wgpu::BindGroupLayout,
    compute_layout: wgpu::BindGroupLayout,
    pipeline: wgpu::ComputePipeline,
    cache: Mutex<Option<Arc<GridBuffers>>>,
}
pub(crate) fn layout_entries(compute: bool) -> Vec<wgpu::BindGroupLayoutEntry> {
    let mut entries: Vec<_> = (0..4)
        .map(|binding| wgpu::BindGroupLayoutEntry {
            binding,
            visibility: if compute {
                wgpu::ShaderStages::COMPUTE
            } else {
                wgpu::ShaderStages::FRAGMENT
            },
            ty: wgpu::BindingType::Buffer {
                ty: if binding == 0 {
                    wgpu::BufferBindingType::Uniform
                } else {
                    wgpu::BufferBindingType::Storage {
                        read_only: !compute || binding == 1,
                    }
                },
                has_dynamic_offset: false,
                min_binding_size: None,
            },
            count: None,
        })
        .collect();
    if compute {
        #[cfg(all(feature = "cooked-clusters", not(target_arch = "wasm32")))]
        entries.push(wgpu::BindGroupLayoutEntry {
            binding: 4,
            visibility: wgpu::ShaderStages::COMPUTE,
            ty: wgpu::BindingType::Buffer {
                ty: wgpu::BufferBindingType::Uniform,
                has_dynamic_offset: false,
                min_binding_size: wgpu::BufferSize::new(16),
            },
            count: None,
        });
    } else {
        entries.extend([
            wgpu::BindGroupLayoutEntry {
                binding: 4,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Texture {
                    sample_type: wgpu::TextureSampleType::Depth,
                    view_dimension: wgpu::TextureViewDimension::D2Array,
                    multisampled: false,
                },
                count: None,
            },
            wgpu::BindGroupLayoutEntry {
                binding: 5,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Comparison),
                count: None,
            },
            wgpu::BindGroupLayoutEntry {
                binding: 6,
                visibility: wgpu::ShaderStages::FRAGMENT,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            },
        ]);
        #[cfg(all(feature = "cooked-materials", not(target_arch = "wasm32")))]
        entries.push(wgpu::BindGroupLayoutEntry {
            binding: 7,
            visibility: wgpu::ShaderStages::FRAGMENT,
            ty: wgpu::BindingType::Buffer {
                ty: wgpu::BufferBindingType::Uniform,
                has_dynamic_offset: false,
                min_binding_size: wgpu::BufferSize::new(16),
            },
            count: None,
        });
    }
    entries
}
fn layout(device: &wgpu::Device, compute: bool) -> wgpu::BindGroupLayout {
    device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
        label: Some("Clustered lighting"),
        entries: &layout_entries(compute),
    })
}
impl LightingSystem {
    pub fn new(device: &wgpu::Device, _backend: wgpu::Backend) -> Result<Self> {
        let compute_layout = layout(device, true);
        let layout = layout(device, false);
        #[cfg(all(feature = "cooked-clusters", not(target_arch = "wasm32")))]
        let (shader, entry) = cooked::shader(device, _backend)?;
        #[cfg(not(all(feature = "cooked-clusters", not(target_arch = "wasm32"))))]
        let (shader, entry) = (
            device.create_shader_module(wgpu::ShaderModuleDescriptor {
                label: Some("Light cluster assignment"),
                source: wgpu::ShaderSource::Wgsl(include_str!("grid.wgsl").into()),
            }),
            "build",
        );
        let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("Light cluster assignment"),
            bind_group_layouts: &[Some(&compute_layout)],
            immediate_size: 0,
        });
        let pipeline = device.create_compute_pipeline(&wgpu::ComputePipelineDescriptor {
            label: Some("Light cluster assignment"),
            layout: Some(&pipeline_layout),
            module: &shader,
            entry_point: Some(entry),
            compilation_options: Default::default(),
            cache: None,
        });
        Ok(Self {
            layout,
            compute_layout,
            pipeline,
            cache: Mutex::new(None),
        })
    }
    fn buffers(
        &self,
        device: &wgpu::Device,
        dimensions: [u32; 2],
        words: u32,
    ) -> Result<Arc<GridBuffers>> {
        if !(1..=MAX_MASK_WORDS).contains(&words) {
            return Err(ResourceError::LightGridSize.into());
        }
        let count = dimensions[0]
            .checked_mul(dimensions[1])
            .and_then(|n| n.checked_mul(DEPTH_SLICES))
            .filter(|n| *n > 0 && *n <= MAX_CLUSTERS)
            .ok_or(ResourceError::LightGridSize)?;
        let bytes = u64::from(count) * u64::from(words) * 4;
        if bytes > device.limits().max_storage_buffer_binding_size
            || bytes > device.limits().max_buffer_size
        {
            return Err(ResourceError::LightGridSize.into());
        }
        let mut cached = self
            .cache
            .lock()
            .map_err(|_| ResourceError::CacheLock("light grid"))?;
        if let Some(buffers) = cached
            .as_ref()
            .filter(|b| b.dimensions == dimensions && b.words == words)
        {
            return Ok(Arc::clone(buffers));
        }
        let make = |label, size| {
            device.create_buffer(&wgpu::BufferDescriptor {
                label: Some(label),
                size,
                usage: wgpu::BufferUsages::STORAGE | wgpu::BufferUsages::COPY_SRC,
                mapped_at_creation: false,
            })
        };
        let buffers = Arc::new(GridBuffers {
            dimensions,
            words,
            counts: make("Cluster light counts", u64::from(count) * 4),
            masks: make("Cluster light membership masks", bytes),
        });
        *cached = Some(Arc::clone(&buffers));
        Ok(buffers)
    }
    pub fn prepare(
        &self,
        device: &wgpu::Device,
        lights: &GpuLights,
        viewport: [f32; 4],
        selection: LocalLightSelection,
        camera: crate::camera::CameraView,
        shadows: &crate::shadows::PreparedShadows,
    ) -> Result<PreparedLighting> {
        let dimensions = [
            (viewport[2] / 64.).ceil() as u32,
            (viewport[3] / 64.).ceil() as u32,
        ];
        let clustered = lights.local > 0 && selection == LocalLightSelection::Clustered;
        let words = lights.local.div_ceil(32).max(1);
        // The all-light diagnostic and directional-only paths never access masks.
        let buffers = self.buffers(
            device,
            if clustered { dimensions } else { [1, 1] },
            if clustered { words } else { 1 },
        )?;
        let grid = GridUniform {
            view: camera.view.to_cols_array_2d(),
            viewport,
            dimensions: [dimensions[0], dimensions[1], DEPTH_SLICES, words],
            depth: [
                camera.near,
                camera.far,
                DEPTH_SLICES as f32 / (camera.far / camera.near).ln(),
                camera.vertical_parameter(),
            ],
            lights: [
                lights.directional,
                lights.local,
                u32::from(!clustered),
                u32::from(camera.orthographic_half_height.is_some()),
            ],
        };
        let uniform = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("Immutable light grid frame"),
            contents: bytemuck::bytes_of(&grid),
            usage: wgpu::BufferUsages::UNIFORM,
        });
        #[cfg(all(feature = "cooked-clusters", not(target_arch = "wasm32")))]
        let compute_sizes = if clustered {
            let sizes = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: Some("Cluster storage byte lengths"),
                contents: bytemuck::cast_slice(
                    &storage_lengths([
                        lights.buffer.size(),
                        buffers.counts.size(),
                        buffers.masks.size(),
                    ])
                    .map_err(ResourceError::CookedCluster)?,
                ),
                usage: wgpu::BufferUsages::UNIFORM,
            });
            Some(sizes)
        } else {
            None
        };
        let mut entries = [&uniform, &lights.buffer, &buffers.counts, &buffers.masks]
            .iter()
            .enumerate()
            .map(|(binding, buffer)| wgpu::BindGroupEntry {
                binding: binding as u32,
                resource: buffer.as_entire_binding(),
            })
            .collect::<Vec<_>>();
        let compute = if clustered {
            #[cfg(all(feature = "cooked-clusters", not(target_arch = "wasm32")))]
            entries.push(wgpu::BindGroupEntry {
                binding: 4,
                resource: compute_sizes
                    .as_ref()
                    .expect("clustered sizes")
                    .as_entire_binding(),
            });
            let group = device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: Some("Cluster assignment frame"),
                layout: &self.compute_layout,
                entries: &entries,
            });
            // Binding4 in the fragment group is the shadow texture, not sizes.
            #[cfg(all(feature = "cooked-clusters", not(target_arch = "wasm32")))]
            entries.pop();
            Some(ClusterPass {
                pipeline: self.pipeline.clone(),
                group,
                dimensions,
            })
        } else {
            None
        };
        entries.extend([
            wgpu::BindGroupEntry {
                binding: 4,
                resource: wgpu::BindingResource::TextureView(&shadows.view),
            },
            wgpu::BindGroupEntry {
                binding: 5,
                resource: wgpu::BindingResource::Sampler(&shadows.sampler),
            },
            wgpu::BindGroupEntry {
                binding: 6,
                resource: shadows.uniform.as_entire_binding(),
            },
        ]);
        // Metal passthrough omits Naga's dynamic-storage reflection. Bind the
        // three real byte lengths explicitly in the compiler's verified order;
        // never disable bounds checks or read a synthetic unset lengths buffer.
        #[cfg(all(feature = "cooked-materials", not(target_arch = "wasm32")))]
        let sizes = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("Material storage byte lengths"),
            contents: bytemuck::cast_slice(
                &storage_lengths([
                    lights.buffer.size(),
                    buffers.counts.size(),
                    buffers.masks.size(),
                ])
                .map_err(ResourceError::CookedMaterial)?,
            ),
            usage: wgpu::BufferUsages::UNIFORM,
        });
        #[cfg(all(feature = "cooked-materials", not(target_arch = "wasm32")))]
        entries.push(wgpu::BindGroupEntry {
            binding: 7,
            resource: sizes.as_entire_binding(),
        });
        Ok(PreparedLighting {
            compute,
            shading: device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: Some("Cluster shading frame"),
                layout: &self.layout,
                entries: &entries,
            }),
        })
    }
}
#[cfg(all(
    any(feature = "cooked-materials", feature = "cooked-clusters"),
    not(target_arch = "wasm32")
))]
fn storage_lengths(bytes: [u64; 3]) -> std::result::Result<[u32; 4], &'static str> {
    let mut values = [0; 4];
    for (i, (size, stride)) in bytes.into_iter().zip([64, 4, 4]).enumerate() {
        if size == 0 || size % stride != 0 {
            return Err("storage buffer alignment");
        }
        values[i] = u32::try_from(size).map_err(|_| "storage buffer length")?;
    }
    Ok(values)
}
#[cfg(all(
    test,
    any(feature = "cooked-materials", feature = "cooked-clusters"),
    not(target_arch = "wasm32")
))]
#[test]
fn material_lengths_use_allocation_bytes_and_refuse_truncation() {
    assert_eq!(
        storage_lengths([64 * 4112, 4 * 24, 4 * 24 * 128]).unwrap(),
        [263168, 96, 12288, 0]
    );
    for sizes in [
        [0, 4, 4],
        [63, 4, 4],
        [64, 5, 4],
        [64, 4, 5],
        [1u64 << 32, 4, 4],
        [64, 1u64 << 32, 4],
        [64, 4, 1u64 << 32],
    ] {
        assert!(storage_lengths(sizes).is_err());
    }
}
/// Immutable uniforms and retained storage bindings for one encoded frame.
pub(crate) struct PreparedLighting {
    pub shading: wgpu::BindGroup,
    pub compute: Option<ClusterPass>,
}
pub(crate) struct ClusterPass {
    pipeline: wgpu::ComputePipeline,
    group: wgpu::BindGroup,
    dimensions: [u32; 2],
}
impl ClusterPass {
    pub fn encode(&self, encoder: &mut wgpu::CommandEncoder) {
        // Every used cluster word is overwritten, including empty clusters.
        let mut pass = encoder.begin_compute_pass(&wgpu::ComputePassDescriptor {
            label: Some("Assign local lights to view clusters"),
            timestamp_writes: None,
        });
        pass.set_pipeline(&self.pipeline);
        pass.set_bind_group(0, &self.group, &[]);
        pass.dispatch_workgroups(self.dimensions[0], self.dimensions[1], DEPTH_SLICES);
    }
}
