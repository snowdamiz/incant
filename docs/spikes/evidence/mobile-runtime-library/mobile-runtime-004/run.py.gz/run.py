import os,pathlib,subprocess,json,time,hashlib,datetime
root=pathlib.Path('/Users/andreyyurlov/.codex/worktrees/responsive-project-loading/incant');out=pathlib.Path(__file__).parent
os.chdir(root);env=dict(os.environ,CARGO_TARGET_DIR='/Users/andreyyurlov/.codex/incant-mobile-runtime-target',CARGO_BUILD_JOBS='4')
commands=[['./tools/cargo','test','--locked','--profile','ci','-p','incant_game_player','--features','mobile-ffi'],['./tools/cargo','clippy','--locked','--profile','ci','-p','incant_game_player','--features','mobile-ffi','--all-targets','--','-D','warnings']]
receipts=[];freeze=json.loads((out/'freeze.json').read_text());code=0
for i,cmd in enumerate(commands):
 start=time.monotonic();log=out/f'command-{i}.log'
 with log.open('w') as f: code=subprocess.call(cmd,stdout=f,stderr=subprocess.STDOUT,env=env)
 receipts.append({'argv':cmd,'exit_code':code,'seconds':time.monotonic()-start,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()});(out/'commands.json').write_text(json.dumps(receipts,indent=2)+'\n')
 if code:break
changed=[p for p,h in freeze.items() if not (root/p).is_file() or hashlib.sha256((root/p).read_bytes()).hexdigest()!=h]
(out/'terminal.json').write_text(json.dumps({'exit_code':code,'changed':changed,'frozen_files':len(freeze),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
print({'exit_code':code,'changed':changed,'commands':len(receipts)},flush=True)
raise SystemExit(code or bool(changed))
