import json,sys,os,time,hashlib,subprocess
from pathlib import Path
R=Path('/Users/andreyyurlov/.codex/worktrees/physics-failure-isolation/incant');E=Path(__file__).resolve().parent
sys.path[:0]=[str(R/'tools'),str(R/'tools/probes')]
from native_wasm_restart.owner import Owner,tree_bytes,process_rows
P=json.loads((E/'plan.json').read_text());T=Path(P['target'])
def source():return {p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=R,text=True).splitlines() if(R/p).is_file()}
assert source()==json.loads((E/'sources.json').read_text()) and tree_bytes(T)==P['initial_bytes']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
env=dict(os.environ);env.update(PATH='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/Users/andreyyurlov/.cargo/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',CARGO_TARGET_DIR=str(T),CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='2',RUST_TEST_THREADS='2',CARGO_INCREMENTAL='0',CARGO_NET_OFFLINE='true',CARGO_TERM_COLOR='never')
o=Owner(E/'output',T,P['target_cap']);o.deadline=o.start+P['seconds'];o.peaks['target']=max(P['prior_target_peak'],P['initial_bytes']);env['TMPDIR']=str(o.scratch)
r={'passed':False,'source':P['source'],'wrapper_pid':os.getpid(),'stages':[]}
try:
 with o:
  for argv in P['steps']:
   print('RUN',argv[:3],flush=True);start=time.monotonic();x=o.run(argv,cwd=R,env=env,timeout=360)
   row={'argv':argv,'exit':x.returncode,'seconds':time.monotonic()-start};r['stages'].append(row)
   if x.returncode:print(x.stderr[-9000:],flush=True)
   assert x.returncode==0,row
   if argv[0]=='cargo':
    row['summaries']=[line for line in x.stdout.splitlines() if line.startswith('test result:')];assert all(s.startswith('test result: ok.') for s in row['summaries'])
    row['local_artifacts']=[json.loads(s)for s in x.stdout.splitlines() if s.startswith('{') and json.loads(s).get('reason')=='compiler-artifact' and json.loads(s)['package_id'].startswith('path+')]
  assert source()==json.loads((E/'sources.json').read_text());r['passed']=True;o.passed=True
except BaseException as e:r['error']=repr(e)
r.update(seconds=time.monotonic()-o.start,source_unchanged=source()==json.loads((E/'sources.json').read_text()),groups=o.groups,peaks=o.peaks)
rows=process_rows();r['all_groups_absent']=all(not any(g['pid'] in (p,group) for p,group,_ in rows)for g in o.groups)
r['passed'] &= r['all_groups_absent'] and r['source_unchanged']
(E/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k not in ('stages','groups')}),flush=True)
raise SystemExit(0 if r['passed'] else 1)
