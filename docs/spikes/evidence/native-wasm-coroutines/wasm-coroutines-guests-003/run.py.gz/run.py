import hashlib,importlib.util,json,os,shutil,subprocess,sys,time,types
from pathlib import Path
E=Path(__file__).resolve().parent;P=json.loads((E/'plan.json').read_text());R=Path(P['source_root']);T=Path(P['target'])
sys.path[:0]=[str(R/'tools'),str(R/'tools/probes')]
from native_wasm_restart.owner import Owner,tree_bytes,process_rows,MIB,GIB
import rust_guest,wasm2c
sha=lambda p:hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()
def save(n,d):(E/n).write_text(json.dumps(d,indent=2)+'\n')
def sources():return {n:sha(R/n)for n in subprocess.check_output(['git','ls-files','-co','--exclude-standard'],cwd=R,text=True).splitlines()if(R/n).is_file()}
def protected():
 for p,row in json.loads((E/'protected.json').read_text()).items():assert Path(p).stat().st_size==row['bytes'] and sha(p)==row['sha256'],p
 for p,h in json.loads((E/'wabt.json').read_text()).items():assert sha(p)==h,p
assert sources()==json.loads((E/'sources.json').read_text());protected()
assert tree_bytes(T)==P['initial_target_bytes'];assert shutil.disk_usage(T).free>=6*GIB+P['target_cap']-tree_bytes(T)+2*GIB
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True).strip()
o=Owner(E/'output',T,P['target_cap']);o.deadline=o.start+P['scope_seconds'];o.peaks['target']=P['prior_target_peak']
env={**P['environment'],'TMPDIR':str(o.scratch),'RUST_TEST_THREADS':'2'}
cargo=Path(env['RUSTC']).with_name('cargo')
r={'passed':False,'wrapper_pid':os.getpid(),'source':P['source_head'],'plan_sha256':sha(E/'plan.json'),'runner_sha256':sha(__file__),'prior_seconds':P['prior_seconds'],'stages':[],'artifacts':[],'GPU':False,'native_window':False}
def run(argv,*,timeout=120,**kw):
 kw.pop('capture_output',None);kw.setdefault('env',env);kw.setdefault('cwd',R)
 result=o.run(argv,timeout=timeout,**kw)
 assert result.returncode==0 and o.calls[-1]['cleanup_confirmed'],(argv,result.returncode)
 return result
def check_output(argv,**kw):
 text=kw.get('text',False);kw['text']=True;v=run(argv,**kw).stdout;return v if text else v.encode()
def cargo_stage(name,args,tests=None,timeout=600):
 print(name,flush=True);start=time.monotonic()
 done=run([cargo,*args,'--profile','ci','-j2','--locked','--offline','--no-default-features','--message-format=json'],timeout=timeout)
 rows=[json.loads(l)for l in done.stdout.splitlines()if l.startswith('{')]
 assert [m['success']for m in rows if m.get('reason')=='build-finished']==[True]
 sums=[l for l in done.stdout.splitlines()if l.startswith('test result:')]
 if tests is not None:assert len(sums)==tests and all(l.startswith('test result: ok.')for l in sums),sums
 local=[m for m in rows if m.get('reason')=='compiler-artifact' and m['package_id'].startswith('path+')]
 for m in local:
  if m.get('executable') and (m['profile']['test'] or m['target']['name']=='incant_wasm_cook'):
   f=Path(m['executable']);assert f.stat().st_size<=256*MIB;h=sha(f)
   if not any(x['sha256']==h for x in r['artifacts']):
    dest=E/('artifact-'+str(len(r['artifacts'])));shutil.copy2(f,dest);assert sha(dest)==h
    r['artifacts'].append({'copy':str(dest),'source':str(f),'bytes':f.stat().st_size,'sha256':h,'cargo':m})
 r['stages'].append({'name':name,'seconds':time.monotonic()-start,'local_producers':local,'test_summaries':sums});save('partial.json',r);protected();return rows
try:
 with o:
  cargo_stage('fresh-normal-cooker',['build','-p','incant_wasm_cook','--bin','incant_wasm_cook'])
  cook=Path(next(a['copy']for a in r['artifacts']if a['cargo']['target']['name']=='incant_wasm_cook'))
  print('actual SDK and static bundle',flush=True);inputs=o.output/'inputs';inputs.mkdir();guests=inputs/'guests';guests.mkdir()
  spec=importlib.util.spec_from_file_location('timer_shipping',R/'tools/probes/shipping-wasm2c.py');shipping=importlib.util.module_from_spec(spec);spec.loader.exec_module(shipping)
  rust_guest.subprocess=types.SimpleNamespace(run=run,check_output=check_output)
  modules=shipping.coroutine_guests(env['RUSTC'],inputs,guests,env)
  prepared=wasm2c.prepare(inputs/'bundle',modules,Path(P['wabt']),cook,execute=lambda a:run(a).stdout)
  assert len(prepared['modules'])==12 and all(m['persistent_state']is not None for m in prepared['modules'])
  save('prepared.json',prepared);save('sdk-provenance.json',rust_guest.provenance());env.update(INCANT_WASM_BUNDLE=str(inputs/'bundle'),INCANT_RUST_SDK_GUESTS=str(guests))
  cargo_stage('actual-coroutine-guests',['test','-p','incant_wasm_dev','--features','persistent-conformance','--test','coroutines','--test','coroutines_parity','--test','registry'],tests=3)
  cargo_stage('existing-typescript-coroutine-contract',['test','-p','incant_script','--features','compiler','--lib','coroutines::tests'],tests=1)
  print('strict-development-coroutine-lint',flush=True)
  args=[cargo,'clippy','--profile','ci','-j2','--locked','--offline','--no-default-features','--message-format=json','-p','incant_wasm_dev','--features','persistent-conformance','--lib','--test','coroutines','--test','coroutines_parity','--test','registry','--','-D','warnings']
  done=run(args,timeout=300);assert any(json.loads(l).get('reason')=='build-finished' and json.loads(l).get('success') for l in done.stdout.splitlines()if l.startswith('{'))
  r['stages'].append({'name':'strict-development-coroutine-lint','passed':True})
  for n,h in prepared['files'].items():assert sha(inputs/'bundle'/n)==h
  protected();assert sources()==json.loads((E/'sources.json').read_text());o.passed=True;r['passed']=True
except BaseException as error:r['error']=repr(error)
r.update(seconds=time.monotonic()-o.start,cumulative_seconds=P['prior_seconds']+time.monotonic()-o.start,target_peak=o.peaks['target'],final_target=tree_bytes(T),groups=o.groups,source_unchanged=sources()==json.loads((E/'sources.json').read_text()))
rows=process_rows();r['absence']=[{'pid':g['pid'],'absent':not any(g['pid']in(pid,group)for pid,group,_ in rows)}for g in o.groups]
r['passed']&=r['source_unchanged']and all(a['absent']for a in r['absence'])and all(g['cleanup_confirmed']for g in o.groups)
save('result.json',r);print(json.dumps({k:v for k,v in r.items()if k not in('stages','groups','artifacts','absence')}),flush=True)
raise SystemExit(0 if r['passed']else 1)
