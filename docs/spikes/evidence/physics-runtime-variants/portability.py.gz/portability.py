from pathlib import Path
import sys,os,json,hashlib,time
root=Path('/Users/andreyyurlov/.codex/worktrees/native-audio-host/incant');out=Path('/Users/andreyyurlov/.codex/incant-evidence/physics-runtime-variants-001')
sys.path.insert(0,str(root/'tools'))
from native_process import run
env=dict(os.environ,CARGO_TARGET_DIR='/Users/andreyyurlov/.codex/incant-physics-variant-target');rows=[];code=0
cases=[('wasm-deterministic',['--target','wasm32-unknown-unknown'],0),('wasm-fast',['--target','wasm32-unknown-unknown','--no-default-features'],0),('conflicting-modes',['--features','incant_physics_runtime/fast-simd8,incant_physics_2d_runtime/fast-simd8'],101)]
for name,extra,expected in cases:
 argv=[str(root/'tools/cargo'),'check','--locked','--profile','ci','-j2','-p','incant_physics_runtime','-p','incant_physics_2d_runtime','--message-format=json',*extra];start=time.monotonic()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:r=run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr,text=False,timeout=1800)
 row={'name':name,'argv':argv,'exit_code':r.returncode,'expected_exit':expected,'seconds':time.monotonic()-start}
 for stream in ['stdout','stderr']:
  path=out/(name+'.'+stream);row[stream]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 rows.append(row);(out/'portability-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode!=expected:code=1;break
freeze=json.loads((out/'freeze.json').read_text());changed=[p for p,h in freeze.items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h]
(out/'portability-terminal.json').write_text(json.dumps({'exit_code':code,'changed':changed},indent=2)+'\n');sys.exit(code or bool(changed))
