from pathlib import Path
import sys,os,json,hashlib,time
root=Path('/Users/andreyyurlov/.codex/worktrees/native-audio-host/incant'); out=Path('/Users/andreyyurlov/.codex/incant-evidence/physics-runtime-variants-001')
sys.path.insert(0,str(root/'tools'))
from native_process import run
env=dict(os.environ,CARGO_TARGET_DIR='/Users/andreyyurlov/.codex/incant-physics-variant-target')
commands=[]; code=0
for mode,features in [('deterministic',[]),('fast',['--no-default-features']),('fast-simd8',['--no-default-features','--features','incant_physics_runtime/fast-simd8,incant_physics_2d_runtime/fast-simd8'])]:
 for action in ['test','clippy']:
  argv=[str(root/'tools/cargo'),action,'--locked','--profile','ci','-j2','-p','incant_physics_runtime','-p','incant_physics_2d_runtime','--message-format=json',*features]
  if action=='clippy':argv+=['--all-targets','--','-D','warnings']
  dest=out/(mode+'-'+action);start=time.monotonic()
  with dest.with_suffix('.stdout').open('wb') as stdout,dest.with_suffix('.stderr').open('wb') as stderr:
   result=run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr,text=False,timeout=2400)
  row={'mode':mode,'action':action,'argv':argv,'exit_code':result.returncode,'seconds':time.monotonic()-start}
  for stream in ['stdout','stderr']:
   p=dest.with_suffix('.'+stream);row[stream]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
  commands.append(row);(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  print(mode,action,result.returncode,flush=True)
  if result.returncode: code=result.returncode;break
 if code:break
freeze=json.loads((out/'freeze.json').read_text())
changed=[p for p,h in freeze.items() if not (root/p).is_file() or hashlib.sha256((root/p).read_bytes()).hexdigest()!=h]
(out/'terminal.json').write_text(json.dumps({'exit_code':code,'changed':changed,'frozen_files':len(freeze)},indent=2)+'\n')
sys.exit(code or bool(changed))
