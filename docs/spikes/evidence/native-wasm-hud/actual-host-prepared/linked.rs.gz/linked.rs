// Generated trusted static descriptors. Do not load from project data.
use crate::{Import, ModuleExports};
use std::ffi::c_void;
unsafe extern "C" {
 fn incant_m0_create(cb:Import,ctx:*mut c_void,out:*mut *mut c_void)->i32;
 fn incant_m0_update(p:*mut c_void,cb:Import,ctx:*mut c_void,e:i64,dt:f64)->i32;
 fn incant_m0_free(p:*mut c_void);
}
unsafe extern "C" {
 fn incant_m1_create(cb:Import,ctx:*mut c_void,out:*mut *mut c_void)->i32;
 fn incant_m1_update(p:*mut c_void,cb:Import,ctx:*mut c_void,e:i64,dt:f64)->i32;
 fn incant_m1_free(p:*mut c_void);
}
pub fn linked(name: &str) -> Option<ModuleExports> { match name {
"rust-hud" => Some(unsafe { ModuleExports::from_linked(incant_m0_create, incant_m0_update, incant_m0_free) }),
"hud" => Some(unsafe { ModuleExports::from_linked(incant_m1_create, incant_m1_update, incant_m1_free) }),
_ => None } }
