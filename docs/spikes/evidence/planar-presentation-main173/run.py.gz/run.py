from pathlib import Path
import os,sys,json,subprocess,hashlib,time,shutil
r=Path('/Users/andreyyurlov/.codex/worktrees/native-fbx-import/incant');o=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/planar-presentation-main173-001');o.mkdir(exist_ok=False)
td=Path('/Users/andreyyurlov/.codex/incant-planar-integration-target')
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
assert not git('status','--porcelain');assert git('rev-parse','HEAD')=='0efd6d9b83b1cf09fdc4d3c2ac07f2609fce1623'
paths=git('ls-files','crates','editor/app','tools','sdk','schemas','third_party','Cargo.toml','Cargo.lock','rust-toolchain.toml','.cargo','samples/planar').splitlines();freeze={p:h(r/p) for p in paths if (r/p).is_file()}
(o/'freeze.json').write_text(json.dumps({'head':git('rev-parse','HEAD'),'root':str(r),'files':freeze},indent=2)+'\n')
e=dict(os.environ,CARGO_TARGET_DIR=str(td),PYTHONDONTWRITEBYTECODE='1');e['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:/Users/andreyyurlov/.local/share/fnm/node-versions/v22.23.3/installation/bin:/opt/homebrew/bin:'+e['PATH'];rows=[]
def run(name,cmd):
 assert all(h(r/p)==v for p,v in freeze.items());print('starting',name,flush=True);start=time.monotonic()
 with (o/(name+'.stdout')).open('wb') as out,(o/(name+'.stderr')).open('wb') as err:rc=subprocess.run(cmd,cwd=r,env=e,stdout=out,stderr=err).returncode
 row={'name':name,'command':cmd,'exit':rc,'seconds':time.monotonic()-start}
 for s in ['stdout','stderr']:row[s]={'path':str(o/(name+'.'+s)),'sha256':h(o/(name+'.'+s))}
 rows.append(row);(o/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,rc,flush=True)
 assert all(h(r/p)==v for p,v in freeze.items())
 if rc:raise SystemExit(rc)
metadata=json.loads(subprocess.check_output(['./tools/cargo','metadata','--locked','--no-deps','--format-version','1'],cwd=r,env=e));packages=[p['name'] for p in metadata['packages'] if p['id'] in metadata['workspace_members']]
(o/'clone.json').write_text(json.dumps({'source':'/Users/andreyyurlov/.codex/incant-physics-foundation-integration-target','destination':str(td),'method':'read-only APFS cp -cR while source idle; clone19266 terminal0','checkout':str(r),'cleaned_workspace_packages':packages},indent=2)+'\n')
run('cloned-workspace-clean',['./tools/cargo','clean','--target-dir',str(td)]+[x for p in packages for x in ['-p',p]])
(td/'incant-checkout-owner.json').write_text(json.dumps({'checkout':str(r),'method':'APFS dependency clone; all workspace package products removed before use'},indent=2)+'\n')
run('unit',['python3','-B','-m','unittest','discover','-s','tools/tests','-p','test_planar_presentation.py'])
run('typescript',['node','node_modules/typescript/bin/tsc','-p','samples/planar/tsconfig.json'])
base=['--locked','--profile','ci','--target','aarch64-apple-darwin','-j2','--message-format=json']
run('headless',['./tools/cargo','build',*base,'-p','incant_headless','--bin','incant_headless'])
source=td/'aarch64-apple-darwin/ci/incant_headless';binary=o/'incant_headless';shutil.copy2(source,binary);binary.chmod(0o555)
(o/'binary.json').write_text(json.dumps({'source':str(source),'path':str(binary),'sha256':h(binary),'bytes':binary.stat().st_size,'head':git('rev-parse','HEAD'),'profile':'ci','target':'aarch64-apple-darwin','features':'incant_headless default','freeze_sha256':h(o/'freeze.json')},indent=2)+'\n')
for name,args in [('default',[]),('presentation',['--presentation'])]:run(name,['python3','-B','samples/planar/verify.py',*args,str(o/name),'--binary',str(binary)])
run('authored-cove',['python3','-B','samples/planar/scene.py',str(o/'authored-cove'),'--binary',str(binary),'--play'])
run('player-clippy',['./tools/cargo','clippy',*base,'-p','incant_game_player','--all-targets','--features','project,render-gpu','--','-D','warnings'])
run('feature-guard',['python3','tools/physics_features.py','manifest'])
run('fmt',['./tools/cargo','fmt','--all','--','--check'])
run('conventions',['python3','tools/generate_conventions.py','--check'])
run('diff',['git','diff','--check'])
(o/'terminal.json').write_text(json.dumps({'exit':0,'head':git('rev-parse','HEAD'),'frozen_files':len(freeze),'unchanged':True,'gpu_executed':False},indent=2)+'\n');print('all terminal',flush=True)
