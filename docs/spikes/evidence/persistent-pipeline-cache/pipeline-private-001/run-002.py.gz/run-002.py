import json,subprocess,time,os,hashlib
from pathlib import Path
b=Path(__file__).parent;env=dict(os.environ);env['PATH']='/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin:'+env['PATH'];env['CARGO_TARGET_DIR']='/tmp/incant-agent-font-target'
rows=[]
for name,args in [('tests',['test']),('clippy',['clippy','--all-targets','--','-D','warnings'])]:
 argv=['/Users/andreyyurlov/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin/cargo',args[0],'--offline','--manifest-path',str(b/'harness/Cargo.toml'),'-j2','--locked',*args[1:]]
 start=time.monotonic();p=subprocess.run(argv,cwd=b,env=env,capture_output=True,timeout=180);log=b/(name+'-002.log');log.write_bytes(p.stdout+p.stderr)
 row={'argv':argv,'cwd':str(b),'env':{'PATH':env['PATH'],'CARGO_TARGET_DIR':env['CARGO_TARGET_DIR']},'exit_code':p.returncode,'seconds':time.monotonic()-start,'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()};rows.append(row);(b/'commands-002.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
