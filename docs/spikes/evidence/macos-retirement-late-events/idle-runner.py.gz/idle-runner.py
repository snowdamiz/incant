from pathlib import Path
import subprocess,time,re,json,hashlib,datetime
out=Path('/Users/andreyyurlov/.codex/incant-integration-evidence/macos-retirement-late-events-003');binary=out/'macos_text_retirement';expected='cc3dead50b353b4edbb27c37dd3b5580b2a9e7c2f01d410087bb88b3da4f1d6e';assert hashlib.sha256(binary.read_bytes()).hexdigest()==expected

def idle():
 s=subprocess.check_output(['/usr/sbin/ioreg','-c','IOHIDSystem','-r','-l'],text=True);m=re.search(r'"HIDIdleTime"\s*=\s*(\d+)',s);assert m;return int(m[1])/1e9

def front():
 return subprocess.check_output(['osascript','-e','tell application "System Events" to get bundle identifier of first application process whose frontmost is true'],text=True).strip()

def active():
 s=subprocess.check_output(['ps','-axo','pid=,comm='],text=True);return [x.strip() for x in s.splitlines() if any(y in x.lower() for y in ['screencapture','incant_editor','incant_game_player'])]

start=time.monotonic()
while idle()<20:
 if time.monotonic()-start>=55:
  print(json.dumps({'launched':False,'reason':'No20-second user-idle interval; no native process started'}));raise SystemExit(0)
 time.sleep(.25)
assert not active(),active();foreground=front();before=idle()
if before<20:print(json.dumps({'launched':False,'reason':'User active after foreground read'}));raise SystemExit(0)
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary_sha256':expected,'idle_before_seconds':before,'foreground_before':foreground,'no_capture_or_player_before':True,'no_screenshot':True,'no_input_injected':True,'no_gpu':True};started=time.monotonic()
with (out/'native.stdout').open('w') as stdout,(out/'native.stderr').open('w') as stderr:
 p=subprocess.Popen([str(binary)],stdout=stdout,stderr=stderr);record['pid']=p.pid;interrupted=False
 while p.poll() is None:
  if idle()<20:
   interrupted=True;p.terminate();break
  if time.monotonic()-started>20:
   p.terminate();record['timeout']=True;break
  time.sleep(.03)
 try:rc=p.wait(timeout=5)
 except subprocess.TimeoutExpired:p.kill();rc=p.wait();record['forced_kill']=True
record.update(exit=rc,seconds=time.monotonic()-started,interrupted_by_input=interrupted,reaped=True,foreground_after=front())
if record['foreground_after']!=foreground and not interrupted:
 subprocess.run(['osascript','-e',f'tell application id {json.dumps(foreground)} to activate'],check=True);record['foreground_restored']=front()==foreground
else:record['foreground_preserved']=record['foreground_after']==foreground
for name in ['native.stdout','native.stderr']:record[name]={'sha256':hashlib.sha256((out/name).read_bytes()).hexdigest(),'bytes':(out/name).stat().st_size}
(out/'native-run.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));assert rc==0 and not interrupted
result=json.loads((out/'native.stdout').read_text());assert result=={'passed':True,'native_contexts':768,'cycles':256,'stale_sessions_refused':256,'active_owner_destroyed':True,'visible_window':False,'gpu_submitted':False,'input_injected':False};print('Native AppKit retirement passed')
